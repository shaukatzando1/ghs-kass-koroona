/**
 * School Management Database - DB & Storage Engine
 * Handles localStorage persistence, models, relationships, and seed data.
 */

const DB_KEY = 'school_db_kass_koroona_v1';

const SchoolDB = {
  // Database State
  data: {
    students: [],
    teachers: [],
    classes: [],
    subjects: [],
    attendance: [],
    marks: [],
    fees: [],
    notices: [],
    stockGeneral: [],
    stockPTC: [],
    settings: {
      schoolName: 'GOVT: HIGH SCHOOL KASS KOROONA, MARDAN',
      emisCode: '35567',
      tagline: 'Excellence in Education & Character (تعلیم و تربیت کا معتبر ادارہ)',
      address: 'Kass Koroona, Mardan, Khyber Pakhtunkhwa, Pakistan',
      phone: '+92 937 000000',
      email: 'ghs.kasskoroona@schools.kp.gov.pk',
      academicYear: '2025 - 2026',
      currency: 'Rs. ',
      author: 'Shaukat Zando'
    }
  },

  // Initialize DB from localStorage or seed
  init() {
    try {
      const stored = localStorage.getItem(DB_KEY);
      if (stored) {
        this.data = JSON.parse(stored);
        // Ensure all collections exist in case of version upgrades
        this.ensureCollections();
      } else {
        this.seed();
        this.save();
      }
    } catch (err) {
      console.error('Error loading database, resetting to seed data:', err);
      this.seed();
      this.save();
    }
  },

  ensureCollections() {
    const defaultKeys = ['students', 'teachers', 'classes', 'subjects', 'attendance', 'marks', 'fees', 'notices', 'stockGeneral', 'stockPTC', 'documents', 'freeTextBooks', 'admWithdrawalMiddle', 'admWithdrawalHigh'];
    defaultKeys.forEach(k => {
      if (!Array.isArray(this.data[k])) {
        this.data[k] = [];
      }
    });

    // Default Standard Classes for Grades 6th, 7th, 8th (A, B, C, D), 9th, 10th (A, B, C), and 11th, 12th (A, B)
    const standardClasses = [
      // Grade 6: Sections A, B, C, D
      { id: 'CLS-6A',  name: 'Grade 6',  section: 'A', room: 'Room 01', teacherId: 'TCH-103', capacity: 40 },
      { id: 'CLS-6B',  name: 'Grade 6',  section: 'B', room: 'Room 02', teacherId: 'TCH-107', capacity: 40 },
      { id: 'CLS-6C',  name: 'Grade 6',  section: 'C', room: 'Room 03', teacherId: 'TCH-108', capacity: 40 },
      { id: 'CLS-6D',  name: 'Grade 6',  section: 'D', room: 'Room 04', teacherId: 'TCH-109', capacity: 40 },
      // Grade 7: Sections A, B, C, D
      { id: 'CLS-7A',  name: 'Grade 7',  section: 'A', room: 'Room 05', teacherId: 'TCH-108', capacity: 40 },
      { id: 'CLS-7B',  name: 'Grade 7',  section: 'B', room: 'Room 06', teacherId: 'TCH-109', capacity: 40 },
      { id: 'CLS-7C',  name: 'Grade 7',  section: 'C', room: 'Room 07', teacherId: 'TCH-105', capacity: 40 },
      { id: 'CLS-7D',  name: 'Grade 7',  section: 'D', room: 'Room 08', teacherId: 'TCH-110', capacity: 40 },
      // Grade 8: Sections A, B, C, D
      { id: 'CLS-8A',  name: 'Grade 8',  section: 'A', room: 'Room 09', teacherId: 'TCH-105', capacity: 40 },
      { id: 'CLS-8B',  name: 'Grade 8',  section: 'B', room: 'Room 10', teacherId: 'TCH-110', capacity: 40 },
      { id: 'CLS-8C',  name: 'Grade 8',  section: 'C', room: 'Room 11', teacherId: 'TCH-101', capacity: 40 },
      { id: 'CLS-8D',  name: 'Grade 8',  section: 'D', room: 'Room 12', teacherId: 'TCH-106', capacity: 40 },
      // Grade 9: Sections A, B, C
      { id: 'CLS-9A',  name: 'Grade 9',  section: 'A', room: 'Lab 1',   teacherId: 'TCH-102', capacity: 40 }, // Science Group
      { id: 'CLS-9B',  name: 'Grade 9',  section: 'B', room: 'Room 13', teacherId: 'TCH-106', capacity: 40 }, // Arts Group
      { id: 'CLS-9C',  name: 'Grade 9',  section: 'C', room: 'Room 14', teacherId: 'TCH-107', capacity: 40 }, // Arts Group
      // Grade 10: Sections A, B, C
      { id: 'CLS-10A', name: 'Grade 10', section: 'A', room: 'Lab 2',   teacherId: 'TCH-101', capacity: 40 }, // Science Group
      { id: 'CLS-10B', name: 'Grade 10', section: 'B', room: 'Room 15', teacherId: 'TCH-108', capacity: 40 }, // Arts Group
      { id: 'CLS-10C', name: 'Grade 10', section: 'C', room: 'Room 16', teacherId: 'TCH-109', capacity: 40 }, // Arts Group
      // Grade 11: Sections A, B
      { id: 'CLS-11A', name: 'Grade 11', section: 'A', room: 'College Block 1', teacherId: 'TCH-102', capacity: 40 },
      { id: 'CLS-11B', name: 'Grade 11', section: 'B', room: 'College Block 2', teacherId: 'TCH-101', capacity: 40 },
      // Grade 12: Sections A, B
      { id: 'CLS-12A', name: 'Grade 12', section: 'A', room: 'College Block 3', teacherId: 'TCH-105', capacity: 40 },
      { id: 'CLS-12B', name: 'Grade 12', section: 'B', room: 'College Block 4', teacherId: 'TCH-104', capacity: 40 }
    ];

    let subjectsChanged = false;
    // Strictly retain only valid standard classes and remove any non-standard ones
    const validClassIds = new Set(standardClasses.map(sc => sc.id));
    if (Array.isArray(this.data.classes)) {
      const initialCount = this.data.classes.length;
      this.data.classes = this.data.classes.filter(c => validClassIds.has(c.id));
      if (this.data.classes.length !== initialCount) {
        subjectsChanged = true;
      }
    } else {
      this.data.classes = [];
    }

    standardClasses.forEach(sc => {
      const exists = this.data.classes.some(c => c.id === sc.id);
      if (!exists) {
        this.data.classes.push(sc);
        subjectsChanged = true;
      }
    });

    // 31 Comprehensive Curriculum Subjects for KP High Schools:
    // 1. Middle Section (Grades 6th, 7th, 8th - All Sections) -> 13 Subjects
    // 2. Secondary Science Section (Grades 9th & 10th - Section A) -> 9 Subjects
    // 3. Secondary Arts / General Section (Grades 9th B, 9th C, 10th B, 10th C) -> 9 Subjects
    const standardSubjectsV2 = [
      // --- Group 1: 6th, 7th, 8th (All Sections) [13 Subjects] ---
      { code: 'MID-ENG', name: 'English (انگریزی)', grade: 'Grades 6th, 7th, 8th (All Sections)', teacherId: 'TCH-103', totalMarks: 100 },
      { code: 'MID-URD', name: 'Urdu (اردو)', grade: 'Grades 6th, 7th, 8th (All Sections)', teacherId: 'TCH-107', totalMarks: 100 },
      { code: 'MID-MTH', name: 'Maths (ریاضی)', grade: 'Grades 6th, 7th, 8th (All Sections)', teacherId: 'TCH-101', totalMarks: 100 },
      { code: 'MID-GSC', name: 'G.Science (جنرل سائنس)', grade: 'Grades 6th, 7th, 8th (All Sections)', teacherId: 'TCH-105', totalMarks: 100 },
      { code: 'MID-ISL', name: 'Islamiyat (اسلامیات)', grade: 'Grades 6th, 7th, 8th (All Sections)', teacherId: 'TCH-106', totalMarks: 100 },
      { code: 'MID-MQR', name: 'Mutalea Quran (مطالعہ قرآن حکیم)', grade: 'Grades 6th, 7th, 8th (All Sections)', teacherId: 'TCH-106', totalMarks: 100 },
      { code: 'MID-HIS', name: 'History (تاریخ)', grade: 'Grades 6th, 7th, 8th (All Sections)', teacherId: 'TCH-108', totalMarks: 100 },
      { code: 'MID-GEO', name: 'Geography (جغرافیہ)', grade: 'Grades 6th, 7th, 8th (All Sections)', teacherId: 'TCH-108', totalMarks: 100 },
      { code: 'MID-HPE', name: 'HPE (صحت و جسمانی تعلیم)', grade: 'Grades 6th, 7th, 8th (All Sections)', teacherId: 'TCH-109', totalMarks: 100 },
      { code: 'MID-ARB', name: 'Arabic (عربی)', grade: 'Grades 6th, 7th, 8th (All Sections)', teacherId: 'TCH-106', totalMarks: 100 },
      { code: 'MID-CS',  name: 'Computer (کمپیوٹر)', grade: 'Grades 6th, 7th, 8th (All Sections)', teacherId: 'TCH-104', totalMarks: 100 },
      { code: 'MID-DRW', name: 'Drawing (ڈرائنگ)', grade: 'Grades 6th, 7th, 8th (All Sections)', teacherId: 'TCH-110', totalMarks: 100 },
      { code: 'MID-PAS', name: 'Pashto (پشتو)', grade: 'Grades 6th, 7th, 8th (All Sections)', teacherId: 'TCH-107', totalMarks: 100 },

      // --- Group 2: 9th & 10th Section A (Science Group) [9 Subjects] ---
      { code: 'SCI-ENG',  name: 'English (انگریزی)', grade: 'Grades 9th & 10th (Section A - Science)', teacherId: 'TCH-103', totalMarks: 100 },
      { code: 'SCI-URD',  name: 'Urdu (اردو)', grade: 'Grades 9th & 10th (Section A - Science)', teacherId: 'TCH-107', totalMarks: 100 },
      { code: 'SCI-MTH',  name: 'Maths (ریاضی)', grade: 'Grades 9th & 10th (Section A - Science)', teacherId: 'TCH-101', totalMarks: 100 },
      { code: 'SCI-ISLC', name: 'Islamiyat (C) (اسلامیات لازمی)', grade: 'Grades 9th & 10th (Section A - Science)', teacherId: 'TCH-106', totalMarks: 100 },
      { code: 'SCI-PKS',  name: 'Pak. Studies (مطالعہ پاکستان)', grade: 'Grades 9th & 10th (Section A - Science)', teacherId: 'TCH-108', totalMarks: 100 },
      { code: 'SCI-BIO',  name: 'Biology (بیالوجی)', grade: 'Grades 9th & 10th (Section A - Science)', teacherId: 'TCH-105', totalMarks: 100 },
      { code: 'SCI-PHY',  name: 'Physics (فزکس)', grade: 'Grades 9th & 10th (Section A - Science)', teacherId: 'TCH-102', totalMarks: 100 },
      { code: 'SCI-CHM',  name: 'Chemistry (کیمسٹری)', grade: 'Grades 9th & 10th (Section A - Science)', teacherId: 'TCH-105', totalMarks: 100 },
      { code: 'SCI-MQR',  name: 'Mutalea Quran (مطالعہ قرآن حکیم)', grade: 'Grades 9th & 10th (Section A - Science)', teacherId: 'TCH-106', totalMarks: 100 },

      // --- Group 3: 9th B, 9th C and 10th B, 10th C (Arts / General Group) [9 Subjects] ---
      { code: 'ART-ENG',  name: 'English (انگریزی)', grade: 'Grades 9th & 10th (Sec B & C - Arts)', teacherId: 'TCH-103', totalMarks: 100 },
      { code: 'ART-URD',  name: 'Urdu (اردو)', grade: 'Grades 9th & 10th (Sec B & C - Arts)', teacherId: 'TCH-107', totalMarks: 100 },
      { code: 'ART-GMTH', name: 'G.Maths (جنرل ریاضی)', grade: 'Grades 9th & 10th (Sec B & C - Arts)', teacherId: 'TCH-101', totalMarks: 100 },
      { code: 'ART-ISLC', name: 'Islamiyat (C) (اسلامیات لازمی)', grade: 'Grades 9th & 10th (Sec B & C - Arts)', teacherId: 'TCH-106', totalMarks: 100 },
      { code: 'ART-PKS',  name: 'Pak. Studies (مطالعہ پاکستان)', grade: 'Grades 9th & 10th (Sec B & C - Arts)', teacherId: 'TCH-108', totalMarks: 100 },
      { code: 'ART-ISLE', name: 'Islamiyat (E) (اسلامیات اختیاری)', grade: 'Grades 9th & 10th (Sec B & C - Arts)', teacherId: 'TCH-106', totalMarks: 100 },
      { code: 'ART-PAS',  name: 'Pashto (پشتو)', grade: 'Grades 9th & 10th (Sec B & C - Arts)', teacherId: 'TCH-107', totalMarks: 100 },
      { code: 'ART-DRW',  name: 'Drawing (ڈرائنگ)', grade: 'Grades 9th & 10th (Sec B & C - Arts)', teacherId: 'TCH-110', totalMarks: 100 },
      { code: 'ART-MQR',  name: 'Mutalea Quran (مطالعہ قرآن حکیم)', grade: 'Grades 9th & 10th (Sec B & C - Arts)', teacherId: 'TCH-106', totalMarks: 100 }
    ];

    // Migration Check: Ensure all subjects have totalMarks initialized
    this.data.subjects.forEach(s => {
      if (s.totalMarks === undefined || s.totalMarks === null || isNaN(Number(s.totalMarks))) {
        s.totalMarks = 100;
        subjectsChanged = true;
      }
    });

    if (this.data.subjectsSchemaVersion !== 2 || this.data.subjects.some(s => s.code && s.code.endsWith('-101'))) {
      this.data.subjects = [...standardSubjectsV2];
      this.data.subjectsSchemaVersion = 2;
      subjectsChanged = true;
    } else {
      // Ensure all 31 subjects are present
      standardSubjectsV2.forEach(std => {
        const exists = this.data.subjects.some(s => s.code === std.code);
        if (!exists) {
          this.data.subjects.push(std);
          subjectsChanged = true;
        }
      });
    }

    const standardTeachers = [
      { id: 'TCH-106', name: 'Qari Abdul Rehman', gender: 'Male', qualification: 'M.A. Islamic Studies, Shahadat-ul-Almiya', phone: '0305-9371006', email: 'a.rehman@schools.kp.gov.pk', joinDate: '2021-04-10', status: 'Active' },
      { id: 'TCH-107', name: 'Mr. Ahmad Khan', gender: 'Male', qualification: 'M.A. Urdu & Pashto Literature', phone: '0306-9371007', email: 'a.khan@schools.kp.gov.pk', joinDate: '2020-09-01', status: 'Active' },
      { id: 'TCH-108', name: 'Mr. Tariq Mehmood', gender: 'Male', qualification: 'M.Sc. Geography & History', phone: '0307-9371008', email: 't.mehmood@schools.kp.gov.pk', joinDate: '2021-06-15', status: 'Active' },
      { id: 'TCH-109', name: 'Coach Bilal Shah', gender: 'Male', qualification: 'BS Physical Education & Sports', phone: '0308-9371009', email: 'b.shah@schools.kp.gov.pk', joinDate: '2022-01-20', status: 'Active' },
      { id: 'TCH-110', name: 'Ms. Ayesha Noor', gender: 'Female', qualification: 'B.F.A. Fine Arts', phone: '0309-9371010', email: 'a.noor@schools.kp.gov.pk', joinDate: '2022-08-01', status: 'Active' }
    ];

    standardTeachers.forEach(tch => {
      const exists = this.data.teachers.some(t => t.id === tch.id);
      if (!exists) {
        this.data.teachers.push(tch);
        subjectsChanged = true;
      }
    });

    // Auto-migrate teachers: add new staff fields (Father Name, Designation, BPS, Qualification, Personal No, CNIC, Salary Account, Bank Code, Bank Name)
    const defaultStaffMetadata = {
      'TCH-101': { fatherName: 'Muhammad Vance', designation: 'Subject Specialist (SS) Maths', bps: 'BPS-17', personalNo: '00389101', cnic: '16101-2345671-1', salaryAccount: '0342001928374', bankCode: '0342', bankName: 'National Bank of Pakistan (NBP)' },
      'TCH-102': { fatherName: 'Abdul Hameed Reed', designation: 'Secondary School Teacher - SST (Physics)', bps: 'BPS-16', personalNo: '00389102', cnic: '16101-3456782-2', salaryAccount: '0342001928375', bankCode: '0342', bankName: 'National Bank of Pakistan (NBP)' },
      'TCH-103': { fatherName: 'Gulzar Ahmad Brody', designation: 'Secondary School Teacher - SST (English)', bps: 'BPS-16', personalNo: '00389103', cnic: '16101-4567893-3', salaryAccount: '0342001928376', bankCode: '0342', bankName: 'National Bank of Pakistan (NBP)' },
      'TCH-104': { fatherName: 'Noor Muhammad Martinez', designation: 'Secondary School Teacher - SST (IT)', bps: 'BPS-16', personalNo: '00389104', cnic: '16101-5678904-4', salaryAccount: '0342001928377', bankCode: '0342', bankName: 'National Bank of Pakistan (NBP)' },
      'TCH-105': { fatherName: 'Haji Chen Badshah', designation: 'Secondary School Teacher - SST (Bio/Chem)', bps: 'BPS-16', personalNo: '00389105', cnic: '16101-6789015-5', salaryAccount: '0342001928378', bankCode: '0342', bankName: 'National Bank of Pakistan (NBP)' },
      'TCH-106': { fatherName: 'Hafiz Shams-ur-Rehman', designation: 'Theology Teacher (TT)', bps: 'BPS-15', personalNo: '00389106', cnic: '16101-7890126-6', salaryAccount: '0342001928379', bankCode: '0342', bankName: 'National Bank of Pakistan (NBP)' },
      'TCH-107': { fatherName: 'Sher Afzal Khan', designation: 'Certified Teacher (CT)', bps: 'BPS-15', personalNo: '00389107', cnic: '16101-8901237-7', salaryAccount: '0342001928380', bankCode: '0342', bankName: 'National Bank of Pakistan (NBP)' },
      'TCH-108': { fatherName: 'Fazal Mehmood', designation: 'Secondary School Teacher - SST (General)', bps: 'BPS-16', personalNo: '00389108', cnic: '16101-9012348-8', salaryAccount: '0342001928381', bankCode: '0342', bankName: 'National Bank of Pakistan (NBP)' },
      'TCH-109': { fatherName: 'Sayed Anwar Shah', designation: 'Physical Education Teacher (PET)', bps: 'BPS-15', personalNo: '00389109', cnic: '16101-0123459-9', salaryAccount: '0342001928382', bankCode: '0342', bankName: 'National Bank of Pakistan (NBP)' },
      'TCH-110': { fatherName: 'Muhammad Noor Jan', designation: 'Drawing Master (DM)', bps: 'BPS-15', personalNo: '00389110', cnic: '16101-1234560-0', salaryAccount: '0342001928383', bankCode: '0342', bankName: 'National Bank of Pakistan (NBP)' }
    };

    this.data.teachers.forEach((t, i) => {
      const def = defaultStaffMetadata[t.id] || {};
      if (!t.fatherName) { t.fatherName = def.fatherName || 'Tariq Khan'; subjectsChanged = true; }
      if (!t.designation) { t.designation = def.designation || 'Staff / Teacher'; subjectsChanged = true; }
      if (!t.bps) { t.bps = def.bps || 'BPS-16'; subjectsChanged = true; }
      if (!t.personalNo) { t.personalNo = def.personalNo || `003891${(i + 1).toString().padStart(2, '0')}`; subjectsChanged = true; }
      if (!t.cnic) { t.cnic = def.cnic || `16101-${(1000000 + i)}-1`; subjectsChanged = true; }
      if (!t.salaryAccount) { t.salaryAccount = def.salaryAccount || `034200192838${i}`; subjectsChanged = true; }
      if (!t.bankCode) { t.bankCode = def.bankCode || '0342'; subjectsChanged = true; }
      if (!t.bankName) { t.bankName = def.bankName || 'National Bank of Pakistan (NBP)'; subjectsChanged = true; }
      if ('department' in t) {
        delete t.department;
        subjectsChanged = true;
      }
      if ('salary' in t) {
        delete t.salary;
        subjectsChanged = true;
      }
      if (!t.qualification && t.subject) {
        t.qualification = t.subject;
        subjectsChanged = true;
      }
      if ('subject' in t) {
        delete t.subject;
        subjectsChanged = true;
      }
    });

    // Auto-migrate phone numbers from placeholder format to realistic local Pakistani mobile numbers
    const pakTeacherPhones = [
      '0300-9371001', '0301-9371002', '0302-9371003', '0303-9371004', '0304-9371005',
      '0305-9371006', '0306-9371007', '0307-9371008', '0308-9371009', '0309-9371010'
    ];
    this.data.teachers.forEach((t, i) => {
      if (!t.phone || t.phone.includes('+1 (555)')) {
        t.phone = pakTeacherPhones[i % pakTeacherPhones.length];
        subjectsChanged = true;
      }
    });

    const pakStudentPhones = [
      '0300-8811001', '0301-8811002', '0302-8811003', '0303-8811004', '0304-8811005',
      '0305-8811006', '0306-8811007', '0307-8811008', '0308-8811009', '0309-8811010',
      '0310-8811011', '0311-8811012', '0312-8811013', '0313-8811014', '0314-8811015'
    ];
    this.data.students.forEach((s, i) => {
      if (!s.phone || s.phone.includes('+1 (555)')) {
        s.phone = pakStudentPhones[i % pakStudentPhones.length];
        subjectsChanged = true;
      }
      if (!s.specialCategory) {
        s.specialCategory = 'None';
        subjectsChanged = true;
      }
      if (s.admWithdrawalMiddle === undefined) {
        s.admWithdrawalMiddle = '';
        subjectsChanged = true;
      }
      if (s.admWithdrawalHigh === undefined) {
        s.admWithdrawalHigh = '';
        subjectsChanged = true;
      }
    });

    if (!this.data.settings) {
      this.data.settings = {
        schoolName: 'GOVT: HIGH SCHOOL KASS KOROONA, MARDAN',
        emisCode: '35567',
        tagline: 'Excellence in Education & Character (تعلیم و تربیت کا معتبر ادارہ)',
        address: 'Kass Koroona, Mardan, Khyber Pakhtunkhwa, Pakistan',
        phone: '+92 937 000000',
        email: 'ghs.kasskoroona@schools.kp.gov.pk',
        academicYear: '2025 - 2026',
        currency: 'Rs. '
      };
      subjectsChanged = true;
    } else {
      if (!this.data.settings.emisCode) {
        this.data.settings.emisCode = '35567';
        subjectsChanged = true;
      }
      if (this.data.settings.schoolName && (this.data.settings.schoolName.toLowerCase().includes('horizon') || this.data.settings.schoolName === 'Horizon Academy')) {
        this.data.settings.schoolName = 'GOVT: HIGH SCHOOL KASS KOROONA, MARDAN';
        this.data.settings.address = 'Kass Koroona, Mardan, Khyber Pakhtunkhwa, Pakistan';
        if (!this.data.settings.currency || this.data.settings.currency === '$') {
          this.data.settings.currency = 'Rs. ';
        }
        subjectsChanged = true;
      }
    }

    // Ensure Admin Credentials exist
    if (!this.data.admin) {
      this.data.admin = {
        username: 'admin',
        password: 'password123',
        fullName: 'Principal / Headmaster (پرنسپل / ہیڈ ماسٹر)',
        role: 'Administrator'
      };
      subjectsChanged = true;
    }

    // Auto-migrate legacy examination terms to 1st Semester & 2nd Semester
    if (this.data.marks && this.data.marks.length) {
      this.data.marks.forEach(m => {
        if (m.examTerm === 'Midterm Examination 2025' || m.examTerm === 'Midterm') {
          m.examTerm = '1st Semester';
          subjectsChanged = true;
        } else if (m.examTerm === 'Final Examination 2025' || m.examTerm === 'Final') {
          m.examTerm = '2nd Semester';
          subjectsChanged = true;
        }
      });
    }

    // Ensure 1st Semester marks exist for demo students STU-1004 & STU-1005
    if (this.data.marks) {
      const hasSem1_1004 = this.data.marks.some(m => m.studentId === 'STU-1004' && m.examTerm === '1st Semester');
      if (!hasSem1_1004) {
        this.data.marks.push(
          {
            id: 'MRK-504',
            studentId: 'STU-1004',
            classId: 'CLS-10A',
            examTerm: '1st Semester',
            scores: {
              'SCI-ENG': 86, 'SCI-URD': 89, 'SCI-MTH': 82, 'SCI-ISLC': 88, 'SCI-PKS': 85,
              'SCI-BIO': 85, 'SCI-PHY': 80, 'SCI-CHM': 82, 'SCI-MQR': 93
            },
            totalObtained: 770,
            maxMarks: 900,
            percentage: 86,
            grade: 'A',
            gpa: 3.7,
            remarks: 'Pleasant attitude and consistent effort throughout 1st semester.'
          },
          {
            id: 'MRK-505',
            studentId: 'STU-1005',
            classId: 'CLS-10A',
            examTerm: '1st Semester',
            scores: {
              'SCI-ENG': 70, 'SCI-URD': 72, 'SCI-MTH': 66, 'SCI-ISLC': 78, 'SCI-PKS': 70,
              'SCI-BIO': 70, 'SCI-PHY': 65, 'SCI-CHM': 64, 'SCI-MQR': 80
            },
            totalObtained: 635,
            maxMarks: 900,
            percentage: 71,
            grade: 'B',
            gpa: 3.0,
            remarks: 'Satisfactory foundation; can aim higher with diligent study.'
          }
        );
        subjectsChanged = true;
      }

      // Ensure 2nd Semester marks exist for all demo students
      const hasSem2 = this.data.marks.some(m => m.examTerm === '2nd Semester');
      if (!hasSem2) {
        this.data.marks.push(
          {
            id: 'MRK-601',
            studentId: 'STU-1001',
            classId: 'CLS-10A',
            examTerm: '2nd Semester',
            scores: {
              'SCI-ENG': 91, 'SCI-URD': 93, 'SCI-MTH': 96, 'SCI-ISLC': 95, 'SCI-PKS': 92,
              'SCI-BIO': 94, 'SCI-PHY': 90, 'SCI-CHM': 95, 'SCI-MQR': 99
            },
            totalObtained: 845,
            maxMarks: 900,
            percentage: 94,
            grade: 'A+',
            gpa: 4.0,
            remarks: 'Maintained stellar academic excellence. Promoted to Next Class with Distinction.'
          },
          {
            id: 'MRK-602',
            studentId: 'STU-1002',
            classId: 'CLS-10A',
            examTerm: '2nd Semester',
            scores: {
              'SCI-ENG': 93, 'SCI-URD': 91, 'SCI-MTH': 85, 'SCI-ISLC': 92, 'SCI-PKS': 89,
              'SCI-BIO': 90, 'SCI-PHY': 86, 'SCI-CHM': 87, 'SCI-MQR': 96
            },
            totalObtained: 809,
            maxMarks: 900,
            percentage: 90,
            grade: 'A+',
            gpa: 4.0,
            remarks: 'Superb dedication and remarkable grasp of languages and natural sciences.'
          },
          {
            id: 'MRK-603',
            studentId: 'STU-1003',
            classId: 'CLS-10A',
            examTerm: '2nd Semester',
            scores: {
              'SCI-ENG': 82, 'SCI-URD': 83, 'SCI-MTH': 77, 'SCI-ISLC': 86, 'SCI-PKS': 78,
              'SCI-BIO': 80, 'SCI-PHY': 75, 'SCI-CHM': 74, 'SCI-MQR': 89
            },
            totalObtained: 724,
            maxMarks: 900,
            percentage: 80,
            grade: 'A',
            gpa: 3.7,
            remarks: 'Significant improvement in mathematics and general coursework.'
          },
          {
            id: 'MRK-604',
            studentId: 'STU-1004',
            classId: 'CLS-10A',
            examTerm: '2nd Semester',
            scores: {
              'SCI-ENG': 88, 'SCI-URD': 90, 'SCI-MTH': 84, 'SCI-ISLC': 90, 'SCI-PKS': 86,
              'SCI-BIO': 87, 'SCI-PHY': 82, 'SCI-CHM': 83, 'SCI-MQR': 94
            },
            totalObtained: 784,
            maxMarks: 900,
            percentage: 87,
            grade: 'A',
            gpa: 3.7,
            remarks: 'Consistent hard work and highly commendable academic progress.'
          },
          {
            id: 'MRK-605',
            studentId: 'STU-1005',
            classId: 'CLS-10A',
            examTerm: '2nd Semester',
            scores: {
              'SCI-ENG': 74, 'SCI-URD': 76, 'SCI-MTH': 70, 'SCI-ISLC': 80, 'SCI-PKS': 72,
              'SCI-BIO': 74, 'SCI-PHY': 68, 'SCI-CHM': 67, 'SCI-MQR': 82
            },
            totalObtained: 663,
            maxMarks: 900,
            percentage: 74,
            grade: 'B',
            gpa: 3.0,
            remarks: 'Good overall performance; advised to concentrate on science labs.'
          }
        );
        subjectsChanged = true;
      }
    }

    // Ensure Stock General Register has default records
    if (!this.data.stockGeneral || !this.data.stockGeneral.length) {
      this.data.stockGeneral = this.getDefaultStockGeneral();
      subjectsChanged = true;
    }

    // Ensure Stock PTC Register has default records
    if (!this.data.stockPTC || !this.data.stockPTC.length) {
      this.data.stockPTC = this.getDefaultStockPTC();
      subjectsChanged = true;
    } else {
      // Ensure existing PTC items have releaseYear
      this.data.stockPTC.forEach(item => {
        if (!item.releaseYear) {
          if (item.id === 'STK-PTC-001' || item.id === 'STK-PTC-003' || item.id === 'STK-PTC-006') {
            item.releaseYear = '2023 - 2024';
          } else {
            item.releaseYear = '2024 - 2025';
          }
          subjectsChanged = true;
        }
      });
    }

    // Ensure Documents collection has default seed records
    if (!this.data.documents || !this.data.documents.length) {
      this.data.documents = this.getDefaultDocuments();
      subjectsChanged = true;
    }

    // Ensure Free Text Books collection has default seed records
    if (!this.data.freeTextBooks || !this.data.freeTextBooks.length) {
      this.data.freeTextBooks = this.getDefaultFreeTextBooks();
      subjectsChanged = true;
    }

    // Ensure Admission & Withdrawal Middle collection has default records
    if (!this.data.admWithdrawalMiddle || !this.data.admWithdrawalMiddle.length) {
      this.data.admWithdrawalMiddle = this.getDefaultAdmWithdrawal('middle');
      subjectsChanged = true;
    }

    // Ensure Admission & Withdrawal High collection has default records
    if (!this.data.admWithdrawalHigh || !this.data.admWithdrawalHigh.length) {
      this.data.admWithdrawalHigh = this.getDefaultAdmWithdrawal('high');
      subjectsChanged = true;
    }

    if (subjectsChanged) {
      this.save();
    }
  },

  // WhatsApp Integration Utilities
  formatWhatsAppNumber(phone) {
    if (!phone) return null;
    let digits = String(phone).replace(/\D/g, '');
    if (!digits) return null;
    // Pakistani mobile starting with 0: 03001234567 (11 digits) -> 923001234567
    if (digits.startsWith('0') && digits.length === 11) {
      digits = '92' + digits.substring(1);
    } else if (digits.length === 10 && digits.startsWith('3')) {
      digits = '92' + digits;
    }
    return digits.length >= 9 ? digits : null;
  },

  getWhatsAppLink(phone, message = '') {
    const cleanNumber = this.formatWhatsAppNumber(phone);
    if (!cleanNumber) return null;
    const textParam = message ? `?text=${encodeURIComponent(message)}` : '';
    return `https://wa.me/${cleanNumber}${textParam}`;
  },

  getStudentsByClass(className, section = '') {
    return this.data.students.filter(s => {
      let match = s.grade === className;
      if (section) match = match && s.section === section;
      return match;
    });
  },

  // Admin authentication methods
  isAdminAuthenticated() {
    return sessionStorage.getItem('school_admin_logged_in') === 'true';
  },

  getAdminProfile() {
    return this.data.admin || { username: 'admin', password: 'password123', fullName: 'Headmaster', role: 'Administrator' };
  },

  verifyAdmin(username, password) {
    const admin = this.getAdminProfile();
    return (username.trim().toLowerCase() === admin.username.toLowerCase()) && (password === admin.password);
  },

  updateAdminCredentials(newUsername, newPassword, newFullName) {
    if (!this.isAdminAuthenticated()) {
      console.warn('Unauthorized: Admin authorization required to update credentials.');
      return false;
    }
    if (!this.data.admin) this.data.admin = {};
    if (newUsername) this.data.admin.username = newUsername.trim();
    if (newPassword) this.data.admin.password = newPassword.trim();
    if (newFullName) this.data.admin.fullName = newFullName.trim();
    this.save();
    return true;
  },

  // Save current data state to localStorage
  save() {
    try {
      localStorage.setItem(DB_KEY, JSON.stringify(this.data));
      window.dispatchEvent(new CustomEvent('school_db_updated', { detail: this.data }));
      if (typeof CloudSync !== 'undefined' && CloudSync.config && CloudSync.config.enabled && CloudSync.config.autoSync && navigator.onLine) {
        CloudSync.debounceSync();
      }
      return true;
    } catch (err) {
      console.error('Failed to save to localStorage:', err);
      alert('Local storage limit exceeded or write error.');
      return false;
    }
  },

  // Reset database to initial sample data
  reset() {
    if (!this.isAdminAuthenticated()) {
      console.warn('Unauthorized: Admin authorization required to reset database.');
      return false;
    }
    this.seed();
    this.save();
    return true;
  },

  // Export full database as JSON file
  exportJSON() {
    const jsonStr = JSON.stringify(this.data, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const timestamp = new Date().toISOString().split('T')[0];
    a.href = url;
    a.download = `school_database_backup_${timestamp}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  },

  // Import JSON backup
  importJSON(jsonString) {
    if (!this.isAdminAuthenticated()) {
      return { success: false, message: 'Unauthorized: Admin log on is required to restore database backup.' };
    }
    try {
      const parsed = JSON.parse(jsonString);
      if (parsed && parsed.students && parsed.teachers) {
        this.data = parsed;
        this.ensureCollections();
        this.save();
        return { success: true };
      } else {
        return { success: false, message: 'Invalid database backup structure.' };
      }
    } catch (err) {
      return { success: false, message: 'JSON parsing error: ' + err.message };
    }
  },

  // Generic ID generator
  generateId(prefix = 'REC') {
    return `${prefix}-${Date.now().toString(36).toUpperCase()}-${Math.floor(Math.random() * 899 + 100)}`;
  },

  // ==================== STUDENTS ====================
  getStudents() {
    return [...this.data.students];
  },

  getStudentById(id) {
    return this.data.students.find(s => s.id === id);
  },

  saveStudent(student) {
    if (!this.isAdminAuthenticated()) {
      console.warn('Unauthorized: Admin authorization required to save student.');
      return null;
    }
    if (!student.id) {
      student.id = this.generateId('ADM');
    }
    if (!student.specialCategory) student.specialCategory = 'None';
    if (!student.admissionDate) student.admissionDate = new Date().toISOString().split('T')[0];
    if (!student.status) student.status = 'Active';

    const index = this.data.students.findIndex(s => s.id === student.id);
    if (index !== -1) {
      this.data.students[index] = { ...this.data.students[index], ...student };
    } else {
      this.data.students.unshift(student);
    }
    this.save();
    return student;
  },

  importStudents(studentsList) {
    if (!this.isAdminAuthenticated()) {
      console.warn('Unauthorized: Admin authorization required to import students.');
      return { success: false, message: 'Unauthorized: Admin privileges required.' };
    }
    if (!Array.isArray(studentsList) || !studentsList.length) {
      return { success: false, count: 0, message: 'No student records to import.' };
    }

    let count = 0;
    studentsList.forEach(s => {
      if (!s.name) return; // skip rows without name
      if (!s.id) {
        s.id = this.generateId('STU');
      }
      if (!s.admissionDate) s.admissionDate = new Date().toISOString().split('T')[0];
      if (!s.status) s.status = 'Active';
      if (!s.grade) s.grade = 'Grade 10';
      if (!s.section) s.section = 'A';
      if (!s.gender) s.gender = 'Male';
      if (!s.rollNo) {
        s.rollNo = String(100 + this.data.students.length + 1);
      }
      if (s.phone) {
        s.phone = this.formatWhatsAppNumber(s.phone) ? s.phone : s.phone;
      }

      // Check if student with same ID or same rollNo in same class exists
      const existingIndex = this.data.students.findIndex(ex => 
        (s.id && ex.id === s.id) || 
        (s.rollNo && String(ex.rollNo).trim() === String(s.rollNo).trim() && ex.grade === s.grade)
      );

      if (existingIndex !== -1) {
        this.data.students[existingIndex] = { ...this.data.students[existingIndex], ...s };
      } else {
        this.data.students.unshift(s);
      }
      count++;
    });

    this.save();
    window.dispatchEvent(new CustomEvent('school_db_updated'));
    return { success: true, count };
  },

  deleteStudent(id) {
    if (!this.isAdminAuthenticated()) {
      console.warn('Unauthorized: Admin authorization required to delete student.');
      return false;
    }
    this.data.students = this.data.students.filter(s => s.id !== id);
    // Cascade cleanup or keep historical records
    this.data.fees = this.data.fees.filter(f => f.studentId !== id);
    this.data.marks = this.data.marks.filter(m => m.studentId !== id);
    this.save();
    return true;
  },

  // ==================== TEACHERS ====================
  getTeachers() {
    return [...this.data.teachers];
  },

  getTeacherById(id) {
    return this.data.teachers.find(t => t.id === id);
  },

  saveTeacher(teacher) {
    if (!this.isAdminAuthenticated()) {
      console.warn('Unauthorized: Admin authorization required to save teacher.');
      return null;
    }
    if (!teacher.id) {
      teacher.id = this.generateId('TCH');
      if (!teacher.joinDate) teacher.joinDate = new Date().toISOString().split('T')[0];
      if (!teacher.status) teacher.status = 'Active';
      this.data.teachers.unshift(teacher);
    } else {
      const index = this.data.teachers.findIndex(t => t.id === teacher.id);
      if (index !== -1) {
        this.data.teachers[index] = { ...this.data.teachers[index], ...teacher };
      } else {
        this.data.teachers.unshift(teacher);
      }
    }
    this.save();
    return teacher;
  },

  deleteTeacher(id) {
    if (!this.isAdminAuthenticated()) {
      console.warn('Unauthorized: Admin authorization required to delete teacher.');
      return false;
    }
    this.data.teachers = this.data.teachers.filter(t => t.id !== id);
    // Unassign from classes
    this.data.classes.forEach(c => {
      if (c.teacherId === id) c.teacherId = '';
    });
    this.save();
    return true;
  },

  // ==================== CLASSES & SUBJECTS ====================
  getClasses() {
    return [...this.data.classes];
  },

  getClassById(id) {
    return this.data.classes.find(c => c.id === id);
  },

  saveClass(cls) {
    if (!this.isAdminAuthenticated()) {
      console.warn('Unauthorized: Admin authorization required to save class.');
      return null;
    }
    if (!cls.id) {
      cls.id = this.generateId('CLS');
      this.data.classes.push(cls);
    } else {
      const idx = this.data.classes.findIndex(c => c.id === cls.id);
      if (idx !== -1) this.data.classes[idx] = { ...this.data.classes[idx], ...cls };
    }
    this.save();
    return cls;
  },

  deleteClass(id) {
    if (!this.isAdminAuthenticated()) {
      console.warn('Unauthorized: Admin authorization required to delete class.');
      return false;
    }
    this.data.classes = this.data.classes.filter(c => c.id !== id);
    this.save();
    return true;
  },

  getSubjects() {
    return [...this.data.subjects];
  },

  saveSubject(subj) {
    if (!this.isAdminAuthenticated()) {
      console.warn('Unauthorized: Admin authorization required to save subject.');
      return null;
    }
    if (!subj.code) subj.code = 'SUB-' + Math.floor(100 + Math.random() * 900);
    if (subj.totalMarks === undefined || subj.totalMarks === null || isNaN(Number(subj.totalMarks))) {
      subj.totalMarks = 100;
    } else {
      subj.totalMarks = Math.max(1, Number(subj.totalMarks));
    }
    const idx = this.data.subjects.findIndex(s => s.code === subj.code);
    if (idx !== -1) {
      this.data.subjects[idx] = { ...this.data.subjects[idx], ...subj };
    } else {
      this.data.subjects.push(subj);
    }
    this.save();
    return subj;
  },

  saveSubjectTotalMarksMap(marksMap) {
    if (!this.isAdminAuthenticated()) {
      console.warn('Unauthorized: Admin authorization required to update subject total marks.');
      return false;
    }
    let updatedCount = 0;
    for (const [code, maxVal] of Object.entries(marksMap)) {
      const parsed = Math.max(1, Number(maxVal) || 100);
      const sub = this.data.subjects.find(s => s.code === code);
      if (sub) {
        sub.totalMarks = parsed;
        updatedCount++;
      }
    }
    if (updatedCount > 0) {
      // Recalculate maxMarks and percentage for existing marks records to keep database consistent
      if (this.data.marks && this.data.marks.length) {
        const subMap = {};
        this.data.subjects.forEach(s => subMap[s.code] = Number(s.totalMarks) || 100);

        this.data.marks.forEach(m => {
          if (m.scores && !m.isCombined) {
            let total = 0;
            let maxTotal = 0;
            for (const subCode in m.scores) {
              const scoreVal = Number(m.scores[subCode]) || 0;
              total += scoreVal;
              maxTotal += (subMap[subCode] || 100);
            }
            if (maxTotal > 0) {
              m.totalObtained = total;
              m.maxMarks = maxTotal;
              m.percentage = Math.round((total / maxTotal) * 100);

              let grade = 'F';
              let gpa = 0.0;
              if (m.percentage >= 90) { grade = 'A+'; gpa = 4.0; }
              else if (m.percentage >= 80) { grade = 'A'; gpa = 3.7; }
              else if (m.percentage >= 70) { grade = 'B'; gpa = 3.0; }
              else if (m.percentage >= 60) { grade = 'C'; gpa = 2.0; }
              else if (m.percentage >= 50) { grade = 'D'; gpa = 1.0; }
              m.grade = grade;
              m.gpa = gpa;
            }
          }
        });
      }
      this.save();
    }
    return true;
  },

  deleteSubject(code) {
    if (!this.isAdminAuthenticated()) {
      console.warn('Unauthorized: Admin authorization required to delete subject.');
      return false;
    }
    this.data.subjects = this.data.subjects.filter(s => s.code !== code);
    this.save();
    return true;
  },

  // ==================== ATTENDANCE ====================
  getAttendance(classId, date) {
    return this.data.attendance.find(a => a.classId === classId && a.date === date);
  },

  saveAttendance(classId, date, records) {
    if (!this.isAdminAuthenticated()) {
      console.warn('Unauthorized: Admin authorization required to save attendance.');
      return null;
    }
    let entry = this.data.attendance.find(a => a.classId === classId && a.date === date);
    if (entry) {
      entry.records = records;
      entry.updatedAt = new Date().toISOString();
    } else {
      entry = {
        id: this.generateId('ATT'),
        classId,
        date,
        records,
        createdAt: new Date().toISOString()
      };
      this.data.attendance.push(entry);
    }
    this.save();
    return entry;
  },

  getAttendanceStatsForStudent(studentId) {
    let totalDays = 0;
    let presentDays = 0;
    let lateDays = 0;
    let absentDays = 0;

    this.data.attendance.forEach(record => {
      if (record.records && record.records[studentId]) {
        totalDays++;
        const status = record.records[studentId];
        if (status === 'Present') presentDays++;
        else if (status === 'Late') { lateDays++; presentDays++; }
        else if (status === 'Absent') absentDays++;
      }
    });

    const rate = totalDays > 0 ? Math.round((presentDays / totalDays) * 100) : 100;
    return { totalDays, presentDays, lateDays, absentDays, rate };
  },

  // ==================== EXAMS & MARKS ====================
  normalizeTermName(term) {
    if (!term) return '';
    const t = String(term).toLowerCase().trim();
    if (t.includes('combined')) return 'Combined (1st & 2nd Semester)';
    if (t.includes('1st') || t.includes('first') || t.includes('midterm') || t.includes('semester 1') || t === '1') return '1st Semester';
    if (t.includes('2nd') || t.includes('second') || t.includes('final') || t.includes('semester 2') || t === '2') return '2nd Semester';
    return term;
  },

  getMarks(classId, examTerm) {
    const termNorm = this.normalizeTermName(examTerm);
    if (termNorm === 'Combined (1st & 2nd Semester)') {
      return this.getCombinedMarksList(classId);
    }
    return this.data.marks.filter(m => {
      let match = true;
      if (classId) match = match && m.classId === classId;
      if (examTerm) {
        const mNorm = this.normalizeTermName(m.examTerm);
        match = match && (mNorm === termNorm);
      }
      return match;
    });
  },

  getStudentMarks(studentId) {
    return this.data.marks.filter(m => m.studentId === studentId);
  },

  getStudentMarkByTerm(studentId, examTerm) {
    const termNorm = this.normalizeTermName(examTerm);
    return this.data.marks.find(m => m.studentId === studentId && this.normalizeTermName(m.examTerm) === termNorm);
  },

  getMarkByIdOrCombined(markId) {
    if (!markId) return null;
    if (markId.startsWith('COMB-')) {
      const studentId = markId.replace('COMB-', '');
      const student = this.getStudentById(studentId);
      const sem1 = this.getStudentMarkByTerm(studentId, '1st Semester');
      const sem2 = this.getStudentMarkByTerm(studentId, '2nd Semester');
      return this.computeCombinedMarkRecord(student, sem1, sem2);
    }
    return this.data.marks.find(m => m.id === markId) || null;
  },

  getCombinedMarksList(classId) {
    const students = this.getStudents().filter(s => {
      if (!classId) return true;
      const c = this.getClassById(classId);
      if (!c) return false;
      return s.grade === c.name && s.section === c.section;
    });

    const combinedList = [];
    students.forEach(student => {
      const sem1 = this.getStudentMarkByTerm(student.id, '1st Semester');
      const sem2 = this.getStudentMarkByTerm(student.id, '2nd Semester');

      if (sem1 || sem2) {
        const record = this.computeCombinedMarkRecord(student, sem1, sem2);
        combinedList.push(record);
      }
    });
    return combinedList;
  },

  computeCombinedMarkRecord(student, sem1, sem2) {
    const sem1Obtained = sem1 ? (Number(sem1.totalObtained) || 0) : 0;
    const sem1Max = sem1 ? (Number(sem1.maxMarks) || 0) : 0;
    const sem1Pct = sem1 ? (Number(sem1.percentage) || 0) : 0;
    const sem1Gpa = sem1 ? (Number(sem1.gpa) || 0) : 0;
    const sem1Grade = sem1 ? (sem1.grade || 'F') : '-';

    const sem2Obtained = sem2 ? (Number(sem2.totalObtained) || 0) : 0;
    const sem2Max = sem2 ? (Number(sem2.maxMarks) || 0) : 0;
    const sem2Pct = sem2 ? (Number(sem2.percentage) || 0) : 0;
    const sem2Gpa = sem2 ? (Number(sem2.gpa) || 0) : 0;
    const sem2Grade = sem2 ? (sem2.grade || 'F') : '-';

    const totalObtained = sem1Obtained + sem2Obtained;
    const maxMarks = sem1Max + sem2Max;
    const percentage = maxMarks > 0 ? Math.round((totalObtained / maxMarks) * 100) : 0;

    let grade = 'F';
    let gpa = 0.0;
    if (percentage >= 90) { grade = 'A+'; gpa = 4.0; }
    else if (percentage >= 80) { grade = 'A'; gpa = 3.7; }
    else if (percentage >= 70) { grade = 'B'; gpa = 3.0; }
    else if (percentage >= 60) { grade = 'C'; gpa = 2.0; }
    else if (percentage >= 50) { grade = 'D'; gpa = 1.0; }

    const combinedScores = {};
    const allCodes = new Set([
      ...Object.keys(sem1?.scores || {}),
      ...Object.keys(sem2?.scores || {})
    ]);

    allCodes.forEach(code => {
      const s1 = sem1?.scores && sem1.scores[code] !== undefined ? Number(sem1.scores[code]) : null;
      const s2 = sem2?.scores && sem2.scores[code] !== undefined ? Number(sem2.scores[code]) : null;
      const totalScore = (s1 !== null ? s1 : 0) + (s2 !== null ? s2 : 0);
      const maxScore = (s1 !== null && s2 !== null) ? 200 : 100;
      combinedScores[code] = {
        sem1: s1,
        sem2: s2,
        total: totalScore,
        max: maxScore
      };
    });

    const studentId = student?.id || sem2?.studentId || sem1?.studentId || '';
    const classId = sem2?.classId || sem1?.classId || '';

    return {
      id: `COMB-${studentId}`,
      studentId: studentId,
      classId: classId,
      examTerm: 'Combined (1st & 2nd Semester)',
      isCombined: true,
      sem1: sem1 || null,
      sem2: sem2 || null,
      sem1Obtained,
      sem1Max,
      sem1Percentage: sem1Pct,
      sem1Grade,
      sem1Gpa,
      sem2Obtained,
      sem2Max,
      sem2Percentage: sem2Pct,
      sem2Grade,
      sem2Gpa,
      totalObtained,
      maxMarks,
      percentage,
      grade,
      gpa,
      scores: combinedScores,
      remarks: sem2?.remarks || sem1?.remarks || (percentage >= 50 ? 'Promoted to Next Class with Distinction (کامیاب و ترقی برائے اگلی جماعت).' : 'Needs Academic Improvement (محنت درکار).')
    };
  },

  saveMarks(entry) {
    if (!this.isAdminAuthenticated()) {
      console.warn('Unauthorized: Admin authorization required to save examination marks.');
      return null;
    }
    // Calculate total, percentage, GPA using subjects' configured totalMarks
    const subMap = {};
    this.data.subjects.forEach(s => subMap[s.code] = Number(s.totalMarks) || 100);

    let total = 0;
    let maxMarks = 0;
    for (let sub in entry.scores) {
      const val = Number(entry.scores[sub]) || 0;
      total += val;
      const subMax = subMap[sub] || 100;
      maxMarks += subMax;
    }
    const percentage = maxMarks > 0 ? Math.round((total / maxMarks) * 100) : 0;
    
    let grade = 'F';
    let gpa = 0.0;
    if (percentage >= 90) { grade = 'A+'; gpa = 4.0; }
    else if (percentage >= 80) { grade = 'A'; gpa = 3.7; }
    else if (percentage >= 70) { grade = 'B'; gpa = 3.0; }
    else if (percentage >= 60) { grade = 'C'; gpa = 2.0; }
    else if (percentage >= 50) { grade = 'D'; gpa = 1.0; }

    entry.totalObtained = total;
    entry.maxMarks = maxMarks;
    entry.percentage = percentage;
    entry.grade = grade;
    entry.gpa = gpa;

    entry.examTerm = this.normalizeTermName(entry.examTerm) || entry.examTerm;

    if (!entry.id) {
      // check if record already exists for student + examTerm
      const existing = this.data.marks.find(m => m.studentId === entry.studentId && this.normalizeTermName(m.examTerm) === entry.examTerm);
      if (existing) {
        entry.id = existing.id;
        const idx = this.data.marks.findIndex(m => m.id === existing.id);
        this.data.marks[idx] = { ...this.data.marks[idx], ...entry };
      } else {
        entry.id = this.generateId('MRK');
        this.data.marks.push(entry);
      }
    } else {
      const idx = this.data.marks.findIndex(m => m.id === entry.id);
      if (idx !== -1) {
        this.data.marks[idx] = { ...this.data.marks[idx], ...entry };
      } else {
        this.data.marks.push(entry);
      }
    }
    this.save();
    return entry;
  },

  deleteMarks(id) {
    if (!this.isAdminAuthenticated()) {
      console.warn('Unauthorized: Admin authorization required to delete marks.');
      return false;
    }
    this.data.marks = this.data.marks.filter(m => m.id !== id);
    this.save();
    return true;
  },

  // ==================== FEES ====================
  getFees() {
    return [...this.data.fees];
  },

  saveFee(fee) {
    if (!this.isAdminAuthenticated()) {
      console.warn('Unauthorized: Admin authorization required to save fee invoice.');
      return null;
    }
    fee.amount = Number(fee.amount) || 0;
    fee.paidAmount = Number(fee.paidAmount) || 0;
    
    if (fee.paidAmount >= fee.amount && fee.amount > 0) {
      fee.status = 'Paid';
    } else if (fee.paidAmount > 0) {
      fee.status = 'Partial';
    } else {
      fee.status = 'Pending';
    }

    if (!fee.id) {
      fee.id = this.generateId('INV');
      fee.createdAt = new Date().toISOString().split('T')[0];
      this.data.fees.unshift(fee);
    } else {
      const idx = this.data.fees.findIndex(f => f.id === fee.id);
      if (idx !== -1) {
        this.data.fees[idx] = { ...this.data.fees[idx], ...fee };
      } else {
        this.data.fees.unshift(fee);
      }
    }
    this.save();
    return fee;
  },

  deleteFee(id) {
    if (!this.isAdminAuthenticated()) {
      console.warn('Unauthorized: Admin authorization required to delete fee record.');
      return false;
    }
    this.data.fees = this.data.fees.filter(f => f.id !== id);
    this.save();
    return true;
  },

  // ==================== NOTICES ====================
  getNotices() {
    return [...this.data.notices];
  },

  saveNotice(notice) {
    if (!this.isAdminAuthenticated()) {
      console.warn('Unauthorized: Admin authorization required to post notice.');
      return null;
    }
    if (!notice.id) {
      notice.id = this.generateId('NTC');
      if (!notice.date) notice.date = new Date().toISOString().split('T')[0];
      this.data.notices.unshift(notice);
    } else {
      const idx = this.data.notices.findIndex(n => n.id === notice.id);
      if (idx !== -1) {
        this.data.notices[idx] = { ...this.data.notices[idx], ...notice };
      } else {
        this.data.notices.unshift(notice);
      }
    }
    this.save();
    return notice;
  },

  deleteNotice(id) {
    if (!this.isAdminAuthenticated()) {
      console.warn('Unauthorized: Admin authorization required to delete notice.');
      return false;
    }
    this.data.notices = this.data.notices.filter(n => n.id !== id);
    this.save();
    return true;
  },

  // ==================== STOCK REGISTERS (GENERAL & PTC) ====================
  getDefaultStockGeneral() {
    return [
      {
        id: 'STK-GEN-001',
        itemCode: 'GEN-FURN-01',
        name: 'Student Wooden Dual Desks (طلباء ڈیسک و بینچ)',
        category: 'Furniture',
        date: '2024-04-10',
        quantity: 40,
        unit: 'Pairs',
        unitPrice: 4500,
        totalCost: 180000,
        billNo: 'Inv #1084 / Khyber Wood Works Mardan',
        location: 'Rooms 09 & 10 (10th Class)',
        condition: 'Working',
        remarks: 'Solid shisham wood dual desks with shelf for high classes.'
      },
      {
        id: 'STK-GEN-002',
        itemCode: 'GEN-ELEC-02',
        name: 'Pak Fan 56" Deluxe Ceiling Fans (سیلنگ فینز)',
        category: 'Electrical',
        date: '2024-05-15',
        quantity: 16,
        unit: 'Nos',
        unitPrice: 6200,
        totalCost: 99200,
        billNo: 'Bill #442 / Royal Electric Store Mardan',
        location: 'Classrooms Block A & B',
        condition: 'Working',
        remarks: 'Heavy copper winding with energy-saving capacitors.'
      },
      {
        id: 'STK-GEN-003',
        itemCode: 'GEN-LAB-03',
        name: 'Compound Optical Microscopes 1000x (مائیکروسکوپ لیب)',
        category: 'Laboratory',
        date: '2023-11-20',
        quantity: 6,
        unit: 'Sets',
        unitPrice: 15500,
        totalCost: 93000,
        billNo: 'Bill #781 / Scientific Supplies Peshawar',
        location: 'Biology & Science Lab',
        condition: 'Working',
        remarks: 'Precision optical glass lenses with lockable wooden cases.'
      },
      {
        id: 'STK-GEN-004',
        itemCode: 'GEN-IT-04',
        name: 'Core i5 Desktop Computers with LED (کمپیوٹرز)',
        category: 'IT & Computer',
        date: '2023-09-05',
        quantity: 10,
        unit: 'Sets',
        unitPrice: 42000,
        totalCost: 420000,
        billNo: 'Bill #9021 / Techno Zone Mardan',
        location: 'Computer Lab Room 04',
        condition: 'Working',
        remarks: '8GB RAM, 256GB SSD, keyboards, mice, and 19-inch LED monitors.'
      },
      {
        id: 'STK-GEN-005',
        itemCode: 'GEN-FURN-05',
        name: 'Steel Almirah for Office & Records (اسٹیل الماری)',
        category: 'Furniture',
        date: '2024-02-18',
        quantity: 4,
        unit: 'Nos',
        unitPrice: 18000,
        totalCost: 72000,
        billNo: 'Bill #319 / Gujranwala Steel Works',
        location: 'Principal Office & Exam Cell',
        condition: 'Working',
        remarks: 'Four-shelf gauge 22 steel almirahs with dual central locks.'
      },
      {
        id: 'STK-GEN-006',
        itemCode: 'GEN-SPT-06',
        name: 'Cricket Kits & Sports Gear (کرکٹ کٹس و فٹ بال)',
        category: 'Sports',
        date: '2024-10-01',
        quantity: 4,
        unit: 'Sets',
        unitPrice: 13500,
        totalCost: 54000,
        billNo: 'Bill #1240 / Sialkot Sports House Mardan',
        location: 'Sports & PE Room',
        condition: 'Working',
        remarks: 'English willow bats, batting pads, gloves, stumps, and match footballs.'
      },
      {
        id: 'STK-GEN-007',
        itemCode: 'GEN-ELEC-07',
        name: 'Electric Water Cooler 65L with Filter (واٹر کولر)',
        category: 'Electrical',
        date: '2023-06-12',
        quantity: 2,
        unit: 'Nos',
        unitPrice: 52000,
        totalCost: 104000,
        billNo: 'Bill #653 / Super Asia Center Mardan',
        location: 'Main School Verandah',
        condition: 'Working',
        remarks: 'Stainless steel tank with heavy compressor and 3-stage water filter.'
      }
    ];
  },

  getDefaultStockPTC() {
    return [
      {
        id: 'STK-PTC-001',
        itemCode: 'PTC-2024-01',
        name: 'Magnetic Whiteboards 4x8 ft (مقناطیسی وائٹ بورڈز)',
        releaseYear: '2023 - 2024',
        category: 'Classroom Supplies',
        date: '2024-04-25',
        quantity: 8,
        unit: 'Nos',
        unitPrice: 7200,
        totalCost: 57600,
        billNo: 'PTC Res #04 / Stationers & Co Mardan',
        location: 'Classrooms 6th to 10th',
        condition: 'Working',
        remarks: 'Purchased under PTC Annual Grant 2023-24 resolution.'
      },
      {
        id: 'STK-PTC-002',
        itemCode: 'PTC-2024-02',
        name: 'Solar Hybrid Inverter 3.5kVA with Batteries (سولر سسٹم)',
        releaseYear: '2024 - 2025',
        category: 'Electrical & Solar',
        date: '2024-08-10',
        quantity: 1,
        unit: 'System',
        unitPrice: 245000,
        totalCost: 245000,
        billNo: 'PTC Res #07 / Green Energy Solar Mardan',
        location: 'Administrative Block & Staff Room',
        condition: 'Working',
        remarks: 'Sanctioned by PTC Council for uninterrupted power during load-shedding.'
      },
      {
        id: 'STK-PTC-003',
        itemCode: 'PTC-2024-03',
        name: 'Submersible Water Pump 2HP with Bore Fittings (پانی موٹر)',
        releaseYear: '2023 - 2024',
        category: 'Sanitary & Water',
        date: '2024-05-02',
        quantity: 1,
        unit: 'Unit',
        unitPrice: 48000,
        totalCost: 48000,
        billNo: 'PTC Res #05 / Ittehad Machinery Store',
        location: 'School Water Bore / Tube Well',
        condition: 'Working',
        remarks: 'Emergency resolution passed by parents and teachers for drinking water.'
      },
      {
        id: 'STK-PTC-004',
        itemCode: 'PTC-2024-04',
        name: 'Repair & Plywood Renovation of Student Benches (مرمت بینچز)',
        releaseYear: '2024 - 2025',
        category: 'Furniture Repair',
        date: '2024-09-14',
        quantity: 35,
        unit: 'Desks',
        unitPrice: 1600,
        totalCost: 56000,
        billNo: 'PTC Res #09 / Local Carpenter Zando Dheri',
        location: 'Middle Section Classrooms',
        condition: 'Working',
        remarks: 'Full overhaul of broken student desks with durable plywood and paint.'
      },
      {
        id: 'STK-PTC-005',
        itemCode: 'PTC-2024-05',
        name: 'LED Outdoor Floodlights 100W (فلڈ لائٹس)',
        releaseYear: '2024 - 2025',
        category: 'Electrical & Solar',
        date: '2024-07-20',
        quantity: 6,
        unit: 'Nos',
        unitPrice: 3800,
        totalCost: 22800,
        billNo: 'PTC Res #06 / Bismillah Electric Store',
        location: 'School Boundary Walls & Main Gate',
        condition: 'Working',
        remarks: 'Night security lighting installation on school boundary.'
      },
      {
        id: 'STK-PTC-006',
        itemCode: 'PTC-2024-06',
        name: 'Student Emergency First Aid Medical Kit (طبی امداد باکس)',
        releaseYear: '2023 - 2024',
        category: 'Health & Safety',
        date: '2024-06-05',
        quantity: 2,
        unit: 'Boxes',
        unitPrice: 8500,
        totalCost: 17000,
        billNo: 'PTC Res #08 / Khyber Medicos Mardan',
        location: 'Staff Room & Sports Incharge',
        condition: 'Working',
        remarks: 'Essential medical bandages, antiseptics, and emergency remedies.'
      }
    ];
  },

  getStockItems(type = 'general', category = '', condition = '', query = '', releaseYear = '') {
    const key = type === 'ptc' ? 'stockPTC' : 'stockGeneral';
    let items = Array.isArray(this.data[key]) ? this.data[key] : [];
    
    if (category) {
      items = items.filter(i => (i.category || '').toLowerCase() === category.toLowerCase());
    }
    if (condition) {
      items = items.filter(i => (i.condition || '').toLowerCase() === condition.toLowerCase());
    }
    if (releaseYear && type === 'ptc') {
      const cleanYr = releaseYear.replace(/\s+/g, '').toLowerCase();
      items = items.filter(i => {
        const itemYr = (i.releaseYear || '').replace(/\s+/g, '').toLowerCase();
        return itemYr.includes(cleanYr) || cleanYr.includes(itemYr);
      });
    }
    if (query) {
      const q = query.toLowerCase().trim();
      items = items.filter(i => 
        (i.name && i.name.toLowerCase().includes(q)) ||
        (i.itemCode && i.itemCode.toLowerCase().includes(q)) ||
        (i.category && i.category.toLowerCase().includes(q)) ||
        (i.billNo && i.billNo.toLowerCase().includes(q)) ||
        (i.location && i.location.toLowerCase().includes(q)) ||
        (i.releaseYear && i.releaseYear.toLowerCase().includes(q))
      );
    }
    return [...items];
  },

  getStockItemById(type = 'general', id) {
    const key = type === 'ptc' ? 'stockPTC' : 'stockGeneral';
    const items = Array.isArray(this.data[key]) ? this.data[key] : [];
    return items.find(i => i.id === id);
  },

  saveStockItem(type = 'general', item) {
    if (!this.isAdminAuthenticated()) {
      console.warn('Unauthorized: Admin authorization required to save stock item.');
      return null;
    }
    const key = type === 'ptc' ? 'stockPTC' : 'stockGeneral';
    if (!Array.isArray(this.data[key])) {
      this.data[key] = [];
    }
    
    item.quantity = Number(item.quantity) || 0;
    item.unitPrice = Number(item.unitPrice) || 0;
    item.totalCost = Number(item.totalCost) || (item.quantity * item.unitPrice);
    if (!item.date) item.date = new Date().toISOString().split('T')[0];
    if (!item.condition) item.condition = 'Working';
    if (!item.category) item.category = 'General';
    if (!item.unit) item.unit = 'Nos';
    if (type === 'ptc' && !item.releaseYear) {
      item.releaseYear = '2024 - 2025';
    }

    if (!item.id) {
      const prefix = type === 'ptc' ? 'STK-PTC' : 'STK-GEN';
      item.id = this.generateId(prefix);
      if (!item.itemCode) {
        const count = this.data[key].length + 1;
        item.itemCode = `${type === 'ptc' ? 'PTC' : 'GEN'}-${String(count).padStart(3, '0')}`;
      }
      this.data[key].unshift(item);
    } else {
      const idx = this.data[key].findIndex(i => i.id === item.id);
      if (idx !== -1) {
        this.data[key][idx] = { ...this.data[key][idx], ...item };
      } else {
        this.data[key].unshift(item);
      }
    }
    this.save();
    return item;
  },

  deleteStockItem(type = 'general', id) {
    if (!this.isAdminAuthenticated()) {
      console.warn('Unauthorized: Admin authorization required to delete stock item.');
      return false;
    }
    const key = type === 'ptc' ? 'stockPTC' : 'stockGeneral';
    if (!Array.isArray(this.data[key])) return false;
    this.data[key] = this.data[key].filter(i => i.id !== id);
    this.save();
    return true;
  },

  // ==================== DOCUMENTS & DOWNLOADS MODULE ====================
  // IndexedDB helper for large file payloads (any format, any size)
  idbPromise: null,
  getIdb() {
    if (this.idbPromise) return this.idbPromise;
    this.idbPromise = new Promise((resolve, reject) => {
      if (!window.indexedDB) {
        resolve(null);
        return;
      }
      const request = indexedDB.open('GHS_ZandoDheri_DocStore_v1', 1);
      request.onupgradeneeded = (e) => {
        const db = e.target.result;
        if (!db.objectStoreNames.contains('files')) {
          db.createObjectStore('files', { keyPath: 'id' });
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => {
        console.warn('IndexedDB unavailable, falling back to in-memory/localStorage.');
        resolve(null);
      };
    });
    return this.idbPromise;
  },

  async saveFilePayload(docId, fileData) {
    try {
      const db = await this.getIdb();
      if (db) {
        return new Promise((resolve, reject) => {
          const tx = db.transaction('files', 'readwrite');
          const store = tx.objectStore('files');
          store.put({ id: docId, data: fileData });
          tx.oncomplete = () => resolve(true);
          tx.onerror = () => resolve(false);
        });
      }
    } catch (e) {
      console.warn('IDB write failed, saved in memory state:', e);
    }
    return false;
  },

  async getFilePayload(docId) {
    try {
      const db = await this.getIdb();
      if (db) {
        return new Promise((resolve) => {
          const tx = db.transaction('files', 'readonly');
          const store = tx.objectStore('files');
          const req = store.get(docId);
          req.onsuccess = () => {
            resolve(req.result ? req.result.data : null);
          };
          req.onerror = () => resolve(null);
        });
      }
    } catch (e) {
      console.warn('IDB read failed:', e);
    }
    return null;
  },

  async deleteFilePayload(docId) {
    try {
      const db = await this.getIdb();
      if (db) {
        return new Promise((resolve) => {
          const tx = db.transaction('files', 'readwrite');
          const store = tx.objectStore('files');
          store.delete(docId);
          tx.oncomplete = () => resolve(true);
          tx.onerror = () => resolve(false);
        });
      }
    } catch (e) {
      console.warn('IDB delete failed:', e);
    }
    return false;
  },

  getDefaultDocuments() {
    return [
      {
        id: 'DOC-2025-001',
        title: 'KP School Admission Form 2025-26 (داخلہ فارم)',
        category: 'Admission Forms',
        filename: 'School_Admission_Form_GHS_Zando_Dheri.pdf',
        fileSize: 425600, // ~415 KB
        formattedSize: '415.6 KB',
        fileType: 'application/pdf',
        ext: 'pdf',
        uploadDate: '2025-04-05',
        uploadedBy: 'Headmaster Office',
        description: 'Standard Government Khyber Pakhtunkhwa School Admission Form with parent undertaking and B-Form verification checklist.',
        downloadsCount: 42,
        isSample: true,
        dataUri: 'data:application/pdf;base64,JVBERi0xLjQKJcTl8uXrp/Og0MTGCjQgMCBvYmoKPDwgL0xlbmd0aCA2MCA+Pgogc3RyZWFtCkJUCi9GMSAxMiBUZgoxMDAgNzAwIFRECihoaWdoIHNjaG9vbCB6YW5kbyBkaGVyaSBhZG1pc3Npb24gZm9ybSkKVGgKRVQKZW5kc3RyZWFtCmVuZG9iago='
      },
      {
        id: 'DOC-2025-002',
        title: 'Annual Academic Calendar & Holiday Schedule (تعلیمی کیلنڈر)',
        category: 'Academic Schedule',
        filename: 'Academic_Calendar_2025_2026.pdf',
        fileSize: 285400,
        formattedSize: '278.7 KB',
        fileType: 'application/pdf',
        ext: 'pdf',
        uploadDate: '2025-08-10',
        uploadedBy: 'Controller Exams',
        description: 'Official schedule of 1st & 2nd semester examinations, summer/winter breaks, sports gala, and parent-teacher meetings.',
        downloadsCount: 68,
        isSample: true,
        dataUri: 'data:application/pdf;base64,JVBERi0xLjQKJcTl8uXrp/Og0MTGCjQgMCBvYmoKPDwgL0xlbmd0aCA2MCA+Pgogc3RyZWFtCkJUCi9GMSAxMiBUZgoxMDAgNzAwIFRECihoaWdoIHNjaG9vbCB6YW5kbyBkaGVyaSBjYWxlbmRhcikKVGgKRVQKZW5kc3RyZWFtCmVuZG9iago='
      },
      {
        id: 'DOC-2025-003',
        title: 'PTC Grant Utilization Guidelines & Resolution Proforma (پی ٹی سی رہنمائی)',
        category: 'PTC & Financial',
        filename: 'PTC_Fund_Utilization_Proforma.docx',
        fileSize: 182300,
        formattedSize: '178.0 KB',
        fileType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        ext: 'docx',
        uploadDate: '2024-09-01',
        uploadedBy: 'PTC Secretary',
        description: 'Government KP Elementary & Secondary Education Parent-Teacher Council rules, meeting resolution format, and procurement ceiling.',
        downloadsCount: 19,
        isSample: true,
        dataUri: 'data:application/vnd.openxmlformats-officedocument.wordprocessingml.document;base64,UEsDBBQAAAAIAAAAAAAAAAAAAAAAAAAAAAA='
      },
      {
        id: 'DOC-2025-004',
        title: 'BISE Mardan Matriculation Board Syllabus (بورڈ نصاب 9th و 10th)',
        category: 'Curriculum & Books',
        filename: 'BISE_Mardan_Matric_Syllabus_2025.pdf',
        fileSize: 1250000,
        formattedSize: '1.22 MB',
        fileType: 'application/pdf',
        ext: 'pdf',
        uploadDate: '2025-05-12',
        uploadedBy: 'Science Faculty',
        description: 'Board of Intermediate and Secondary Education Mardan syllabus breakdown for Science & Arts groups (Grades 9th & 10th).',
        downloadsCount: 95,
        isSample: true,
        dataUri: 'data:application/pdf;base64,JVBERi0xLjQKJcTl8uXrp/Og0MTGCjQgMCBvYmoKPDwgL0xlbmd0aCA2MCA+Pgogc3RyZWFtCkJUCi9GMSAxMiBUZgoxMDAgNzAwIFRECihoaWdoIHNjaG9vbCB6YW5kbyBkaGVyaSBzeWxsYWJ1cykKVGgKRVQKZW5kc3RyZWFtCmVuZG9iago='
      },
      {
        id: 'DOC-2025-005',
        title: 'School Fee Voucher & Bank Challan Template (فیس بینک چالان)',
        category: 'Fee & Billing',
        filename: 'School_Fee_Bank_Challan_Sample.xlsx',
        fileSize: 94200,
        formattedSize: '92.0 KB',
        fileType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        ext: 'xlsx',
        uploadDate: '2025-03-20',
        uploadedBy: 'Accountant',
        description: '3-fold printable bank deposit slip (Bank Copy, School Copy, Student Copy) in Excel format.',
        downloadsCount: 31,
        isSample: true,
        dataUri: 'data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,UEsDBBQAAAAIAAAAAAAAAAAAAAAAAAAAAAA='
      }
    ];
  },

  getDocuments(category = '', query = '') {
    let docs = Array.isArray(this.data.documents) ? this.data.documents : [];
    if (category) {
      docs = docs.filter(d => (d.category || '').toLowerCase() === category.toLowerCase());
    }
    if (query) {
      const q = query.toLowerCase().trim();
      docs = docs.filter(d => 
        (d.title && d.title.toLowerCase().includes(q)) ||
        (d.filename && d.filename.toLowerCase().includes(q)) ||
        (d.category && d.category.toLowerCase().includes(q)) ||
        (d.uploadedBy && d.uploadedBy.toLowerCase().includes(q)) ||
        (d.description && d.description.toLowerCase().includes(q)) ||
        (d.ext && d.ext.toLowerCase().includes(q))
      );
    }
    return [...docs];
  },

  getDocumentById(id) {
    const docs = Array.isArray(this.data.documents) ? this.data.documents : [];
    return docs.find(d => d.id === id);
  },

  async saveDocument(doc, filePayload) {
    if (!this.isAdminAuthenticated()) {
      console.warn('Unauthorized: Admin authorization required to upload document.');
      return null;
    }
    if (!Array.isArray(this.data.documents)) {
      this.data.documents = [];
    }

    if (!doc.id) {
      doc.id = this.generateId('DOC');
      doc.uploadDate = doc.uploadDate || new Date().toISOString().split('T')[0];
      doc.downloadsCount = 0;
      doc.uploadedBy = doc.uploadedBy || (this.getAdminProfile().fullName || 'School Admin');

      // If file payload provided, save to IndexedDB or embedded
      if (filePayload) {
        if (filePayload.length > 2000000) {
          // Large payload: save in IndexedDB
          await this.saveFilePayload(doc.id, filePayload);
          doc.hasIdb = true;
        } else {
          // Smaller file: keep dataUri in localStorage record for universal portability
          doc.dataUri = filePayload;
          await this.saveFilePayload(doc.id, filePayload);
        }
      }
      this.data.documents.unshift(doc);
    } else {
      const idx = this.data.documents.findIndex(d => d.id === doc.id);
      if (idx !== -1) {
        if (filePayload) {
          if (filePayload.length > 2000000) {
            await this.saveFilePayload(doc.id, filePayload);
            doc.hasIdb = true;
            delete doc.dataUri;
          } else {
            doc.dataUri = filePayload;
            await this.saveFilePayload(doc.id, filePayload);
          }
        }
        this.data.documents[idx] = { ...this.data.documents[idx], ...doc };
      } else {
        this.data.documents.unshift(doc);
      }
    }

    this.save();
    return doc;
  },

  async deleteDocument(id) {
    if (!this.isAdminAuthenticated()) {
      console.warn('Unauthorized: Admin authorization required to delete document.');
      return false;
    }
    if (!Array.isArray(this.data.documents)) return false;
    this.data.documents = this.data.documents.filter(d => d.id !== id);
    await this.deleteFilePayload(id);
    this.save();
    return true;
  },

  async triggerDocumentDownload(id) {
    const doc = this.getDocumentById(id);
    if (!doc) {
      alert('Document not found.');
      return;
    }

    // Increment download counter
    doc.downloadsCount = (doc.downloadsCount || 0) + 1;
    this.save();

    let dataUri = doc.dataUri;
    if (!dataUri) {
      dataUri = await this.getFilePayload(doc.id);
    }

    if (!dataUri) {
      // Create a fallback downloadable text/memo if binary payload was cleared
      const fallbackContent = `GOVT: HIGH SCHOOL ZANDO DHERI, MARDAN\nDocument: ${doc.title}\nCategory: ${doc.category}\nDate: ${doc.uploadDate}\nUploaded By: ${doc.uploadedBy}\n\nDescription:\n${doc.description || 'Official Document Record'}\n\nOfficial System Generated File Reference: ${doc.filename}`;
      const blob = new Blob([fallbackContent], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = doc.filename || `${doc.title}.txt`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      return;
    }

    // Download from dataUri
    const a = document.createElement('a');
    a.href = dataUri;
    a.download = doc.filename || `${doc.title}.${doc.ext || 'bin'}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  },

  // ==================== FREE TEXT BOOKS (مفت درسی کتب) MODULE ====================
  getDefaultFreeTextBooks() {
    return [
      // 2024 - 2025
      {
        id: 'FTB-2024-001',
        year: '2024 - 2025',
        grade: 'Grade 6',
        bookTitle: 'English Grade 6',
        receivedNew: 125,
        distributedNew: 120,
        collectedOld: 75,
        distributedOld: 70,
        stockOld: 5,
        stockNew: 5,
        balance: 10,
        remarks: 'KP Textbook Board Peshawar'
      },
      {
        id: 'FTB-2024-002',
        year: '2024 - 2025',
        grade: 'Grade 6',
        bookTitle: 'Mathematics (ریاضی)',
        receivedNew: 130,
        distributedNew: 124,
        collectedOld: 80,
        distributedOld: 78,
        stockOld: 2,
        stockNew: 6,
        balance: 8,
        remarks: 'KP Textbook Board Peshawar'
      },
      {
        id: 'FTB-2024-003',
        year: '2024 - 2025',
        grade: 'Grade 6',
        bookTitle: 'General Science (جنرل سائنس)',
        receivedNew: 125,
        distributedNew: 120,
        collectedOld: 70,
        distributedOld: 68,
        stockOld: 2,
        stockNew: 5,
        balance: 7,
        remarks: 'KP Textbook Board Peshawar'
      },
      {
        id: 'FTB-2024-004',
        year: '2024 - 2025',
        grade: 'Grade 6',
        bookTitle: 'Urdu (اردو)',
        receivedNew: 125,
        distributedNew: 122,
        collectedOld: 85,
        distributedOld: 82,
        stockOld: 3,
        stockNew: 3,
        balance: 6,
        remarks: 'KP Textbook Board Peshawar'
      },
      {
        id: 'FTB-2024-005',
        year: '2024 - 2025',
        grade: 'Grade 6',
        bookTitle: 'Islamiyat (اسلامیات)',
        receivedNew: 125,
        distributedNew: 120,
        collectedOld: 90,
        distributedOld: 88,
        stockOld: 2,
        stockNew: 5,
        balance: 7,
        remarks: 'KP Textbook Board Peshawar'
      },
      {
        id: 'FTB-2024-005A',
        year: '2024 - 2025',
        grade: 'Grade 6',
        bookTitle: 'History (تاریخ)',
        receivedNew: 120,
        distributedNew: 115,
        collectedOld: 70,
        distributedOld: 68,
        stockOld: 2,
        stockNew: 5,
        balance: 7,
        remarks: 'Separate Middle Curriculum Subject'
      },
      {
        id: 'FTB-2024-005B',
        year: '2024 - 2025',
        grade: 'Grade 6',
        bookTitle: 'Geography (جغرافیہ)',
        receivedNew: 120,
        distributedNew: 116,
        collectedOld: 68,
        distributedOld: 66,
        stockOld: 2,
        stockNew: 4,
        balance: 6,
        remarks: 'Separate Middle Curriculum Subject'
      },
      {
        id: 'FTB-2024-006',
        year: '2024 - 2025',
        grade: 'Grade 7',
        bookTitle: 'English Grade 7',
        receivedNew: 110,
        distributedNew: 108,
        collectedOld: 65,
        distributedOld: 62,
        stockOld: 3,
        stockNew: 2,
        balance: 5,
        remarks: 'KP Textbook Board Peshawar'
      },
      {
        id: 'FTB-2024-007',
        year: '2024 - 2025',
        grade: 'Grade 7',
        bookTitle: 'Mathematics (ریاضی)',
        receivedNew: 115,
        distributedNew: 110,
        collectedOld: 70,
        distributedOld: 68,
        stockOld: 2,
        stockNew: 5,
        balance: 7,
        remarks: 'KP Textbook Board Peshawar'
      },
      {
        id: 'FTB-2024-008',
        year: '2024 - 2025',
        grade: 'Grade 7',
        bookTitle: 'General Science (جنرل سائنس)',
        receivedNew: 110,
        distributedNew: 106,
        collectedOld: 60,
        distributedOld: 58,
        stockOld: 2,
        stockNew: 4,
        balance: 6,
        remarks: 'KP Textbook Board Peshawar'
      },
      {
        id: 'FTB-2024-009',
        year: '2024 - 2025',
        grade: 'Grade 8',
        bookTitle: 'Mathematics (ریاضی)',
        receivedNew: 105,
        distributedNew: 102,
        collectedOld: 55,
        distributedOld: 52,
        stockOld: 3,
        stockNew: 3,
        balance: 6,
        remarks: 'KP Textbook Board Peshawar'
      },
      {
        id: 'FTB-2024-010',
        year: '2024 - 2025',
        grade: 'Grade 8',
        bookTitle: 'English Grade 8',
        receivedNew: 105,
        distributedNew: 100,
        collectedOld: 50,
        distributedOld: 48,
        stockOld: 2,
        stockNew: 5,
        balance: 7,
        remarks: 'KP Textbook Board Peshawar'
      },
      {
        id: 'FTB-2024-011',
        year: '2024 - 2025',
        grade: 'Grade 9',
        bookTitle: 'Physics (طبیعیات)',
        receivedNew: 95,
        distributedNew: 90,
        collectedOld: 40,
        distributedOld: 38,
        stockOld: 2,
        stockNew: 5,
        balance: 7,
        remarks: 'KP Textbook Board Peshawar'
      },
      {
        id: 'FTB-2024-012',
        year: '2024 - 2025',
        grade: 'Grade 9',
        bookTitle: 'Chemistry (کیمیاء)',
        receivedNew: 95,
        distributedNew: 92,
        collectedOld: 42,
        distributedOld: 40,
        stockOld: 2,
        stockNew: 3,
        balance: 5,
        remarks: 'KP Textbook Board Peshawar'
      },
      {
        id: 'FTB-2024-013',
        year: '2024 - 2025',
        grade: 'Grade 9',
        bookTitle: 'Biology (حیاتیات)',
        receivedNew: 60,
        distributedNew: 58,
        collectedOld: 28,
        distributedOld: 25,
        stockOld: 3,
        stockNew: 2,
        balance: 5,
        remarks: 'KP Textbook Board Peshawar'
      },
      {
        id: 'FTB-2024-014',
        year: '2024 - 2025',
        grade: 'Grade 9',
        bookTitle: 'Computer Science (کمپیوٹر سائنس)',
        receivedNew: 40,
        distributedNew: 38,
        collectedOld: 18,
        distributedOld: 16,
        stockOld: 2,
        stockNew: 2,
        balance: 4,
        remarks: 'KP Textbook Board Peshawar'
      },
      {
        id: 'FTB-2024-014A',
        year: '2024 - 2025',
        grade: 'Grade 9',
        bookTitle: 'Islamiyat (E) (اسلامیات اختیاری)',
        receivedNew: 45,
        distributedNew: 42,
        collectedOld: 20,
        distributedOld: 18,
        stockOld: 2,
        stockNew: 3,
        balance: 5,
        remarks: 'Elective Arts Subject'
      },
      {
        id: 'FTB-2024-015',
        year: '2024 - 2025',
        grade: 'Grade 10',
        bookTitle: 'Mathematics (ریاضی دہم)',
        receivedNew: 90,
        distributedNew: 88,
        collectedOld: 45,
        distributedOld: 44,
        stockOld: 1,
        stockNew: 2,
        balance: 3,
        remarks: 'KP Textbook Board Peshawar'
      },
      {
        id: 'FTB-2024-016',
        year: '2024 - 2025',
        grade: 'Grade 10',
        bookTitle: 'English Grade 10',
        receivedNew: 90,
        distributedNew: 87,
        collectedOld: 50,
        distributedOld: 48,
        stockOld: 2,
        stockNew: 3,
        balance: 5,
        remarks: 'KP Textbook Board Peshawar'
      },
      {
        id: 'FTB-2024-017',
        year: '2024 - 2025',
        grade: 'Grade 10',
        bookTitle: 'Pakistan Studies (مطالعہ پاکستان)',
        receivedNew: 90,
        distributedNew: 89,
        collectedOld: 55,
        distributedOld: 53,
        stockOld: 2,
        stockNew: 1,
        balance: 3,
        remarks: 'KP Textbook Board Peshawar'
      },
      // 2023 - 2024
      {
        id: 'FTB-2023-001',
        year: '2023 - 2024',
        grade: 'Grade 6',
        bookTitle: 'English Grade 6',
        receivedNew: 120,
        distributedNew: 118,
        collectedOld: 70,
        distributedOld: 68,
        stockOld: 2,
        stockNew: 2,
        balance: 4,
        remarks: 'KP Textbook Board Peshawar'
      },
      {
        id: 'FTB-2023-002',
        year: '2023 - 2024',
        grade: 'Grade 6',
        bookTitle: 'Mathematics (ریاضی)',
        receivedNew: 125,
        distributedNew: 123,
        collectedOld: 75,
        distributedOld: 72,
        stockOld: 3,
        stockNew: 2,
        balance: 5,
        remarks: 'KP Textbook Board Peshawar'
      },
      {
        id: 'FTB-2023-003',
        year: '2023 - 2024',
        grade: 'Grade 9',
        bookTitle: 'Physics (طبیعیات)',
        receivedNew: 90,
        distributedNew: 88,
        collectedOld: 35,
        distributedOld: 34,
        stockOld: 1,
        stockNew: 2,
        balance: 3,
        remarks: 'KP Textbook Board Peshawar'
      },
      {
        id: 'FTB-2023-004',
        year: '2023 - 2024',
        grade: 'Grade 10',
        bookTitle: 'English Grade 10',
        receivedNew: 85,
        distributedNew: 84,
        collectedOld: 45,
        distributedOld: 43,
        stockOld: 2,
        stockNew: 1,
        balance: 3,
        remarks: 'KP Textbook Board Peshawar'
      },
      // 2022 - 2023
      {
        id: 'FTB-2022-001',
        year: '2022 - 2023',
        grade: 'Grade 6',
        bookTitle: 'General Science (جنرل سائنس)',
        receivedNew: 110,
        distributedNew: 108,
        collectedOld: 60,
        distributedOld: 59,
        stockOld: 1,
        stockNew: 2,
        balance: 3,
        remarks: 'KP Textbook Board Peshawar'
      },
      {
        id: 'FTB-2022-002',
        year: '2022 - 2023',
        grade: 'Grade 10',
        bookTitle: 'Mathematics (ریاضی دہم)',
        receivedNew: 80,
        distributedNew: 80,
        collectedOld: 40,
        distributedOld: 39,
        stockOld: 1,
        stockNew: 0,
        balance: 1,
        remarks: 'KP Textbook Board Peshawar'
      },
      // 2020 - 2021
      {
        id: 'FTB-2020-001',
        year: '2020 - 2021',
        grade: 'Grade 6',
        bookTitle: 'Urdu (اردو)',
        receivedNew: 100,
        distributedNew: 100,
        collectedOld: 50,
        distributedOld: 49,
        stockOld: 1,
        stockNew: 0,
        balance: 1,
        remarks: 'KP Textbook Board Peshawar'
      },
      // 2018 - 2019
      {
        id: 'FTB-2018-001',
        year: '2018 - 2019',
        grade: 'Grade 6',
        bookTitle: 'Mathematics (ریاضی)',
        receivedNew: 95,
        distributedNew: 95,
        collectedOld: 45,
        distributedOld: 45,
        stockOld: 0,
        stockNew: 0,
        balance: 0,
        remarks: 'Archive register'
      },
      // 2015 - 2016
      {
        id: 'FTB-2015-001',
        year: '2015 - 2016',
        grade: 'Grade 9',
        bookTitle: 'General Science / Physics',
        receivedNew: 80,
        distributedNew: 80,
        collectedOld: 30,
        distributedOld: 30,
        stockOld: 0,
        stockNew: 0,
        balance: 0,
        remarks: 'Archive register'
      },
      // 2012 - 2013
      {
        id: 'FTB-2012-001',
        year: '2012 - 2013',
        grade: 'Grade 6',
        bookTitle: 'English Grade 6',
        receivedNew: 85,
        distributedNew: 85,
        collectedOld: 35,
        distributedOld: 35,
        stockOld: 0,
        stockNew: 0,
        balance: 0,
        remarks: 'Historical baseline year 2012'
      }
    ];
  },

  getFreeTextBooks(filterYear = '', filterGrade = '', query = '') {
    let books = Array.isArray(this.data.freeTextBooks) ? this.data.freeTextBooks : [];
    if (filterYear) {
      books = books.filter(b => (b.year || '').trim() === filterYear.trim());
    }
    if (filterGrade) {
      books = books.filter(b => (b.grade || '').trim().toLowerCase() === filterGrade.trim().toLowerCase());
    }
    if (query) {
      const q = query.toLowerCase().trim();
      books = books.filter(b => 
        (b.bookTitle || '').toLowerCase().includes(q) ||
        (b.grade || '').toLowerCase().includes(q) ||
        (b.year || '').toLowerCase().includes(q) ||
        (b.remarks || '').toLowerCase().includes(q)
      );
    }
    return books;
  },

  getFreeTextBookById(id) {
    const books = Array.isArray(this.data.freeTextBooks) ? this.data.freeTextBooks : [];
    return books.find(b => b.id === id);
  },

  saveFreeTextBook(book) {
    if (!this.isAdminAuthenticated()) {
      console.warn('Unauthorized: Admin authorization required to save Free Text Book.');
      return null;
    }
    if (!Array.isArray(this.data.freeTextBooks)) {
      this.data.freeTextBooks = [];
    }

    const receivedNew = Number(book.receivedNew) || 0;
    const distributedNew = Number(book.distributedNew) || 0;
    const collectedOld = Number(book.collectedOld) || 0;
    const distributedOld = Number(book.distributedOld) || 0;
    const stockNew = book.stockNew !== undefined && book.stockNew !== '' ? Number(book.stockNew) : Math.max(0, receivedNew - distributedNew);
    const stockOld = book.stockOld !== undefined && book.stockOld !== '' ? Number(book.stockOld) : Math.max(0, collectedOld - distributedOld);
    const balance = book.balance !== undefined && book.balance !== '' ? Number(book.balance) : (stockNew + stockOld);

    const bookData = {
      ...book,
      receivedNew,
      distributedNew,
      collectedOld,
      distributedOld,
      stockNew,
      stockOld,
      balance,
      updatedAt: new Date().toISOString()
    };

    if (!bookData.id) {
      const yStr = (bookData.year || '2024').slice(0, 4);
      const count = this.data.freeTextBooks.length + 1;
      bookData.id = `FTB-${yStr}-${String(count).padStart(3, '0')}`;
      this.data.freeTextBooks.unshift(bookData);
    } else {
      const idx = this.data.freeTextBooks.findIndex(b => b.id === bookData.id);
      if (idx !== -1) {
        this.data.freeTextBooks[idx] = { ...this.data.freeTextBooks[idx], ...bookData };
      } else {
        this.data.freeTextBooks.unshift(bookData);
      }
    }
    this.save();
    return bookData;
  },

  deleteFreeTextBook(id) {
    if (!this.isAdminAuthenticated()) {
      console.warn('Unauthorized: Admin authorization required to delete Free Text Book.');
      return false;
    }
    if (!Array.isArray(this.data.freeTextBooks)) return false;
    this.data.freeTextBooks = this.data.freeTextBooks.filter(b => b.id !== id);
    this.save();
    return true;
  },

  importFreeTextBooks(books) {
    if (!this.isAdminAuthenticated()) {
      return { success: false, message: 'Admin authentication required to import Free Text Books.' };
    }
    if (!Array.isArray(books) || !books.length) {
      return { success: false, message: 'No valid book records provided for import.' };
    }
    if (!Array.isArray(this.data.freeTextBooks)) {
      this.data.freeTextBooks = [];
    }

    let importedCount = 0;
    books.forEach((b) => {
      const year = (b.year || '2024 - 2025').trim();
      const grade = (b.grade || 'Grade 6').trim();
      const bookTitle = (b.bookTitle || '').trim();
      if (!bookTitle) return;

      const receivedNew = Number(b.receivedNew) || 0;
      const distributedNew = Number(b.distributedNew) || 0;
      const collectedOld = Number(b.collectedOld) || 0;
      const distributedOld = Number(b.distributedOld) || 0;
      const stockNew = b.stockNew !== undefined && b.stockNew !== '' ? Number(b.stockNew) : Math.max(0, receivedNew - distributedNew);
      const stockOld = b.stockOld !== undefined && b.stockOld !== '' ? Number(b.stockOld) : Math.max(0, collectedOld - distributedOld);
      const balance = b.balance !== undefined && b.balance !== '' ? Number(b.balance) : (stockNew + stockOld);
      const remarks = (b.remarks || '').trim();

      const yStr = year.slice(0, 4);
      const id = b.id || `FTB-${yStr}-${String(this.data.freeTextBooks.length + 1).padStart(3, '0')}`;

      // Check if duplicate ID or matching book in same year and grade
      const existingIdx = this.data.freeTextBooks.findIndex(item => 
        (item.id && item.id === id) || 
        (item.year === year && item.grade.toLowerCase() === grade.toLowerCase() && item.bookTitle.toLowerCase() === bookTitle.toLowerCase())
      );

      const record = {
        id,
        year,
        grade,
        bookTitle,
        receivedNew,
        distributedNew,
        collectedOld,
        distributedOld,
        stockNew,
        stockOld,
        balance,
        remarks,
        updatedAt: new Date().toISOString()
      };

      if (existingIdx !== -1) {
        this.data.freeTextBooks[existingIdx] = { ...this.data.freeTextBooks[existingIdx], ...record };
      } else {
        this.data.freeTextBooks.unshift(record);
      }
      importedCount++;
    });

    this.save();
    return { success: true, count: importedCount };
  },

  // ==================== ADMISSION & WITHDRAWAL REGISTERS (MIDDLE & HIGH) ====================
  getAdmWithdrawals(type = 'middle', query = '', grade = '', status = '') {
    const key = type === 'high' ? 'admWithdrawalHigh' : 'admWithdrawalMiddle';
    let list = Array.isArray(this.data[key]) ? this.data[key] : [];
    if (grade) {
      list = list.filter(r => (r.grade || '').trim() === grade.trim());
    }
    if (status) {
      list = list.filter(r => (r.status || '').toLowerCase() === status.toLowerCase());
    }
    if (query) {
      const q = query.toLowerCase().trim();
      list = list.filter(r => 
        (r.admissionNo || '').toLowerCase().includes(q) ||
        (r.studentName || '').toLowerCase().includes(q) ||
        (r.fatherName || '').toLowerCase().includes(q) ||
        (r.caste || '').toLowerCase().includes(q) ||
        (r.occupation || '').toLowerCase().includes(q) ||
        (r.residence || '').toLowerCase().includes(q) ||
        (r.prevSchool || '').toLowerCase().includes(q) ||
        (r.slcNo || '').toLowerCase().includes(q) ||
        (r.remarks || '').toLowerCase().includes(q)
      );
    }
    return list;
  },

  getAdmWithdrawalById(type = 'middle', id) {
    const key = type === 'high' ? 'admWithdrawalHigh' : 'admWithdrawalMiddle';
    const list = Array.isArray(this.data[key]) ? this.data[key] : [];
    return list.find(r => r.id === id);
  },

  saveAdmWithdrawal(type = 'middle', record) {
    if (!this.isAdminAuthenticated()) {
      console.warn('Unauthorized: Admin authorization required to save Admission Withdrawal entry.');
      return null;
    }
    const key = type === 'high' ? 'admWithdrawalHigh' : 'admWithdrawalMiddle';
    if (!Array.isArray(this.data[key])) {
      this.data[key] = [];
    }

    const prefix = type === 'high' ? 'AWH' : 'AWM';
    if (!record.id) {
      const count = this.data[key].length + 1;
      record.id = `${prefix}-${String(count).padStart(4, '0')}`;
    }
    if (!record.status) {
      record.status = record.withdrawalDate ? 'Struck Off' : 'Active';
    }

    const dataObj = {
      ...record,
      updatedAt: new Date().toISOString()
    };

    const idx = this.data[key].findIndex(r => r.id === dataObj.id);
    if (idx !== -1) {
      this.data[key][idx] = { ...this.data[key][idx], ...dataObj };
    } else {
      this.data[key].unshift(dataObj);
    }

    this.save();
    return dataObj;
  },

  deleteAdmWithdrawal(type = 'middle', id) {
    if (!this.isAdminAuthenticated()) {
      console.warn('Unauthorized: Admin authorization required to delete Admission Withdrawal entry.');
      return false;
    }
    const key = type === 'high' ? 'admWithdrawalHigh' : 'admWithdrawalMiddle';
    if (!Array.isArray(this.data[key])) return false;
    this.data[key] = this.data[key].filter(r => r.id !== id);
    this.save();
    return true;
  },

  importAdmWithdrawals(type = 'middle', records) {
    if (!this.isAdminAuthenticated()) {
      return { success: false, message: 'Admin authorization required to import records.' };
    }
    if (!Array.isArray(records) || !records.length) {
      return { success: false, message: 'No valid records to import.' };
    }
    const key = type === 'high' ? 'admWithdrawalHigh' : 'admWithdrawalMiddle';
    if (!Array.isArray(this.data[key])) {
      this.data[key] = [];
    }

    const prefix = type === 'high' ? 'AWH' : 'AWM';
    let importedCount = 0;

    records.forEach(r => {
      const studentName = (r.studentName || '').trim();
      if (!studentName) return;

      const admissionNo = (r.admissionNo || '').trim() || String(this.data[key].length + 1);
      const id = r.id || `${prefix}-${String(this.data[key].length + 1).padStart(4, '0')}`;

      const existingIdx = this.data[key].findIndex(item => 
        (item.id && item.id === id) || 
        (item.admissionNo && item.admissionNo === admissionNo)
      );

      const recordObj = {
        id,
        admissionNo,
        admissionDate: r.admissionDate || new Date().toISOString().split('T')[0],
        studentName,
        fatherName: r.fatherName || '',
        caste: r.caste || '',
        occupation: r.occupation || '',
        residence: r.residence || 'Zando Dheri, Mardan',
        dob: r.dob || '',
        dobWords: r.dobWords || '',
        prevSchool: r.prevSchool || '',
        classAdmitted: r.classAdmitted || (type === 'high' ? 'Grade 9' : 'Grade 6'),
        withdrawalDate: r.withdrawalDate || '',
        classWithdrawn: r.classWithdrawn || '',
        withdrawalReason: r.withdrawalReason || '',
        slcNo: r.slcNo || '',
        conduct: r.conduct || 'Good',
        status: r.status || (r.withdrawalDate ? 'Struck Off' : 'Active'),
        remarks: r.remarks || '',
        updatedAt: new Date().toISOString()
      };

      if (existingIdx !== -1) {
        this.data[key][existingIdx] = { ...this.data[key][existingIdx], ...recordObj };
      } else {
        this.data[key].unshift(recordObj);
      }
      importedCount++;
    });

    this.save();
    return { success: true, count: importedCount };
  },

  getDefaultAdmWithdrawal(type = 'middle') {
    if (type === 'middle') {
      return [
        {
          id: 'AWM-0001',
          admissionNo: '142',
          admissionDate: '2023-04-10',
          studentName: 'Muhammad Salman',
          fatherName: 'Noor Muhammad',
          caste: 'Yousafzai',
          occupation: 'Farmer (زمیندار)',
          residence: 'Zando Dheri, Mardan',
          dob: '2011-03-15',
          dobWords: 'Fifteenth March Two Thousand Eleven',
          prevSchool: 'GPS Zando Dheri (پرائمری اسکول زاندو ڈھیری)',
          classAdmitted: 'Grade 6',
          withdrawalDate: '',
          classWithdrawn: '',
          withdrawalReason: '',
          slcNo: '',
          conduct: 'Good (نیک چلن)',
          status: 'Active',
          remarks: 'B-Form verified, Primary Certificate Attached'
        },
        {
          id: 'AWM-0002',
          admissionNo: '143',
          admissionDate: '2023-04-12',
          studentName: 'Zubair Ahmad',
          fatherName: 'Ahmad Jan',
          caste: 'Khattak',
          occupation: 'Government Servant (سرکاری ملازم)',
          residence: 'Chamtar Road, Zando Dheri',
          dob: '2010-09-20',
          dobWords: 'Twentieth September Two Thousand Ten',
          prevSchool: 'GPS Chamtar Mardan',
          classAdmitted: 'Grade 6',
          withdrawalDate: '',
          classWithdrawn: '',
          withdrawalReason: '',
          slcNo: '',
          conduct: 'Good',
          status: 'Active',
          remarks: 'Regular student'
        },
        {
          id: 'AWM-0003',
          admissionNo: '144',
          admissionDate: '2022-04-05',
          studentName: 'Kamran Khan',
          fatherName: 'Gulzar Khan',
          caste: 'Mohmand',
          occupation: 'Shopkeeper (دکاندار)',
          residence: 'Zando Dheri, Mardan',
          dob: '2009-11-10',
          dobWords: 'Tenth November Two Thousand Nine',
          prevSchool: 'GMS Rustam Mardan',
          classAdmitted: 'Grade 7',
          withdrawalDate: '2024-03-31',
          classWithdrawn: 'Grade 8',
          withdrawalReason: 'Passed Middle Standard Exam / Promoted to High School',
          slcNo: 'SLC-MID-2024-88',
          conduct: 'Excellent (بہترین)',
          status: 'Struck Off',
          remarks: 'Middle exam passed with distinction'
        }
      ];
    } else {
      return [
        {
          id: 'AWH-0001',
          admissionNo: '815',
          admissionDate: '2024-04-15',
          studentName: 'Muhammad Tariq Khan',
          fatherName: 'Abdul Qayyum',
          caste: 'Yousafzai',
          occupation: 'Business (کاروبار)',
          residence: 'Zando Dheri, Mardan',
          dob: '2009-04-12',
          dobWords: 'Twelfth April Two Thousand Nine',
          prevSchool: 'GHS Zando Dheri (Middle Section)',
          classAdmitted: 'Grade 9',
          withdrawalDate: '',
          classWithdrawn: '',
          withdrawalReason: '',
          slcNo: '',
          conduct: 'Good (نیک چلن)',
          status: 'Active',
          remarks: 'Science Group (Bio), SSC-I enrolled'
        },
        {
          id: 'AWH-0002',
          admissionNo: '816',
          admissionDate: '2024-04-16',
          studentName: 'Sajid Ahmad',
          fatherName: 'Farhad Ali',
          caste: 'Awan',
          occupation: 'Labourer (مزدور)',
          residence: 'Kashmir Colony, Zando Dheri',
          dob: '2009-08-20',
          dobWords: 'Twentieth August Two Thousand Nine',
          prevSchool: 'GHS Zando Dheri (Middle Section)',
          classAdmitted: 'Grade 9',
          withdrawalDate: '',
          classWithdrawn: '',
          withdrawalReason: '',
          slcNo: '',
          conduct: 'Good',
          status: 'Active',
          remarks: 'Orphan student, Fee Concession Granted'
        },
        {
          id: 'AWH-0003',
          admissionNo: '817',
          admissionDate: '2023-04-10',
          studentName: 'Bilal Khan',
          fatherName: 'Mumtaz Ali',
          caste: 'Yousafzai',
          occupation: 'Farmer (زمیندار)',
          residence: 'Zando Dheri, Mardan',
          dob: '2008-01-05',
          dobWords: 'Fifth January Two Thousand Eight',
          prevSchool: 'GHS Zando Dheri (Middle Section)',
          classAdmitted: 'Grade 9',
          withdrawalDate: '2025-05-10',
          classWithdrawn: 'Grade 10',
          withdrawalReason: 'Passed SSC Annual Examination BISE Mardan',
          slcNo: 'SLC-HIGH-2025-412',
          conduct: 'Exemplary (شاندار)',
          status: 'Struck Off',
          remarks: 'BISE Mardan Roll No 182941, Passed with Grade A'
        }
      ];
    }
  },

  // ==================== SEED DATA GENERATOR ====================
  seed() {
    this.data.settings = {
      schoolName: 'GOVT: HIGH SCHOOL KASS KOROONA, MARDAN',
      emisCode: '35567',
      tagline: 'Excellence in Education & Character (تعلیم و تربیت کا معتبر ادارہ)',
      address: 'Kass Koroona, Mardan, Khyber Pakhtunkhwa, Pakistan',
      phone: '+92 937 000000',
      email: 'ghs.kasskoroona@schools.kp.gov.pk',
      academicYear: '2025 - 2026',
      currency: 'Rs. '
    };

    this.data.admin = {
      username: 'admin',
      password: 'password123',
      fullName: 'Principal / Headmaster (پرنسپل / ہیڈ ماسٹر)',
      role: 'Administrator'
    };

    this.data.teachers = [
      {
        id: 'TCH-101',
        name: 'Dr. Arthur Vance',
        fatherName: 'Muhammad Vance',
        designation: 'Subject Specialist (SS) Maths',
        bps: 'BPS-17',
        qualification: 'Ph.D. in Applied Mathematics',
        personalNo: '00389101',
        cnic: '16101-2345671-1',
        salaryAccount: '0342001928374',
        bankCode: '0342',
        bankName: 'National Bank of Pakistan (NBP)',
        gender: 'Male',
        phone: '0300-9371001',
        email: 'a.vance@schools.kp.gov.pk',
        joinDate: '2020-08-15',
        status: 'Active'
      },
      {
        id: 'TCH-102',
        name: 'Prof. Eleanor Reed',
        fatherName: 'Abdul Hameed Reed',
        designation: 'Secondary School Teacher - SST (Physics)',
        bps: 'BPS-16',
        qualification: 'M.Sc. Physics (Cambridge)',
        personalNo: '00389102',
        cnic: '16101-3456782-2',
        salaryAccount: '0342001928375',
        bankCode: '0342',
        bankName: 'National Bank of Pakistan (NBP)',
        gender: 'Female',
        phone: '0301-9371002',
        email: 'e.reed@schools.kp.gov.pk',
        joinDate: '2021-01-10',
        status: 'Active'
      },
      {
        id: 'TCH-103',
        name: 'Mr. Marcus Brody',
        fatherName: 'Gulzar Ahmad Brody',
        designation: 'Secondary School Teacher - SST (English)',
        bps: 'BPS-16',
        qualification: 'M.A. English Language',
        personalNo: '00389103',
        cnic: '16101-4567893-3',
        salaryAccount: '0342001928376',
        bankCode: '0342',
        bankName: 'National Bank of Pakistan (NBP)',
        gender: 'Male',
        phone: '0302-9371003',
        email: 'm.brody@schools.kp.gov.pk',
        joinDate: '2019-09-01',
        status: 'Active'
      },
      {
        id: 'TCH-104',
        name: 'Ms. Sophia Martinez',
        fatherName: 'Noor Muhammad Martinez',
        designation: 'Secondary School Teacher - SST (IT)',
        bps: 'BPS-16',
        qualification: 'B.Tech in Computer Science',
        personalNo: '00389104',
        cnic: '16101-5678904-4',
        salaryAccount: '0342001928377',
        bankCode: '0342',
        bankName: 'National Bank of Pakistan (NBP)',
        gender: 'Female',
        phone: '0303-9371004',
        email: 's.martinez@schools.kp.gov.pk',
        joinDate: '2022-03-20',
        status: 'Active'
      },
      {
        id: 'TCH-105',
        name: 'Mr. David Chen',
        fatherName: 'Haji Chen Badshah',
        designation: 'Secondary School Teacher - SST (Bio/Chem)',
        bps: 'BPS-16',
        qualification: 'M.Sc. Chemistry & General Science',
        personalNo: '00389105',
        cnic: '16101-6789015-5',
        salaryAccount: '0342001928378',
        bankCode: '0342',
        bankName: 'National Bank of Pakistan (NBP)',
        gender: 'Male',
        phone: '0304-9371005',
        email: 'd.chen@schools.kp.gov.pk',
        joinDate: '2021-08-10',
        status: 'Active'
      },
      {
        id: 'TCH-106',
        name: 'Qari Abdul Rehman',
        fatherName: 'Hafiz Shams-ur-Rehman',
        designation: 'Theology Teacher (TT)',
        bps: 'BPS-15',
        qualification: 'M.A. Islamic Studies, Shahadat-ul-Almiya',
        personalNo: '00389106',
        cnic: '16101-7890126-6',
        salaryAccount: '0342001928379',
        bankCode: '0342',
        bankName: 'National Bank of Pakistan (NBP)',
        gender: 'Male',
        phone: '0305-9371006',
        email: 'a.rehman@schools.kp.gov.pk',
        joinDate: '2021-04-10',
        status: 'Active'
      },
      {
        id: 'TCH-107',
        name: 'Mr. Ahmad Khan',
        fatherName: 'Sher Afzal Khan',
        designation: 'Certified Teacher (CT)',
        bps: 'BPS-15',
        qualification: 'M.A. Urdu & Pashto Literature',
        personalNo: '00389107',
        cnic: '16101-8901237-7',
        salaryAccount: '0342001928380',
        bankCode: '0342',
        bankName: 'National Bank of Pakistan (NBP)',
        gender: 'Male',
        phone: '0306-9371007',
        email: 'a.khan@schools.kp.gov.pk',
        joinDate: '2020-09-01',
        status: 'Active'
      },
      {
        id: 'TCH-108',
        name: 'Mr. Tariq Mehmood',
        fatherName: 'Fazal Mehmood',
        designation: 'Secondary School Teacher - SST (General)',
        bps: 'BPS-16',
        qualification: 'M.Sc. Geography & History',
        personalNo: '00389108',
        cnic: '16101-9012348-8',
        salaryAccount: '0342001928381',
        bankCode: '0342',
        bankName: 'National Bank of Pakistan (NBP)',
        gender: 'Male',
        phone: '0307-9371008',
        email: 't.mehmood@schools.kp.gov.pk',
        joinDate: '2021-06-15',
        status: 'Active'
      },
      {
        id: 'TCH-109',
        name: 'Coach Bilal Shah',
        fatherName: 'Sayed Anwar Shah',
        designation: 'Physical Education Teacher (PET)',
        bps: 'BPS-15',
        qualification: 'BS Physical Education & Sports',
        personalNo: '00389109',
        cnic: '16101-0123459-9',
        salaryAccount: '0342001928382',
        bankCode: '0342',
        bankName: 'National Bank of Pakistan (NBP)',
        gender: 'Male',
        phone: '0308-9371009',
        email: 'b.shah@schools.kp.gov.pk',
        joinDate: '2022-01-20',
        status: 'Active'
      },
      {
        id: 'TCH-110',
        name: 'Ms. Ayesha Noor',
        fatherName: 'Muhammad Noor Jan',
        designation: 'Drawing Master (DM)',
        bps: 'BPS-15',
        qualification: 'B.F.A. Fine Arts',
        personalNo: '00389110',
        cnic: '16101-1234560-0',
        salaryAccount: '0342001928383',
        bankCode: '0342',
        bankName: 'National Bank of Pakistan (NBP)',
        gender: 'Female',
        phone: '0309-9371010',
        email: 'a.noor@schools.kp.gov.pk',
        joinDate: '2022-08-01',
        status: 'Active'
      }
    ];

    this.data.classes = [
      // Grade 6: Sections A, B, C, D
      { id: 'CLS-6A',  name: 'Grade 6',  section: 'A', room: 'Room 01', teacherId: 'TCH-103', capacity: 40 },
      { id: 'CLS-6B',  name: 'Grade 6',  section: 'B', room: 'Room 02', teacherId: 'TCH-107', capacity: 40 },
      { id: 'CLS-6C',  name: 'Grade 6',  section: 'C', room: 'Room 03', teacherId: 'TCH-108', capacity: 40 },
      { id: 'CLS-6D',  name: 'Grade 6',  section: 'D', room: 'Room 04', teacherId: 'TCH-109', capacity: 40 },
      // Grade 7: Sections A, B, C, D
      { id: 'CLS-7A',  name: 'Grade 7',  section: 'A', room: 'Room 05', teacherId: 'TCH-108', capacity: 40 },
      { id: 'CLS-7B',  name: 'Grade 7',  section: 'B', room: 'Room 06', teacherId: 'TCH-109', capacity: 40 },
      { id: 'CLS-7C',  name: 'Grade 7',  section: 'C', room: 'Room 07', teacherId: 'TCH-105', capacity: 40 },
      { id: 'CLS-7D',  name: 'Grade 7',  section: 'D', room: 'Room 08', teacherId: 'TCH-110', capacity: 40 },
      // Grade 8: Sections A, B, C, D
      { id: 'CLS-8A',  name: 'Grade 8',  section: 'A', room: 'Room 09', teacherId: 'TCH-105', capacity: 40 },
      { id: 'CLS-8B',  name: 'Grade 8',  section: 'B', room: 'Room 10', teacherId: 'TCH-110', capacity: 40 },
      { id: 'CLS-8C',  name: 'Grade 8',  section: 'C', room: 'Room 11', teacherId: 'TCH-101', capacity: 40 },
      { id: 'CLS-8D',  name: 'Grade 8',  section: 'D', room: 'Room 12', teacherId: 'TCH-106', capacity: 40 },
      // Grade 9: Sections A, B, C
      { id: 'CLS-9A',  name: 'Grade 9',  section: 'A', room: 'Lab 1',   teacherId: 'TCH-102', capacity: 40 }, // Science Group
      { id: 'CLS-9B',  name: 'Grade 9',  section: 'B', room: 'Room 13', teacherId: 'TCH-106', capacity: 40 }, // Arts Group
      { id: 'CLS-9C',  name: 'Grade 9',  section: 'C', room: 'Room 14', teacherId: 'TCH-107', capacity: 40 }, // Arts Group
      // Grade 10: Sections A, B, C
      { id: 'CLS-10A', name: 'Grade 10', section: 'A', room: 'Lab 2',   teacherId: 'TCH-101', capacity: 40 }, // Science Group
      { id: 'CLS-10B', name: 'Grade 10', section: 'B', room: 'Room 15', teacherId: 'TCH-108', capacity: 40 }, // Arts Group
      { id: 'CLS-10C', name: 'Grade 10', section: 'C', room: 'Room 16', teacherId: 'TCH-109', capacity: 40 }, // Arts Group
      // Grade 11: Sections A, B
      { id: 'CLS-11A', name: 'Grade 11', section: 'A', room: 'College Block 1', teacherId: 'TCH-102', capacity: 40 },
      { id: 'CLS-11B', name: 'Grade 11', section: 'B', room: 'College Block 2', teacherId: 'TCH-101', capacity: 40 },
      // Grade 12: Sections A, B
      { id: 'CLS-12A', name: 'Grade 12', section: 'A', room: 'College Block 3', teacherId: 'TCH-105', capacity: 40 },
      { id: 'CLS-12B', name: 'Grade 12', section: 'B', room: 'College Block 4', teacherId: 'TCH-104', capacity: 40 }
    ];

    // 31 Comprehensive Curriculum Subjects:
    // 1. Middle Section (Grades 6th, 7th, 8th - All Sections) -> 13 Subjects
    // 2. Secondary Science Section (Grades 9th & 10th - Section A) -> 9 Subjects
    // 3. Secondary Arts / General Section (Grades 9th B, 9th C, 10th B, 10th C) -> 9 Subjects
    this.data.subjectsSchemaVersion = 2;
    this.data.subjects = [
      // --- Group 1: 6th, 7th, 8th (All Sections) [13 Subjects] ---
      { code: 'MID-ENG', name: 'English (انگریزی)', grade: 'Grades 6th, 7th, 8th (All Sections)', teacherId: 'TCH-103', totalMarks: 100 },
      { code: 'MID-URD', name: 'Urdu (اردو)', grade: 'Grades 6th, 7th, 8th (All Sections)', teacherId: 'TCH-107', totalMarks: 100 },
      { code: 'MID-MTH', name: 'Maths (ریاضی)', grade: 'Grades 6th, 7th, 8th (All Sections)', teacherId: 'TCH-101', totalMarks: 100 },
      { code: 'MID-GSC', name: 'G.Science (جنرل سائنس)', grade: 'Grades 6th, 7th, 8th (All Sections)', teacherId: 'TCH-105', totalMarks: 100 },
      { code: 'MID-ISL', name: 'Islamiyat (اسلامیات)', grade: 'Grades 6th, 7th, 8th (All Sections)', teacherId: 'TCH-106', totalMarks: 100 },
      { code: 'MID-MQR', name: 'Mutalea Quran (مطالعہ قرآن حکیم)', grade: 'Grades 6th, 7th, 8th (All Sections)', teacherId: 'TCH-106', totalMarks: 100 },
      { code: 'MID-HIS', name: 'History (تاریخ)', grade: 'Grades 6th, 7th, 8th (All Sections)', teacherId: 'TCH-108', totalMarks: 100 },
      { code: 'MID-GEO', name: 'Geography (جغرافیہ)', grade: 'Grades 6th, 7th, 8th (All Sections)', teacherId: 'TCH-108', totalMarks: 100 },
      { code: 'MID-HPE', name: 'HPE (صحت و جسمانی تعلیم)', grade: 'Grades 6th, 7th, 8th (All Sections)', teacherId: 'TCH-109', totalMarks: 100 },
      { code: 'MID-ARB', name: 'Arabic (عربی)', grade: 'Grades 6th, 7th, 8th (All Sections)', teacherId: 'TCH-106', totalMarks: 100 },
      { code: 'MID-CS',  name: 'Computer (کمپیوٹر)', grade: 'Grades 6th, 7th, 8th (All Sections)', teacherId: 'TCH-104', totalMarks: 100 },
      { code: 'MID-DRW', name: 'Drawing (ڈرائنگ)', grade: 'Grades 6th, 7th, 8th (All Sections)', teacherId: 'TCH-110', totalMarks: 100 },
      { code: 'MID-PAS', name: 'Pashto (پشتو)', grade: 'Grades 6th, 7th, 8th (All Sections)', teacherId: 'TCH-107', totalMarks: 100 },

      // --- Group 2: 9th & 10th Section A (Science Group) [9 Subjects] ---
      { code: 'SCI-ENG',  name: 'English (انگریزی)', grade: 'Grades 9th & 10th (Section A - Science)', teacherId: 'TCH-103', totalMarks: 100 },
      { code: 'SCI-URD',  name: 'Urdu (اردو)', grade: 'Grades 9th & 10th (Section A - Science)', teacherId: 'TCH-107', totalMarks: 100 },
      { code: 'SCI-MTH',  name: 'Maths (ریاضی)', grade: 'Grades 9th & 10th (Section A - Science)', teacherId: 'TCH-101', totalMarks: 100 },
      { code: 'SCI-ISLC', name: 'Islamiyat (C) (اسلامیات لازمی)', grade: 'Grades 9th & 10th (Section A - Science)', teacherId: 'TCH-106', totalMarks: 100 },
      { code: 'SCI-PKS',  name: 'Pak. Studies (مطالعہ پاکستان)', grade: 'Grades 9th & 10th (Section A - Science)', teacherId: 'TCH-108', totalMarks: 100 },
      { code: 'SCI-BIO',  name: 'Biology (بیالوجی)', grade: 'Grades 9th & 10th (Section A - Science)', teacherId: 'TCH-105', totalMarks: 100 },
      { code: 'SCI-PHY',  name: 'Physics (فزکس)', grade: 'Grades 9th & 10th (Section A - Science)', teacherId: 'TCH-102', totalMarks: 100 },
      { code: 'SCI-CHM',  name: 'Chemistry (کیمسٹری)', grade: 'Grades 9th & 10th (Section A - Science)', teacherId: 'TCH-105', totalMarks: 100 },
      { code: 'SCI-MQR',  name: 'Mutalea Quran (مطالعہ قرآن حکیم)', grade: 'Grades 9th & 10th (Section A - Science)', teacherId: 'TCH-106', totalMarks: 100 },

      // --- Group 3: 9th B, 9th C and 10th B, 10th C (Arts / General Group) [9 Subjects] ---
      { code: 'ART-ENG',  name: 'English (انگریزی)', grade: 'Grades 9th & 10th (Sec B & C - Arts)', teacherId: 'TCH-103', totalMarks: 100 },
      { code: 'ART-URD',  name: 'Urdu (اردو)', grade: 'Grades 9th & 10th (Sec B & C - Arts)', teacherId: 'TCH-107', totalMarks: 100 },
      { code: 'ART-GMTH', name: 'G.Maths (جنرل ریاضی)', grade: 'Grades 9th & 10th (Sec B & C - Arts)', teacherId: 'TCH-101', totalMarks: 100 },
      { code: 'ART-ISLC', name: 'Islamiyat (C) (اسلامیات لازمی)', grade: 'Grades 9th & 10th (Sec B & C - Arts)', teacherId: 'TCH-106', totalMarks: 100 },
      { code: 'ART-PKS',  name: 'Pak. Studies (مطالعہ پاکستان)', grade: 'Grades 9th & 10th (Sec B & C - Arts)', teacherId: 'TCH-108', totalMarks: 100 },
      { code: 'ART-ISLE', name: 'Islamiyat (E) (اسلامیات اختیاری)', grade: 'Grades 9th & 10th (Sec B & C - Arts)', teacherId: 'TCH-106', totalMarks: 100 },
      { code: 'ART-PAS',  name: 'Pashto (پشتو)', grade: 'Grades 9th & 10th (Sec B & C - Arts)', teacherId: 'TCH-107', totalMarks: 100 },
      { code: 'ART-DRW',  name: 'Drawing (ڈرائنگ)', grade: 'Grades 9th & 10th (Sec B & C - Arts)', teacherId: 'TCH-110', totalMarks: 100 },
      { code: 'ART-MQR',  name: 'Mutalea Quran (مطالعہ قرآن حکیم)', grade: 'Grades 9th & 10th (Sec B & C - Arts)', teacherId: 'TCH-106', totalMarks: 100 }
    ];

    this.data.students = [
      {
        id: 'STU-1001',
        rollNo: '10A-01',
        name: 'Muhammad Usman',
        gender: 'Male',
        dob: '2009-04-12',
        grade: 'Grade 10',
        section: 'A',
        guardian: 'Tariq Mehmood',
        phone: '0300-8811001',
        email: 'usman.t@student.edu',
        address: 'Zando Dheri, Mardan',
        status: 'Active',
        admissionDate: '2023-08-20'
      },
      {
        id: 'STU-1002',
        rollNo: '10A-02',
        name: 'Ayesha Bibi',
        gender: 'Female',
        dob: '2009-08-25',
        grade: 'Grade 10',
        section: 'A',
        guardian: 'Fazal Rehman',
        phone: '0301-8811002',
        email: 'ayesha.f@student.edu',
        address: 'Zando Dheri, Mardan',
        status: 'Active',
        admissionDate: '2023-08-20'
      },
      {
        id: 'STU-1003',
        rollNo: '10A-03',
        name: 'Hamza Khan',
        gender: 'Male',
        dob: '2008-11-30',
        grade: 'Grade 10',
        section: 'A',
        guardian: 'Sardar Khan',
        phone: '0302-8811003',
        email: 'hamza.k@student.edu',
        address: 'Main Road, Zando Dheri, Mardan',
        status: 'Active',
        admissionDate: '2023-08-22'
      },
      {
        id: 'STU-1004',
        rollNo: '10A-04',
        name: 'Fatima Noor',
        gender: 'Female',
        dob: '2009-02-14',
        grade: 'Grade 10',
        section: 'A',
        guardian: 'Noor Muhammad',
        phone: '0303-8811004',
        email: 'fatima.n@student.edu',
        address: 'Near Govt High School, Zando Dheri',
        status: 'Active',
        admissionDate: '2023-08-22'
      },
      {
        id: 'STU-1005',
        rollNo: '10A-05',
        name: 'Bilal Ahmad',
        gender: 'Male',
        dob: '2009-06-18',
        grade: 'Grade 10',
        section: 'A',
        guardian: 'Ahmad Jan',
        phone: '0304-8811005',
        email: 'bilal.a@student.edu',
        address: 'Zando Dheri, Mardan',
        status: 'Active',
        admissionDate: '2023-08-25'
      },
      {
        id: 'STU-1006',
        rollNo: '10B-01',
        name: 'Zainab Bibi',
        gender: 'Female',
        dob: '2009-07-09',
        grade: 'Grade 10',
        section: 'B',
        guardian: 'Zahid Hussain',
        phone: '0305-8811006',
        email: 'zainab.z@student.edu',
        address: 'Zando Dheri, Mardan',
        status: 'Active',
        admissionDate: '2023-08-26'
      },
      {
        id: 'STU-1007',
        rollNo: '9A-01',
        name: 'Umar Farooq',
        gender: 'Male',
        dob: '2010-01-20',
        grade: 'Grade 9',
        section: 'A',
        guardian: 'Farooq Ahmad',
        phone: '0306-8811007',
        email: 'umar.f@student.edu',
        address: 'Zando Dheri, Mardan',
        status: 'Active',
        admissionDate: '2024-08-18'
      },
      {
        id: 'STU-1008',
        rollNo: '11A-01',
        name: 'Sana Gul',
        gender: 'Female',
        dob: '2008-05-11',
        grade: 'Grade 11',
        section: 'A',
        guardian: 'Gul Muhammad',
        phone: '0307-8811008',
        email: 'sana.g@student.edu',
        address: 'Zando Dheri, Mardan',
        status: 'Active',
        admissionDate: '2022-08-15'
      }
    ];

    // Today's & Past Attendance Seed
    const todayStr = new Date().toISOString().split('T')[0];
    this.data.attendance = [
      {
        id: 'ATT-202501',
        classId: 'CLS-10A',
        date: todayStr,
        records: {
          'STU-1001': 'Present',
          'STU-1002': 'Present',
          'STU-1003': 'Late',
          'STU-1004': 'Present',
          'STU-1005': 'Absent'
        },
        createdAt: todayStr
      }
    ];

    // Seed Marks & Exam Records (Aligned with Grade 10 Section A - Science Group)
    this.data.marks = [
      // --- 1st Semester ---
      {
        id: 'MRK-501',
        studentId: 'STU-1001',
        classId: 'CLS-10A',
        examTerm: '1st Semester',
        scores: {
          'SCI-ENG': 88, 'SCI-URD': 92, 'SCI-MTH': 95, 'SCI-ISLC': 94, 'SCI-PKS': 90,
          'SCI-BIO': 91, 'SCI-PHY': 89, 'SCI-CHM': 93, 'SCI-MQR': 98
        },
        totalObtained: 840,
        maxMarks: 900,
        percentage: 93,
        grade: 'A+',
        gpa: 4.0,
        remarks: 'Outstanding analytical skills and steady performance across all coursework.'
      },
      {
        id: 'MRK-502',
        studentId: 'STU-1002',
        classId: 'CLS-10A',
        examTerm: '1st Semester',
        scores: {
          'SCI-ENG': 95, 'SCI-URD': 90, 'SCI-MTH': 82, 'SCI-ISLC': 91, 'SCI-PKS': 88,
          'SCI-BIO': 89, 'SCI-PHY': 84, 'SCI-CHM': 85, 'SCI-MQR': 94
        },
        totalObtained: 798,
        maxMarks: 900,
        percentage: 89,
        grade: 'A',
        gpa: 3.7,
        remarks: 'Excellent in Languages, Mutalea Quran and strong all-around grasp.'
      },
      {
        id: 'MRK-503',
        studentId: 'STU-1003',
        classId: 'CLS-10A',
        examTerm: '1st Semester',
        scores: {
          'SCI-ENG': 78, 'SCI-URD': 80, 'SCI-MTH': 75, 'SCI-ISLC': 85, 'SCI-PKS': 74,
          'SCI-BIO': 76, 'SCI-PHY': 72, 'SCI-CHM': 70, 'SCI-MQR': 86
        },
        totalObtained: 696,
        maxMarks: 900,
        percentage: 77,
        grade: 'B',
        gpa: 3.0,
        remarks: 'Consistent effort; can focus more on mathematics and physical sciences.'
      },
      {
        id: 'MRK-504',
        studentId: 'STU-1004',
        classId: 'CLS-10A',
        examTerm: '1st Semester',
        scores: {
          'SCI-ENG': 86, 'SCI-URD': 89, 'SCI-MTH': 82, 'SCI-ISLC': 88, 'SCI-PKS': 85,
          'SCI-BIO': 85, 'SCI-PHY': 80, 'SCI-CHM': 82, 'SCI-MQR': 93
        },
        totalObtained: 770,
        maxMarks: 900,
        percentage: 86,
        grade: 'A',
        gpa: 3.7,
        remarks: 'Pleasant attitude and consistent effort throughout 1st semester.'
      },
      {
        id: 'MRK-505',
        studentId: 'STU-1005',
        classId: 'CLS-10A',
        examTerm: '1st Semester',
        scores: {
          'SCI-ENG': 70, 'SCI-URD': 72, 'SCI-MTH': 66, 'SCI-ISLC': 78, 'SCI-PKS': 70,
          'SCI-BIO': 70, 'SCI-PHY': 65, 'SCI-CHM': 64, 'SCI-MQR': 80
        },
        totalObtained: 635,
        maxMarks: 900,
        percentage: 71,
        grade: 'B',
        gpa: 3.0,
        remarks: 'Satisfactory foundation; can aim higher with diligent study.'
      },

      // --- 2nd Semester ---
      {
        id: 'MRK-601',
        studentId: 'STU-1001',
        classId: 'CLS-10A',
        examTerm: '2nd Semester',
        scores: {
          'SCI-ENG': 91, 'SCI-URD': 93, 'SCI-MTH': 96, 'SCI-ISLC': 95, 'SCI-PKS': 92,
          'SCI-BIO': 94, 'SCI-PHY': 90, 'SCI-CHM': 95, 'SCI-MQR': 99
        },
        totalObtained: 845,
        maxMarks: 900,
        percentage: 94,
        grade: 'A+',
        gpa: 4.0,
        remarks: 'Maintained stellar academic excellence. Promoted to Next Class with Distinction.'
      },
      {
        id: 'MRK-602',
        studentId: 'STU-1002',
        classId: 'CLS-10A',
        examTerm: '2nd Semester',
        scores: {
          'SCI-ENG': 93, 'SCI-URD': 91, 'SCI-MTH': 85, 'SCI-ISLC': 92, 'SCI-PKS': 89,
          'SCI-BIO': 90, 'SCI-PHY': 86, 'SCI-CHM': 87, 'SCI-MQR': 96
        },
        totalObtained: 809,
        maxMarks: 900,
        percentage: 90,
        grade: 'A+',
        gpa: 4.0,
        remarks: 'Superb dedication and remarkable grasp of languages and natural sciences.'
      },
      {
        id: 'MRK-603',
        studentId: 'STU-1003',
        classId: 'CLS-10A',
        examTerm: '2nd Semester',
        scores: {
          'SCI-ENG': 82, 'SCI-URD': 83, 'SCI-MTH': 77, 'SCI-ISLC': 86, 'SCI-PKS': 78,
          'SCI-BIO': 80, 'SCI-PHY': 75, 'SCI-CHM': 74, 'SCI-MQR': 89
        },
        totalObtained: 724,
        maxMarks: 900,
        percentage: 80,
        grade: 'A',
        gpa: 3.7,
        remarks: 'Significant improvement in mathematics and general coursework.'
      },
      {
        id: 'MRK-604',
        studentId: 'STU-1004',
        classId: 'CLS-10A',
        examTerm: '2nd Semester',
        scores: {
          'SCI-ENG': 88, 'SCI-URD': 90, 'SCI-MTH': 84, 'SCI-ISLC': 90, 'SCI-PKS': 86,
          'SCI-BIO': 87, 'SCI-PHY': 82, 'SCI-CHM': 83, 'SCI-MQR': 94
        },
        totalObtained: 784,
        maxMarks: 900,
        percentage: 87,
        grade: 'A',
        gpa: 3.7,
        remarks: 'Consistent hard work and highly commendable academic progress.'
      },
      {
        id: 'MRK-605',
        studentId: 'STU-1005',
        classId: 'CLS-10A',
        examTerm: '2nd Semester',
        scores: {
          'SCI-ENG': 74, 'SCI-URD': 76, 'SCI-MTH': 70, 'SCI-ISLC': 80, 'SCI-PKS': 72,
          'SCI-BIO': 74, 'SCI-PHY': 68, 'SCI-CHM': 67, 'SCI-MQR': 82
        },
        totalObtained: 663,
        maxMarks: 900,
        percentage: 74,
        grade: 'B',
        gpa: 3.0,
        remarks: 'Good overall performance; advised to concentrate on science labs.'
      }
    ];

    // Seed Fees
    this.data.fees = [
      {
        id: 'INV-2025-001',
        studentId: 'STU-1001',
        feeType: 'Tuition Fee - Term 1',
        amount: 1200,
        paidAmount: 1200,
        dueDate: '2025-09-15',
        paidDate: '2025-09-10',
        status: 'Paid',
        method: 'Bank Transfer'
      },
      {
        id: 'INV-2025-002',
        studentId: 'STU-1002',
        feeType: 'Tuition Fee - Term 1',
        amount: 1200,
        paidAmount: 600,
        dueDate: '2025-09-15',
        paidDate: '2025-09-12',
        status: 'Partial',
        method: 'Card'
      },
      {
        id: 'INV-2025-003',
        studentId: 'STU-1003',
        feeType: 'Tuition Fee - Term 1',
        amount: 1200,
        paidAmount: 0,
        dueDate: '2025-09-15',
        paidDate: '',
        status: 'Pending',
        method: 'Cash'
      },
      {
        id: 'INV-2025-004',
        studentId: 'STU-1004',
        feeType: 'Science Laboratory Fee',
        amount: 250,
        paidAmount: 250,
        dueDate: '2025-10-01',
        paidDate: '2025-09-28',
        status: 'Paid',
        method: 'Online Banking'
      },
      {
        id: 'INV-2025-005',
        studentId: 'STU-1005',
        feeType: 'Sports & Transportation',
        amount: 350,
        paidAmount: 350,
        dueDate: '2025-10-05',
        paidDate: '2025-10-02',
        status: 'Paid',
        method: 'Cheque'
      }
    ];

    // Seed Notices
    this.data.notices = [
      {
        id: 'NTC-301',
        title: 'Annual Science Exhibition 2025',
        date: '2025-10-15',
        audience: 'All',
        priority: 'Important',
        content: 'The school science fair will take place in the auditorium on October 25th. All students participating must submit their project outlines by Friday.'
      },
      {
        id: 'NTC-302',
        title: 'Term 1 Parent-Teacher Conferences',
        date: '2025-10-08',
        audience: 'Students',
        priority: 'Urgent',
        content: 'Individual conference sessions will be held on Saturday from 9:00 AM to 3:00 PM. Report cards and attendance sheets will be reviewed.'
      },
      {
        id: 'NTC-303',
        title: 'Staff Curriculum Coordination Meeting',
        date: '2025-10-02',
        audience: 'Teachers',
        priority: 'Normal',
        content: 'All faculty members are requested to join the monthly planning assembly in the Conference Hall this Thursday at 3:30 PM.'
      }
    ];

    // Seed Stock Registers
    this.data.stockGeneral = this.getDefaultStockGeneral();
    this.data.stockPTC = this.getDefaultStockPTC();
    this.data.freeTextBooks = this.getDefaultFreeTextBooks();
  }
};

// Initialize DB immediately on load
SchoolDB.init();

// ====================================================================
// CloudSync: Multi-Device Realtime Cloud Synchronization Engine
// Compatible with Firebase Realtime Database REST API & offline-first merging
// ====================================================================
const CloudSync = {
  config: {
    enabled: false,
    provider: 'firebase',
    firebaseUrl: '',
    syncKey: '',
    autoSync: true,
    lastSyncTime: null
  },
  _debounceTimer: null,
  _isSyncing: false,

  init() {
    try {
      const stored = localStorage.getItem(DB_KEY + '_cloud_sync_config');
      if (stored) {
        this.config = Object.assign(this.config, JSON.parse(stored));
      }
    } catch (e) {
      console.warn('Could not load cloud sync config:', e);
    }

    window.addEventListener('online', () => {
      this.updateNetworkUI(true);
      if (this.config.enabled && this.config.autoSync) {
        this.debounceSync(1500);
      }
    });

    window.addEventListener('offline', () => {
      this.updateNetworkUI(false);
    });

    this.updateNetworkUI(navigator.onLine);

    if (navigator.onLine && this.config.enabled && this.config.autoSync) {
      setTimeout(() => this.sync(), 3000);
    }
  },

  saveConfig(newConfig = {}) {
    this.config = Object.assign(this.config, newConfig);
    try {
      localStorage.setItem(DB_KEY + '_cloud_sync_config', JSON.stringify(this.config));
    } catch (e) {}
    this.updateNetworkUI(navigator.onLine);
  },

  debounceSync(delay = 2000) {
    if (this._debounceTimer) clearTimeout(this._debounceTimer);
    this._debounceTimer = setTimeout(() => {
      this.sync();
    }, delay);
  },

  async sync() {
    if (this._isSyncing) return { success: false, reason: 'already_syncing' };
    if (!this.config.enabled || !navigator.onLine) {
      this.updateNetworkUI(navigator.onLine);
      return { success: false, reason: 'offline_or_disabled' };
    }

    this._isSyncing = true;
    this.setSyncingState(true);

    try {
      if (this.config.firebaseUrl && this.config.firebaseUrl.trim()) {
        const result = await this.syncWithFirebase();
        this._isSyncing = false;
        this.setSyncingState(false, 'success');
        return result;
      } else {
        this._isSyncing = false;
        this.setSyncingState(false, 'idle');
        return { success: false, reason: 'no_url_configured' };
      }
    } catch (err) {
      console.error('Cloud Sync failed:', err);
      this._isSyncing = false;
      this.setSyncingState(false, 'error');
      return { success: false, error: err.message };
    }
  },

  async syncWithFirebase() {
    let baseUrl = this.config.firebaseUrl.trim().replace(/\/+$/, '');
    if (!baseUrl.startsWith('http://') && !baseUrl.startsWith('https://')) {
      baseUrl = 'https://' + baseUrl;
    }
    const cleanKey = DB_KEY.replace(/[^a-zA-Z0-9_-]/g, '_');
    const authParam = this.config.syncKey && this.config.syncKey.trim() ? `?auth=${encodeURIComponent(this.config.syncKey.trim())}` : '';
    const endpoint = `${baseUrl}/${cleanKey}.json${authParam}`;

    // 1. Fetch remote state
    const res = await fetch(endpoint, { method: 'GET' });
    if (!res.ok) {
      throw new Error(`Firebase returned ${res.status}: ${res.statusText}`);
    }
    const remoteData = await res.json();

    if (!remoteData || typeof remoteData !== 'object') {
      // Remote database is fresh or empty; push current local data
      await this.pushToFirebase();
      this.config.lastSyncTime = new Date().toISOString();
      this.saveConfig();
      return { success: true, action: 'initial_push' };
    }

    // 2. Intelligent merge of local and remote data
    const merged = this.mergeData(SchoolDB.data, remoteData);
    SchoolDB.data = merged;
    localStorage.setItem(DB_KEY, JSON.stringify(SchoolDB.data));
    window.dispatchEvent(new CustomEvent('school_db_updated', { detail: SchoolDB.data }));

    // 3. Push merged state back to Firebase
    await fetch(endpoint, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(merged)
    });

    this.config.lastSyncTime = new Date().toISOString();
    this.saveConfig();
    return { success: true, action: 'merged' };
  },

  async pushToFirebase() {
    let baseUrl = this.config.firebaseUrl.trim().replace(/\/+$/, '');
    if (!baseUrl.startsWith('http://') && !baseUrl.startsWith('https://')) {
      baseUrl = 'https://' + baseUrl;
    }
    const cleanKey = DB_KEY.replace(/[^a-zA-Z0-9_-]/g, '_');
    const authParam = this.config.syncKey && this.config.syncKey.trim() ? `?auth=${encodeURIComponent(this.config.syncKey.trim())}` : '';
    const endpoint = `${baseUrl}/${cleanKey}.json${authParam}`;

    const res = await fetch(endpoint, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(SchoolDB.data)
    });
    if (!res.ok) {
      throw new Error(`Push failed (${res.status}): ${res.statusText}`);
    }
    this.config.lastSyncTime = new Date().toISOString();
    this.saveConfig();
    return { success: true };
  },

  async pullFromFirebase() {
    let baseUrl = this.config.firebaseUrl.trim().replace(/\/+$/, '');
    if (!baseUrl.startsWith('http://') && !baseUrl.startsWith('https://')) {
      baseUrl = 'https://' + baseUrl;
    }
    const cleanKey = DB_KEY.replace(/[^a-zA-Z0-9_-]/g, '_');
    const authParam = this.config.syncKey && this.config.syncKey.trim() ? `?auth=${encodeURIComponent(this.config.syncKey.trim())}` : '';
    const endpoint = `${baseUrl}/${cleanKey}.json${authParam}`;

    const res = await fetch(endpoint, { method: 'GET' });
    if (!res.ok) throw new Error(`Pull failed: ${res.statusText}`);
    const remoteData = await res.json();
    if (!remoteData || typeof remoteData !== 'object') {
      throw new Error('Remote database is empty.');
    }
    SchoolDB.data = remoteData;
    SchoolDB.ensureCollections();
    SchoolDB.save();
    this.config.lastSyncTime = new Date().toISOString();
    this.saveConfig();
    return { success: true };
  },

  mergeData(local = {}, remote = {}) {
    const mergeArray = (localArr = [], remoteArr = [], idProp = 'id') => {
      const map = new Map();
      (remoteArr || []).forEach(item => {
        if (item && item[idProp] !== undefined) map.set(String(item[idProp]), item);
      });
      (localArr || []).forEach(item => {
        if (item && item[idProp] !== undefined) {
          const key = String(item[idProp]);
          const existing = map.get(key);
          if (!existing) {
            map.set(key, item);
          } else {
            const localTime = new Date(item.updatedAt || item.createdAt || 0).getTime();
            const remoteTime = new Date(existing.updatedAt || existing.createdAt || 0).getTime();
            map.set(key, localTime >= remoteTime ? item : existing);
          }
        }
      });
      return Array.from(map.values());
    };

    return {
      settings: Object.assign({}, remote.settings || {}, local.settings || {}),
      students: mergeArray(local.students, remote.students, 'id'),
      teachers: mergeArray(local.teachers, remote.teachers, 'id'),
      classes: mergeArray(local.classes, remote.classes, 'id'),
      subjects: mergeArray(local.subjects, remote.subjects, 'code'),
      attendance: mergeArray(local.attendance, remote.attendance, 'id'),
      marks: mergeArray(local.marks, remote.marks, 'id'),
      fees: mergeArray(local.fees, remote.fees, 'id'),
      stockGeneral: mergeArray(local.stockGeneral, remote.stockGeneral, 'id'),
      stockPTC: mergeArray(local.stockPTC, remote.stockPTC, 'id'),
      freeBooks: mergeArray(local.freeBooks, remote.freeBooks, 'id'),
      notices: mergeArray(local.notices, remote.notices, 'id'),
      admWithdrawalsMiddle: mergeArray(local.admWithdrawalsMiddle, remote.admWithdrawalsMiddle, 'id'),
      admWithdrawalsHigh: mergeArray(local.admWithdrawalsHigh, remote.admWithdrawalsHigh, 'id'),
      adminCredentials: local.adminCredentials || remote.adminCredentials
    };
  },

  updateNetworkUI(isOnline) {
    const badge = document.getElementById('network-status-badge');
    const dot = document.getElementById('network-dot');
    const text = document.getElementById('network-status-text');
    if (!badge || !dot || !text) return;

    if (!isOnline) {
      dot.style.background = '#94a3b8';
      text.textContent = 'Offline (آف لائن)';
      badge.title = 'Device is Offline. All changes are securely saved in local storage.';
      badge.style.borderColor = '#cbd5e1';
      badge.style.background = '#f8fafc';
    } else if (this.config.enabled && this.config.firebaseUrl) {
      dot.style.background = '#10b981';
      text.textContent = 'Cloud Synced (کلاؤڈ سنک)';
      badge.title = 'Online & Connected to Cloud Database across all devices.';
      badge.style.borderColor = '#86efac';
      badge.style.background = '#f0fdf4';
    } else {
      dot.style.background = '#3b82f6';
      text.textContent = 'Online (آن لائن)';
      badge.title = 'Device is Online. Click to configure Multi-Device Cloud Sync.';
      badge.style.borderColor = '#bfdbfe';
      badge.style.background = '#eff6ff';
    }
  },

  setSyncingState(isSyncing, status = 'idle') {
    const dot = document.getElementById('network-dot');
    const text = document.getElementById('network-status-text');
    if (!dot || !text) return;

    if (isSyncing) {
      dot.style.background = '#f59e0b';
      text.textContent = 'Syncing... (سنک جاری ہے)';
    } else if (status === 'success') {
      dot.style.background = '#10b981';
      text.textContent = 'Synced (محفوظ)';
      setTimeout(() => this.updateNetworkUI(navigator.onLine), 3000);
    } else if (status === 'error') {
      dot.style.background = '#ef4444';
      text.textContent = 'Sync Issue (دوبارہ کوشش)';
      setTimeout(() => this.updateNetworkUI(navigator.onLine), 4000);
    } else {
      this.updateNetworkUI(navigator.onLine);
    }
  }
};

// Initialize CloudSync
CloudSync.init();

