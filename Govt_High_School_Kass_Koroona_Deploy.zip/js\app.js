/**
 * School Management Database - Application Controller
 * Handles UI interactions, view switching, modal operations, and CRUD event handling.
 */

const App = {
  currentView: 'dashboard',
  isAdminLoggedIn: false,

  init() {
    this.checkAdminSession();
    this.initPWA();
    this.bindNavigation();
    this.bindGlobalEvents();
    this.bindSearchAndFilters();
    this.bindModals();
    this.syncBranding();
    this.renderCurrentView();
    this.updateDashboardCounters();
    this.updateAdminUI();

    // Listen for database changes to keep UI synchronized
    window.addEventListener('school_db_updated', () => {
      this.syncBranding();
      this.updateDashboardCounters();
      this.renderCurrentView();
      this.updateAdminUI();
    });
  },

  checkAdminSession() {
    // Database is password-protected by default. Only authenticated admin can modify data.
    this.isAdminLoggedIn = sessionStorage.getItem('school_admin_logged_in') === 'true';
  },

  requireAdmin(actionCallback) {
    if (!this.isAdminLoggedIn) {
      this.showToast('Database is password-protected! Only administrator is allowed to make changes.', 'warning');
      this.openAdminLoginModal();
      return false;
    }
    if (typeof actionCallback === 'function') {
      actionCallback();
    }
    return true;
  },

  continueAsGuest() {
    this.closeModal('admin-login-modal');
    this.showToast('Continuing in Protected View-Only Mode. Any database changes require Admin log on.', 'warning');
  },

  updateAdminUI() {
    const authWidget = document.getElementById('admin-auth-widget');
    const admin = SchoolDB.getAdminProfile();
    const readonlyBanner = document.getElementById('admin-readonly-banner');

    if (readonlyBanner) {
      readonlyBanner.style.display = this.isAdminLoggedIn ? 'none' : 'block';
    }

    if (authWidget) {
      if (this.isAdminLoggedIn) {
        authWidget.innerHTML = `
          <div class="admin-logged-in-pill">
            <span class="admin-badge-dot"></span>
            <span class="admin-name-text">&#128100; ${admin.fullName || admin.username}</span>
            <span class="badge status-active" style="font-size: 10px; padding: 2px 6px;">Admin Mode</span>
            <button class="btn btn-secondary btn-sm admin-auth-btn" onclick="App.logoutAdmin()" title="Log out from Admin">
              &#128682; Log Out
            </button>
          </div>
        `;
      } else {
        authWidget.innerHTML = `
          <button class="btn btn-primary btn-sm admin-auth-btn" onclick="App.openAdminLoginModal()" title="Log on as School Admin" style="background:#059669; border-color:#059669; font-weight:700;">
            &#128274; Admin Log On <span class="urdu-title">(ایڈمن لاگ ان)</span>
          </button>
        `;
      }
    }

    // Populate admin settings form fields (Keep passwords hidden/blank for security)
    const adminFullnameInput = document.getElementById('admin-fullname-input');
    const adminUsernameInput = document.getElementById('admin-username-input');
    const adminPasswordInput = document.getElementById('admin-password-input');
    const adminConfirmInput = document.getElementById('admin-confirm-password-input');
    const statusBadge = document.getElementById('settings-admin-status-badge');

    if (adminFullnameInput) {
      adminFullnameInput.value = this.isAdminLoggedIn ? (admin.fullName || 'Principal / Headmaster') : '';
      adminFullnameInput.disabled = !this.isAdminLoggedIn;
    }
    if (adminUsernameInput) {
      adminUsernameInput.value = this.isAdminLoggedIn ? (admin.username || 'admin') : '';
      adminUsernameInput.disabled = !this.isAdminLoggedIn;
    }
    if (adminPasswordInput) {
      adminPasswordInput.value = '';
      adminPasswordInput.disabled = !this.isAdminLoggedIn;
    }
    if (adminConfirmInput) {
      adminConfirmInput.value = '';
      adminConfirmInput.disabled = !this.isAdminLoggedIn;
    }

    if (statusBadge) {
      if (this.isAdminLoggedIn) {
        statusBadge.className = 'badge status-active';
        statusBadge.innerHTML = '&#9989; Logged In as Administrator';
      } else {
        statusBadge.className = 'badge';
        statusBadge.style.background = '#fef3c7';
        statusBadge.style.color = '#92400e';
        statusBadge.innerHTML = '&#128274; Protected Mode (Password Required to Modify)';
      }
    }
  },

  openAdminLoginModal() {
    const form = document.getElementById('admin-login-form');
    if (form) form.reset();
    this.openModal('admin-login-modal');
  },

  handleAdminLogin(e) {
    e.preventDefault();
    const u = document.getElementById('login-username').value;
    const p = document.getElementById('login-password').value;

    if (SchoolDB.verifyAdmin(u, p)) {
      this.isAdminLoggedIn = true;
      sessionStorage.setItem('school_admin_logged_in', 'true');
      this.closeModal('admin-login-modal');
      this.updateAdminUI();
      const admin = SchoolDB.getAdminProfile();
      this.showToast(`Welcome back, ${admin.fullName}! Admin access granted.`);
      this.renderCurrentView();
    } else {
      this.showToast('Invalid admin username or password. Please try again.', 'error');
    }
  },

  logoutAdmin() {
    this.isAdminLoggedIn = false;
    sessionStorage.removeItem('school_admin_logged_in');
    this.updateAdminUI();
    this.showToast('Administrator logged out successfully. Database is now protected in View-Only Mode.', 'warning');
    this.renderCurrentView();
  },

  handleAdminCredentialsUpdate(e) {
    e.preventDefault();
    if (!this.requireAdmin()) return;

    const fullName = document.getElementById('admin-fullname-input').value;
    const username = document.getElementById('admin-username-input').value;
    const password = document.getElementById('admin-password-input').value;
    const confirmPass = document.getElementById('admin-confirm-password-input').value;

    if (password !== confirmPass) {
      this.showToast('Passwords do not match! Please check and retry.', 'error');
      return;
    }

    if (password.length < 4) {
      this.showToast('Password should be at least 4 characters long.', 'warning');
      return;
    }

    SchoolDB.updateAdminCredentials(username, password, fullName);
    this.updateAdminUI();
    this.showToast('Administrator credentials successfully updated!');
  },

  syncBranding() {
    const s = SchoolDB.data.settings;
    if (s && s.schoolName) {
      const brandElem = document.getElementById('brand-school-name');
      if (brandElem) brandElem.textContent = s.schoolName;
      const yrElem = document.getElementById('academic-year-tag');
      if (yrElem && s.academicYear) yrElem.textContent = s.academicYear;
    }
  },

  // Toast Notification System
  showToast(message, type = 'success') {
    const container = document.getElementById('toast-container');
    if (!container) return;
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    const icon = type === 'success' ? '&#10004;' : (type === 'warning' ? '&#9888;' : '&#10060;');
    toast.innerHTML = `<span>${icon}</span> <span>${message}</span>`;
    container.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(10px)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 3200);
  },

  // Sidebar & Navigation Switcher
  bindNavigation() {
    const navItems = document.querySelectorAll('.menu-item[data-view]');
    navItems.forEach(item => {
      item.addEventListener('click', (e) => {
        e.preventDefault();
        const targetView = item.getAttribute('data-view');
        this.switchView(targetView);

        // Close mobile drawer if opened
        const sidebar = document.querySelector('.sidebar');
        if (sidebar.classList.contains('open')) {
          sidebar.classList.remove('open');
        }
      });
    });

    // Mobile sidebar toggle
    const toggleBtn = document.getElementById('menu-toggle');
    if (toggleBtn) {
      toggleBtn.addEventListener('click', () => {
        this.toggleSidebar();
      });
    }
  },

  toggleSidebar(forceState) {
    const sidebar = document.querySelector('.sidebar');
    const backdrop = document.getElementById('sidebar-backdrop');
    if (!sidebar) return;

    const isOpen = typeof forceState === 'boolean' ? forceState : !sidebar.classList.contains('open');
    if (isOpen) {
      sidebar.classList.add('open');
      if (backdrop) backdrop.classList.add('active');
    } else {
      sidebar.classList.remove('open');
      if (backdrop) backdrop.classList.remove('active');
    }
  },

  switchView(viewName) {
    this.currentView = viewName;
    
    // Auto-close sidebar on mobile once a view is selected
    if (window.innerWidth <= 768) {
      this.toggleSidebar(false);
    }
    
    // Update active nav item
    document.querySelectorAll('.menu-item').forEach(el => {
      el.classList.toggle('active', el.getAttribute('data-view') === viewName);
    });

    // Update visible view section
    document.querySelectorAll('.view-section').forEach(sec => {
      sec.classList.toggle('active', sec.id === `view-${viewName}`);
    });

    // Update page title
    const titleMap = {
      dashboard: { title: 'Academic Overview & Analytics (مرکزی جائزہ و شماریات)', sub: 'Welcome to the school central administration portal. / اسکول ایڈمنسٹریشن پورٹل' },
      students: { title: 'Students Directory & Records (طلباء کا ریکارڈ و ڈائریکٹری)', sub: 'Manage student enrollments, profiles, and credentials. / داخلہ و کوائف طلباء' },
      teachers: { title: 'Teaching & Non-teaching Staff Directory (تدریسی و غیر تدریسی عملہ)', sub: 'Faculty and non-teaching employee roster, personal records, and scale allocations. / ریکارڈ ملازمین' },
      classes: { title: 'Classes & Course Catalog (کلاس رومز و نصابی مضامین)', sub: 'Classroom allocations, sections, and curriculum subjects. / جماعتیں و مضامین' },
      attendance: { title: 'Daily Attendance Management (روزانہ حاضری کا انتظام)', sub: 'Mark and monitor classroom daily roll call and attendance rates. / حاضری رجسٹر' },
      exams: { title: 'Examinations & Report Cards (امتحانات، نمبرات و رزلٹ کارڈ)', sub: 'Record subject marks, compute grades, and generate transcripts. / تعلیمی نتائج' },
      fees: { title: 'Fee Accounting & Billing (فیس بلنگ و مالیاتی حسابات)', sub: 'Track tuition invoices, payments, balances, and issue receipts. / فیس چالان و بقایا جات' },
      'stock-general': { title: 'Stock General Register (اسٹاک رجسٹر جنرل و اثاثہ جات)', sub: 'Manage government high school permanent equipment, furniture, and assets. / اسکول اثاثہ جات' },
      'stock-ptc': { title: 'Parent Teacher Council (PTC) Stock (اسٹاک رجسٹر پی ٹی سی)', sub: 'Track classroom supplies, repairs, and infrastructure procured under PTC funds. / پی ٹی سی فنڈز' },
      'free-textbooks': { title: 'Free Text Books Register (مفت درسی کتب رجسٹر)', sub: 'Class-wise record of free textbooks received, distributed, old collected, stock, and balance from 2012 onwards. / مفت درسی کتب' },
      'adm-withdrawal-middle': { title: 'Admission & Withdrawal Register (Middle) (داخلہ خارج رجسٹر مڈل)', sub: 'Official Government KP Register Dakhla Kharij for Classes 6th, 7th & 8th. / داخلہ خارج مڈل سیکشن' },
      'adm-withdrawal-high': { title: 'Admission & Withdrawal Register (High) (داخلہ خارج رجسٹر ہائی)', sub: 'Official Government KP Register Dakhla Kharij for Classes 9th & 10th (SSC). / داخلہ خارج ہائی سیکشن' },
      notices: { title: 'Bulletin Board & Announcements (نوٹس بورڈ و اعلانات)', sub: 'Circulate academic announcements, circulars, and reminders. / اہم سرکلرز' },
      whatsapp: { title: 'WhatsApp Broadcasting & Messaging (واٹس ایپ میسجنگ و نشریات)', sub: 'Send class-wise student & faculty audio and text announcements. / کلاس وائز طلباء اور اساتذہ کو پیغامات' },
      downloads: { title: 'Downloads & Document Repository (ڈاؤنلوڈز و دستاویزات سینٹر)', sub: 'Upload, manage, and download school forms, calendars, syllabi, proformas, and archives. / اسکول دستاویزات' },
      settings: { title: 'Database & System Settings (ڈیٹا بیس و سسٹم ترتیبات)', sub: 'Backup, restore, and configure school metadata. / بیک اپ اور پروفائل' }
    };

    const info = titleMap[viewName] || { title: 'School Management', sub: '' };
    document.getElementById('current-page-title').textContent = info.title;
    document.getElementById('current-page-subtitle').textContent = info.sub;

    this.renderCurrentView();
  },

  renderCurrentView() {
    switch (this.currentView) {
      case 'dashboard':
        this.renderDashboard();
        break;
      case 'students':
        this.renderStudents();
        break;
      case 'adm-withdrawal-middle':
        this.renderAdmWithdrawal('middle');
        break;
      case 'adm-withdrawal-high':
        this.renderAdmWithdrawal('high');
        break;
      case 'teachers':
        this.renderTeachers();
        break;
      case 'classes':
        this.renderClasses();
        break;
      case 'attendance':
        this.renderAttendanceView();
        break;
      case 'exams':
        this.renderExams();
        break;
      case 'fees':
        this.renderFees();
        break;
      case 'stock-general':
        this.renderStock('general');
        break;
      case 'stock-ptc':
        this.renderStock('ptc');
        break;
      case 'free-textbooks':
        this.renderFreeTextBooks();
        break;
      case 'notices':
        this.renderNotices();
        break;
      case 'whatsapp':
        this.renderWhatsAppView();
        break;
      case 'downloads':
        this.renderDownloads();
        break;
      case 'settings':
        this.renderSettings();
        break;
    }
  },

  // ==================== DASHBOARD VIEW ====================
  updateDashboardCounters() {
    const students = SchoolDB.getStudents();
    const teachers = SchoolDB.getTeachers();
    const classes = SchoolDB.getClasses();
    const fees = SchoolDB.getFees();

    // Student Count
    document.getElementById('dash-count-students').textContent = students.length;
    document.getElementById('sidebar-count-students').textContent = students.length;

    // Admission & Withdrawal Counts
    const admMid = SchoolDB.getAdmWithdrawals('middle');
    const admHigh = SchoolDB.getAdmWithdrawals('high');
    const midBadge = document.getElementById('sidebar-count-adm-withdrawal-middle');
    if (midBadge) midBadge.textContent = admMid.length;
    const highBadge = document.getElementById('sidebar-count-adm-withdrawal-high');
    if (highBadge) highBadge.textContent = admHigh.length;

    // Teacher Count
    document.getElementById('dash-count-teachers').textContent = teachers.length;
    document.getElementById('sidebar-count-teachers').textContent = teachers.length;

    // Stock Counts
    const stockGen = SchoolDB.getStockItems('general');
    const stockPtc = SchoolDB.getStockItems('ptc');
    const elGenBadge = document.getElementById('sidebar-count-stock-general');
    if (elGenBadge) elGenBadge.textContent = stockGen.length;
    const elPtcBadge = document.getElementById('sidebar-count-stock-ptc');
    if (elPtcBadge) elPtcBadge.textContent = stockPtc.length;

    // Downloads Count
    const docs = SchoolDB.getDocuments();
    const elDocBadge = document.getElementById('sidebar-count-downloads');
    if (elDocBadge) elDocBadge.textContent = docs.length;

    // Free Text Books Count
    const ftbList = SchoolDB.getFreeTextBooks();
    const elFtbBadge = document.getElementById('sidebar-count-free-textbooks');
    if (elFtbBadge) elFtbBadge.textContent = ftbList.length;

    // Active Classes
    document.getElementById('dash-count-classes').textContent = classes.length;

    // Financial Metrics
    let totalFees = 0;
    let paidFees = 0;
    fees.forEach(f => {
      totalFees += f.amount;
      paidFees += f.paidAmount;
    });
    const currency = SchoolDB.data.settings?.currency || '$';
    document.getElementById('dash-count-fees').textContent = `${currency}${paidFees.toLocaleString()}`;
    document.getElementById('dash-fee-sub').textContent = `${currency}${(totalFees - paidFees).toLocaleString()} Outstanding`;

    // Today's Attendance Metric
    const todayStr = new Date().toISOString().split('T')[0];
    let todayPresent = 0;
    let todayTotal = 0;
    SchoolDB.data.attendance.forEach(att => {
      if (att.date === todayStr && att.records) {
        for (let sId in att.records) {
          todayTotal++;
          if (att.records[sId] === 'Present' || att.records[sId] === 'Late') todayPresent++;
        }
      }
    });
    const attRate = todayTotal > 0 ? Math.round((todayPresent / todayTotal) * 100) : 96;
    document.getElementById('dash-count-attendance').textContent = `${attRate}%`;
  },

  renderDashboard() {
    this.updateDashboardCounters();
    this.renderDashboardRecentNotices();
    this.renderDashboardRecentStudents();
    this.renderDashboardCharts();
  },

  renderDashboardRecentNotices() {
    const container = document.getElementById('dash-recent-notices');
    if (!container) return;
    const notices = SchoolDB.getNotices().slice(0, 3);
    if (!notices.length) {
      container.innerHTML = '<p class="text-muted" style="font-size: 13px; text-align: center;">No announcements posted yet.</p>';
      return;
    }

    container.innerHTML = notices.map(n => `
      <div class="notice-item">
        <div class="notice-item-header">
          <span class="notice-title">${n.title}</span>
          <span class="badge status-${n.priority.toLowerCase()}">${n.priority}</span>
        </div>
        <p class="notice-desc">${n.content.substring(0, 90)}...</p>
        <span class="notice-date">&#128197; ${n.date} &bull; For ${n.audience}</span>
      </div>
    `).join('');
  },

  renderDashboardRecentStudents() {
    const tbody = document.getElementById('dash-recent-students-tbody');
    if (!tbody) return;
    const students = SchoolDB.getStudents().slice(0, 5);
    if (!students.length) {
      tbody.innerHTML = '<tr><td colspan="5" class="text-center text-muted">No student records in database.</td></tr>';
      return;
    }

    tbody.innerHTML = students.map(s => `
      <tr>
        <td><strong>${s.name}</strong></td>
        <td>${s.rollNo}</td>
        <td>${s.grade} - ${s.section}</td>
        <td><span class="badge status-${s.status.toLowerCase()}">${s.status}</span></td>
        <td>
          <button class="action-icon-btn" onclick="App.viewStudentProfile('${s.id}')" title="View Profile">&#128065;</button>
        </td>
      </tr>
    `).join('');
  },

  renderDashboardCharts() {
    // Canvas 1: Attendance Distribution
    const canvasAtt = document.getElementById('chart-attendance');
    if (canvasAtt && canvasAtt.getContext) {
      const ctx = canvasAtt.getContext('2d');
      const w = canvasAtt.width = canvasAtt.parentElement.clientWidth || 300;
      const h = canvasAtt.height = 200;

      ctx.clearRect(0, 0, w, h);

      // Draw modern Bar Chart of 5 days attendance
      const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
      const rates = [94, 91, 96, 89, 95];
      const barWidth = 36;
      const gap = (w - (days.length * barWidth)) / (days.length + 1);

      days.forEach((day, i) => {
        const x = gap + i * (barWidth + gap);
        const barHeight = (rates[i] / 100) * (h - 60);
        const y = h - 30 - barHeight;

        // Gradient (Light Green to Light Blue)
        const grad = ctx.createLinearGradient(0, y, 0, h - 30);
        grad.addColorStop(0, '#10b981');
        grad.addColorStop(1, '#38bdf8');

        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.roundRect ? ctx.roundRect(x, y, barWidth, barHeight, [4, 4, 0, 0]) : ctx.rect(x, y, barWidth, barHeight);
        ctx.fill();

        // Label Rate
        ctx.fillStyle = '#0f2922';
        ctx.font = 'bold 11px Inter, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(`${rates[i]}%`, x + barWidth / 2, y - 6);

        // Label Day
        ctx.fillStyle = '#53756d';
        ctx.font = '11px Inter, sans-serif';
        ctx.fillText(day, x + barWidth / 2, h - 10);
      });
    }

    // Canvas 2: Fee Status Distribution
    const canvasFees = document.getElementById('chart-fees');
    if (canvasFees && canvasFees.getContext) {
      const ctx = canvasFees.getContext('2d');
      const w = canvasFees.width = canvasFees.parentElement.clientWidth || 300;
      const h = canvasFees.height = 200;

      ctx.clearRect(0, 0, w, h);

      const fees = SchoolDB.getFees();
      let paid = 0, partial = 0, pending = 0;
      fees.forEach(f => {
        if (f.status === 'Paid') paid++;
        else if (f.status === 'Partial') partial++;
        else pending++;
      });
      const total = (paid + partial + pending) || 1;

      // Donut Chart
      const centerX = w / 2;
      const centerY = h / 2 - 10;
      const radius = 65;
      const innerRadius = 40;

      const slices = [
        { count: paid, color: '#10b981', label: 'Paid' },
        { count: partial, color: '#38bdf8', label: 'Partial' },
        { count: pending, color: '#f59e0b', label: 'Pending' }
      ];

      let startAngle = -0.5 * Math.PI;
      slices.forEach(slice => {
        const sliceAngle = (slice.count / total) * 2 * Math.PI;
        ctx.beginPath();
        ctx.arc(centerX, centerY, radius, startAngle, startAngle + sliceAngle);
        ctx.arc(centerX, centerY, innerRadius, startAngle + sliceAngle, startAngle, true);
        ctx.closePath();
        ctx.fillStyle = slice.color;
        ctx.fill();
        startAngle += sliceAngle;
      });

      // Center text
      ctx.fillStyle = '#1e293b';
      ctx.font = 'bold 16px Inter, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(total, centerX, centerY + 5);

      // Legend bottom
      const legendY = h - 12;
      let legX = 30;
      slices.forEach(sl => {
        ctx.fillStyle = sl.color;
        ctx.fillRect(legX, legendY - 8, 8, 8);
        ctx.fillStyle = '#64748b';
        ctx.font = '10px Inter, sans-serif';
        ctx.textAlign = 'left';
        ctx.fillText(`${sl.label} (${sl.count})`, legX + 12, legendY);
        legX += (w / 3) - 10;
      });
    }
  },

  // ==================== STUDENTS MODULE ====================
  renderStudents() {
    const tbody = document.getElementById('students-tbody');
    if (!tbody) return;

    let students = SchoolDB.getStudents();
    const query = (document.getElementById('students-search')?.value || '').toLowerCase().trim();
    const filterClass = document.getElementById('students-filter-class')?.value || '';
    const filterSection = document.getElementById('students-filter-section')?.value || '';
    const filterStatus = document.getElementById('students-filter-status')?.value || '';

    // Populate class filter dropdown dynamically
    this.populateClassDropdowns();

    // Filter
    students = students.filter(s => {
      let match = true;
      if (query) {
        match = match && (
          s.name.toLowerCase().includes(query) ||
          s.rollNo.toLowerCase().includes(query) ||
          s.id.toLowerCase().includes(query) ||
          (s.guardian && s.guardian.toLowerCase().includes(query))
        );
      }
      if (filterClass) {
        match = match && s.grade === filterClass;
      }
      if (filterSection) {
        match = match && (s.section || '').toUpperCase() === filterSection.toUpperCase();
      }
      if (filterStatus) {
        match = match && s.status === filterStatus;
      }
      return match;
    });

    if (!students.length) {
      tbody.innerHTML = `
        <tr>
          <td colspan="8">
            <div class="empty-state">
              <div class="empty-state-icon">&#127891;</div>
              <h4>No Students Found</h4>
              <p>Try clearing your search filters or click "Add Student" to register an enrollment.</p>
            </div>
          </td>
        </tr>
      `;
      return;
    }

    tbody.innerHTML = students.map((s, index) => {
      let specialCategoryBadge = '';
      if (s.specialCategory && s.specialCategory !== 'None') {
        const bg = s.specialCategory.includes('Orphan') ? '#fef3c7' : '#e0e7ff';
        const col = s.specialCategory.includes('Orphan') ? '#b45309' : '#4338ca';
        specialCategoryBadge = `<span class="badge" style="background:${bg}; color:${col}; font-size:10px; margin-top:3px; display:inline-block;">${s.specialCategory}</span>`;
      }

      return `
        <tr>
          <td><strong style="color: var(--primary);">${s.id}</strong></td>
          <td>
            <div style="display: flex; align-items: center; gap: 10px;">
              <div class="table-student-avatar">
                ${s.photo ? `<img src="${s.photo}" alt="${s.name}" class="table-avatar-img">` : `<span>${s.name.charAt(0)}</span>`}
              </div>
              <div>
                <div style="font-weight: 600; color: var(--text-main);">${s.name}</div>
                ${specialCategoryBadge ? `<div>${specialCategoryBadge}</div>` : `<small class="text-muted">${s.specialCategory || 'Normal'}</small>`}
              </div>
            </div>
          </td>
          <td><span class="badge" style="background:#e0f2fe; color:#0284c7;">${s.rollNo}</span></td>
          <td>${s.grade} - Sec ${s.section}</td>
          <td>${s.gender}</td>
          <td>${s.guardian || '-'} <br><small class="text-muted">${s.phone || ''}</small></td>
          <td><span class="badge status-${s.status.toLowerCase()}">${s.status}</span></td>
          <td>
            <div class="table-actions">
              <button class="action-icon-btn" onclick="App.quickWhatsAppStudent('${s.id}')" title="Send WhatsApp Message (واٹس ایپ میسج)" style="color: #128C7E;">&#128172;</button>
              <button class="action-icon-btn" onclick="App.viewStudentProfile('${s.id}')" title="View Profile & ID Card">&#128065;</button>
              <button class="action-icon-btn" onclick="App.editStudentModal('${s.id}')" title="Edit Student Details">&#9998;</button>
              <button class="action-icon-btn delete" onclick="App.deleteStudentConfirm('${s.id}')" title="Remove Record">&#128465;</button>
            </div>
          </td>
        </tr>
      `;
    }).join('');
  },

  viewStudentProfile(studentId) {
    const student = SchoolDB.getStudentById(studentId);
    if (!student) return;
    const modalBody = document.getElementById('generic-modal-body');
    const modalTitle = document.getElementById('generic-modal-title');
    modalTitle.textContent = `Student Profile & Digital Credential`;
    
    modalBody.innerHTML = `
      ${ReportEngine.generateStudentIdCardHTML(student)}
      <div style="margin-top: 20px; display: flex; justify-content: center; gap: 12px; flex-wrap: wrap;">
        <button class="btn btn-whatsapp" onclick="App.quickWhatsAppStudent('${student.id}')" title="Send WhatsApp Message">
          &#128172; WhatsApp Father <span class="urdu-title">(واٹس ایپ والد / سرپرست)</span>
        </button>
        <button class="btn btn-primary" onclick="ReportEngine.printElement(ReportEngine.generateStudentIdCardHTML(SchoolDB.getStudentById('${student.id}')))">
          &#128424; Print Student ID Card
        </button>
      </div>
    `;
    this.openModal('generic-modal');
  },

  openAddStudentModal() {
    if (!this.requireAdmin()) return;
    document.getElementById('student-form').reset();
    const idField = document.getElementById('student-id-field');
    if (idField) {
      idField.value = '';
      idField.readOnly = false;
      idField.placeholder = 'e.g. 1001, ADM-2025-01';
    }
    const admDateField = document.getElementById('student-admission-date');
    if (admDateField) {
      admDateField.value = new Date().toISOString().split('T')[0];
    }
    const catSelect = document.getElementById('student-special-category');
    if (catSelect) catSelect.value = 'None';
    document.getElementById('student-modal-title').textContent = 'Register New Student Enrollment';
    this.setStudentPhotoPreview(null);
    this.populateClassDropdowns();
    this.openModal('student-form-modal');
  },

  editStudentModal(id) {
    if (!this.requireAdmin()) return;
    const student = SchoolDB.getStudentById(id);
    if (!student) return;
    this.populateClassDropdowns();
    document.getElementById('student-modal-title').textContent = `Edit Student: ${student.name} (Admission #${student.id})`;
    const idField = document.getElementById('student-id-field');
    if (idField) {
      idField.value = student.id;
      idField.readOnly = true; // Protect Admission No from accidental changes on edit
    }
    const admDateField = document.getElementById('student-admission-date');
    if (admDateField) {
      admDateField.value = student.admissionDate || '';
    }
    document.getElementById('student-name').value = student.name || '';
    document.getElementById('student-roll').value = student.rollNo || '';
    document.getElementById('student-gender').value = student.gender || 'Male';
    document.getElementById('student-dob').value = student.dob || '';
    document.getElementById('student-grade').value = student.grade || 'Grade 10';
    document.getElementById('student-section').value = student.section || 'A';
    document.getElementById('student-guardian').value = student.guardian || '';
    document.getElementById('student-phone').value = student.phone || '';
    const catSelect = document.getElementById('student-special-category');
    if (catSelect) catSelect.value = student.specialCategory || 'None';
    document.getElementById('student-address').value = student.address || '';
    document.getElementById('student-status').value = student.status || 'Active';
    this.setStudentPhotoPreview(student.photo || null);
    this.openModal('student-form-modal');
  },

  setStudentPhotoPreview(photoUrl) {
    const previewBox = document.getElementById('student-photo-preview');
    const photoDataField = document.getElementById('student-photo-data');
    const removeBtn = document.getElementById('btn-remove-photo');
    if (!previewBox || !photoDataField) return;

    if (photoUrl) {
      photoDataField.value = photoUrl;
      previewBox.innerHTML = `<img src="${photoUrl}" alt="Student Photo" class="student-photo-preview-img">`;
      if (removeBtn) removeBtn.style.display = 'inline-block';
    } else {
      photoDataField.value = '';
      previewBox.innerHTML = `<span class="photo-placeholder-icon">&#128100;</span>`;
      if (removeBtn) removeBtn.style.display = 'none';
      const fileInput = document.getElementById('student-photo-input');
      if (fileInput) fileInput.value = '';
    }
  },

  removeStudentPhoto() {
    if (!this.requireAdmin()) return;
    this.setStudentPhotoPreview(null);
  },

  handleStudentPhotoUpload(e) {
    if (!this.requireAdmin()) {
      if (e.target) e.target.value = '';
      return;
    }
    const file = e.target.files && e.target.files[0];
    if (!file) return;

    // Check size limit: keep base64 reasonable for localStorage (< 1MB)
    if (file.size > 2 * 1024 * 1024) {
      this.showToast('Please select a photo smaller than 2MB.', 'error');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      // Scale down image using HTML Canvas to ensure compact localStorage footprint
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX_WIDTH = 320;
        const MAX_HEIGHT = 400;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height;
            height = MAX_HEIGHT;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, width, height);

        const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.85);
        this.setStudentPhotoPreview(compressedDataUrl);
      };
      img.src = event.target.result;
    };
    reader.readAsDataURL(file);
  },

  saveStudentFromForm(e) {
    e.preventDefault();
    if (!this.requireAdmin()) return;
    const id = document.getElementById('student-id-field').value.trim();
    if (!id) {
      this.showToast('Please enter an Admission No for the student.', 'warning');
      document.getElementById('student-id-field').focus();
      return;
    }

    const specialCategory = document.getElementById('student-special-category')?.value || 'None';
    const admissionDate = document.getElementById('student-admission-date')?.value || new Date().toISOString().split('T')[0];

    const student = {
      id: id, // User-filled Admission No
      admissionDate: admissionDate,
      name: document.getElementById('student-name').value.trim(),
      guardian: document.getElementById('student-guardian').value.trim(),
      dob: document.getElementById('student-dob').value,
      grade: document.getElementById('student-grade').value,
      section: document.getElementById('student-section').value,
      phone: document.getElementById('student-phone').value.trim(),
      specialCategory: specialCategory,
      rollNo: document.getElementById('student-roll').value.trim(),
      gender: document.getElementById('student-gender').value,
      address: document.getElementById('student-address').value.trim(),
      status: document.getElementById('student-status').value,
      photo: document.getElementById('student-photo-data').value || ''
    };

    const saved = SchoolDB.saveStudent(student);
    if (!saved) return;
    this.closeModal('student-form-modal');
    this.showToast('Student enrollment saved successfully!');
    this.renderStudents();
  },

  deleteStudentConfirm(id) {
    if (!this.requireAdmin()) return;
    const student = SchoolDB.getStudentById(id);
    if (!student) return;
    if (confirm(`Are you sure you want to remove ${student.name} (Admission #${student.id})? This will also remove associated fee and marks records.`)) {
      SchoolDB.deleteStudent(id);
      this.showToast(`Student ${student.name} removed.`, 'warning');
      this.renderStudents();
    }
  },

  // Student CSV Import Modal Controls
  openStudentCSVModal() {
    if (!this.requireAdmin()) return;
    this.pendingCSVStudents = null;
    const fileInput = document.getElementById('csv-student-file-input');
    if (fileInput) fileInput.value = '';
    const previewContainer = document.getElementById('csv-preview-container');
    if (previewContainer) previewContainer.style.display = 'none';
    const btnConfirm = document.getElementById('btn-confirm-csv-import');
    if (btnConfirm) btnConfirm.disabled = true;
    const dropzone = document.getElementById('csv-student-dropzone');
    if (dropzone) {
      dropzone.style.borderColor = '#93c5fd';
      dropzone.style.background = '#eff6ff';
    }
    this.openModal('student-csv-modal');
  },

  handleStudentCSVSelected(e) {
    const file = e.target.files ? e.target.files[0] : (e.dataTransfer ? e.dataTransfer.files[0] : null);
    if (!file) return;

    if (!file.name.toLowerCase().endsWith('.csv') && file.type !== 'text/csv' && file.type !== 'application/vnd.ms-excel') {
      this.showToast('Please select a valid .csv spreadsheet file.', 'warning');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const csvText = event.target.result;
      const students = ReportEngine.parseStudentsCSV(csvText);

      if (!students || !students.length) {
        this.showToast('No valid student records found in this CSV file. Please ensure column headers match.', 'warning');
        this.pendingCSVStudents = null;
        const prev = document.getElementById('csv-preview-container');
        if (prev) prev.style.display = 'none';
        const btn = document.getElementById('btn-confirm-csv-import');
        if (btn) btn.disabled = true;
        return;
      }

      this.pendingCSVStudents = students;

      // Populate preview UI
      const countElem = document.getElementById('csv-detected-count');
      if (countElem) {
        countElem.textContent = `✅ Detected ${students.length} student records ready for import`;
      }

      const tbody = document.getElementById('csv-preview-tbody');
      if (tbody) {
        tbody.innerHTML = students.slice(0, 5).map(s => `
          <tr>
            <td><strong>${s.id || '-'}</strong></td>
            <td><strong>${s.rollNo || '-'}</strong></td>
            <td>${s.name}</td>
            <td>${s.guardian || '-'}</td>
            <td><span class="badge" style="background:#e0f2fe; color:#0369a1;">${s.grade}</span></td>
            <td><span class="badge" style="background:#f1f5f9; color:#475569;">${s.section}</span></td>
            <td><span class="badge" style="background:${s.specialCategory && s.specialCategory !== 'None' ? '#fef3c7' : '#f1f5f9'}; color:${s.specialCategory && s.specialCategory !== 'None' ? '#b45309' : '#64748b'};">${s.specialCategory || 'None'}</span></td>
            <td>${s.phone || '-'}</td>
          </tr>
        `).join('');
      }

      const previewContainer = document.getElementById('csv-preview-container');
      if (previewContainer) previewContainer.style.display = 'block';

      const btnConfirm = document.getElementById('btn-confirm-csv-import');
      if (btnConfirm) btnConfirm.disabled = false;

      this.showToast(`Found ${students.length} student records in ${file.name}. Review and confirm to import.`);
    };

    reader.onerror = () => {
      this.showToast('Failed to read the selected CSV file.', 'error');
    };

    reader.readAsText(file);
  },

  executeStudentCSVImport() {
    if (!this.requireAdmin()) return;
    if (!this.pendingCSVStudents || !this.pendingCSVStudents.length) {
      this.showToast('No student records selected for import.', 'warning');
      return;
    }

    const res = SchoolDB.importStudents(this.pendingCSVStudents);
    if (res.success) {
      this.closeModal('student-csv-modal');
      this.showToast(`Successfully imported ${res.count} students into database! (کامیابی سے شامل کر لیے گئے)`);
      this.pendingCSVStudents = null;
      this.renderStudents();
      this.updateDashboardCounters();
    } else {
      this.showToast(res.message || 'Failed to import students.', 'error');
    }
  },

  setTeacherPhotoPreview(photoUrl) {
    const previewBox = document.getElementById('teacher-photo-preview');
    const photoDataField = document.getElementById('teacher-photo-data');
    const removeBtn = document.getElementById('btn-remove-teacher-photo');
    if (!previewBox || !photoDataField) return;

    if (photoUrl) {
      photoDataField.value = photoUrl;
      previewBox.innerHTML = `<img src="${photoUrl}" alt="Staff Photo" class="student-photo-preview-img" style="width: 100%; height: 100%; object-fit: cover; border-radius: 6px;">`;
      if (removeBtn) removeBtn.style.display = 'inline-block';
    } else {
      photoDataField.value = '';
      previewBox.innerHTML = `<span class="photo-placeholder-icon">&#128100;</span>`;
      if (removeBtn) removeBtn.style.display = 'none';
      const fileInput = document.getElementById('teacher-photo-input');
      if (fileInput) fileInput.value = '';
    }
  },

  removeTeacherPhoto() {
    if (!this.requireAdmin()) return;
    this.setTeacherPhotoPreview(null);
  },

  handleTeacherPhotoUpload(e) {
    if (!this.requireAdmin()) {
      if (e.target) e.target.value = '';
      return;
    }
    const file = e.target.files && e.target.files[0];
    if (!file) return;

    if (file.size > 2 * 1024 * 1024) {
      this.showToast('Please select a photo smaller than 2MB.', 'error');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX_WIDTH = 320;
        const MAX_HEIGHT = 400;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height;
            height = MAX_HEIGHT;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, width, height);

        const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.85);
        this.setTeacherPhotoPreview(compressedDataUrl);
      };
      img.src = event.target.result;
    };
    reader.readAsDataURL(file);
  },

  // ==================== TEACHING & NON-TEACHING STAFF MODULE ====================
  renderTeachers() {
    const tbody = document.getElementById('teachers-tbody');
    if (!tbody) return;

    let teachers = SchoolDB.getTeachers();
    const query = (document.getElementById('teachers-search')?.value || '').toLowerCase().trim();
    const filterStatus = document.getElementById('teachers-filter-status')?.value || '';

    teachers = teachers.filter(t => {
      let match = true;
      if (query) {
        match = match && (
          (t.name && t.name.toLowerCase().includes(query)) ||
          (t.fatherName && t.fatherName.toLowerCase().includes(query)) ||
          (t.designation && t.designation.toLowerCase().includes(query)) ||
          (t.bps && t.bps.toLowerCase().includes(query)) ||
          (t.qualification && t.qualification.toLowerCase().includes(query)) ||
          (t.profQualification && t.profQualification.toLowerCase().includes(query)) ||
          (t.personalNo && t.personalNo.toLowerCase().includes(query)) ||
          (t.cnic && t.cnic.toLowerCase().includes(query)) ||
          (t.salaryAccount && t.salaryAccount.toLowerCase().includes(query)) ||
          (t.bankCode && t.bankCode.toLowerCase().includes(query)) ||
          (t.bankName && t.bankName.toLowerCase().includes(query)) ||
          (t.id && t.id.toLowerCase().includes(query)) ||
          (t.phone && t.phone.toLowerCase().includes(query)) ||
          (t.email && t.email.toLowerCase().includes(query))
        );
      }
      if (filterStatus) {
        match = match && t.status === filterStatus;
      }
      return match;
    });

    if (!teachers.length) {
      tbody.innerHTML = `
        <tr>
          <td colspan="16">
            <div class="empty-state">
              <div class="empty-state-icon">&#128104;&#8205;&#127979;</div>
              <h4>No Staff Records Found</h4>
              <p>Click "Add Staff Member" to add teaching or non-teaching employees.</p>
            </div>
          </td>
        </tr>
      `;
      return;
    }

    tbody.innerHTML = teachers.map(t => {
      const photoHtml = t.photo 
        ? `<img src="${t.photo}" alt="${t.name}" style="width: 34px; height: 38px; object-fit: cover; border-radius: 4px; border: 1px solid #cbd5e1; box-shadow: 0 1px 2px rgba(0,0,0,0.06); display: inline-block;">` 
        : `<div style="width: 34px; height: 38px; background: #e2e8f0; border-radius: 4px; display: inline-flex; align-items: center; justify-content: center; color: #64748b; font-size: 15px; border: 1px dashed #cbd5e1;">&#128100;</div>`;

      return `
      <tr>
        <td style="text-align: center; vertical-align: middle;">${photoHtml}</td>
        <td><strong style="color: #1e3a8a;">${t.id}</strong></td>
        <td>
          <strong style="color: var(--text-main); font-size: 13px;">${t.name}</strong>
          ${t.gender ? `<small class="text-muted" style="display:block;">${t.gender}</small>` : ''}
        </td>
        <td>${t.fatherName || '-'}</td>
        <td><strong style="color: #0f172a;">${t.designation || 'Staff'}</strong></td>
        <td style="text-align: center;"><span class="badge" style="background:#f1f5f9; color:#0f172a; font-weight:700; border:1px solid #cbd5e1;">${t.bps || 'BPS-16'}</span></td>
        <td><span class="badge" style="background:#e0f2fe; color:#0369a1; font-weight:600;">${t.qualification || '-'}</span></td>
        <td><span class="badge" style="background:#fef3c7; color:#92400e; font-weight:600;">${t.profQualification || t.professionalQualification || '-'}</span></td>
        <td><code style="background:#f8fafc; padding:2px 6px; border:1px solid #e2e8f0; border-radius:4px; font-weight:700; color:#1e40af;">${t.personalNo || '-'}</code></td>
        <td style="font-family: monospace; font-size: 11.5px;">${t.cnic || '-'}</td>
        <td style="font-family: monospace; font-size: 11.5px; color:#065f46; font-weight:600;">${t.salaryAccount || '-'}</td>
        <td style="text-align: center;"><code style="font-weight:700;">${t.bankCode || '-'}</code></td>
        <td>${t.bankName || '-'}</td>
        <td>${t.phone || '-'}</td>
        <td style="text-align: center;"><span class="badge status-${(t.status || 'Active').toLowerCase()}">${t.status || 'Active'}</span></td>
        <td>
          <div class="table-actions" style="justify-content: center; gap: 4px;">
            <button class="action-icon-btn" onclick="ReportEngine.printStaffBioData('${t.id}')" title="Print Official 1-Page Bio-Data Sheet (بائیو ڈیٹا)" style="color: #0284c7; background: #e0f2fe;">&#128196;</button>
            <button class="action-icon-btn" onclick="App.quickWhatsAppTeacher('${t.id}')" title="Send WhatsApp Message (واٹس ایپ میسج)" style="color: #128C7E;">&#128172;</button>
            <button class="action-icon-btn" onclick="App.editTeacherModal('${t.id}')" title="Edit Staff Member">&#9998;</button>
            <button class="action-icon-btn delete" onclick="App.deleteTeacherConfirm('${t.id}')" title="Delete">&#128465;</button>
          </div>
        </td>
      </tr>
      `;
    }).join('');
  },

  openAddTeacherModal() {
    if (!this.requireAdmin()) return;
    document.getElementById('teacher-form').reset();
    document.getElementById('teacher-id-field').value = '';
    this.setTeacherPhotoPreview(null);
    document.getElementById('teacher-modal-title').textContent = 'Add Staff Member (نیا ملازم شامل کریں)';
    this.openModal('teacher-form-modal');
  },

  editTeacherModal(id) {
    if (!this.requireAdmin()) return;
    const t = SchoolDB.getTeacherById(id);
    if (!t) return;
    document.getElementById('teacher-modal-title').textContent = `Edit Staff Record: ${t.name} (${t.designation || 'Staff'})`;
    document.getElementById('teacher-id-field').value = t.id;
    this.setTeacherPhotoPreview(t.photo || null);
    document.getElementById('teacher-name').value = t.name || '';
    document.getElementById('teacher-father-name').value = t.fatherName || '';
    document.getElementById('teacher-designation').value = t.designation || '';
    document.getElementById('teacher-bps').value = t.bps || 'BPS-16';
    document.getElementById('teacher-qualification').value = t.qualification || '';
    document.getElementById('teacher-prof-qualification').value = t.profQualification || t.professionalQualification || '';
    document.getElementById('teacher-personal-no').value = t.personalNo || '';
    document.getElementById('teacher-cnic').value = t.cnic || '';
    document.getElementById('teacher-salary-account').value = t.salaryAccount || '';
    document.getElementById('teacher-bank-code').value = t.bankCode || '';
    document.getElementById('teacher-bank-name').value = t.bankName || '';
    document.getElementById('teacher-phone').value = t.phone || '';
    document.getElementById('teacher-email').value = t.email || '';
    document.getElementById('teacher-gender').value = t.gender || 'Male';
    document.getElementById('teacher-status').value = t.status || 'Active';
    this.openModal('teacher-form-modal');
  },

  saveTeacherFromForm(e) {
    e.preventDefault();
    if (!this.requireAdmin()) return;
    const id = document.getElementById('teacher-id-field').value;
    const teacher = {
      photo: document.getElementById('teacher-photo-data')?.value || '',
      name: document.getElementById('teacher-name').value.trim(),
      fatherName: document.getElementById('teacher-father-name').value.trim(),
      designation: document.getElementById('teacher-designation').value.trim(),
      bps: document.getElementById('teacher-bps').value,
      qualification: document.getElementById('teacher-qualification').value.trim(),
      profQualification: document.getElementById('teacher-prof-qualification').value.trim(),
      personalNo: document.getElementById('teacher-personal-no').value.trim(),
      cnic: document.getElementById('teacher-cnic').value.trim(),
      salaryAccount: document.getElementById('teacher-salary-account').value.trim(),
      bankCode: document.getElementById('teacher-bank-code').value.trim(),
      bankName: document.getElementById('teacher-bank-name').value.trim(),
      phone: document.getElementById('teacher-phone').value.trim(),
      email: document.getElementById('teacher-email').value.trim(),
      gender: document.getElementById('teacher-gender').value,
      status: document.getElementById('teacher-status').value
    };

    if (id) teacher.id = id;

    SchoolDB.saveTeacher(teacher);
    this.closeModal('teacher-form-modal');
    this.showToast(id ? 'Staff record updated successfully!' : 'New staff member registered.');
    this.renderTeachers();
  },

  deleteTeacherConfirm(id) {
    if (!this.requireAdmin()) return;
    const teacher = SchoolDB.getTeacherById(id);
    if (!teacher) return;
    if (confirm(`Are you sure you want to remove ${teacher.name}?`)) {
      SchoolDB.deleteTeacher(id);
      this.showToast(`Faculty member removed.`, 'warning');
      this.renderTeachers();
    }
  },

  // ==================== CLASSES & SUBJECTS ====================
  renderClasses() {
    const classContainer = document.getElementById('classes-cards-grid');
    const subjectTbody = document.getElementById('subjects-tbody');
    const classes = SchoolDB.getClasses();
    const subjects = SchoolDB.getSubjects();
    const students = SchoolDB.getStudents();
    const teachers = SchoolDB.getTeachers();

    const teacherMap = {};
    teachers.forEach(t => teacherMap[t.id] = t.name);

    // Light pastel themes for each section card (مختلف ہلکے رنگ)
    const sectionThemes = [
      { bg: '#f0fdf4', border: '#86efac', text: '#166534', headerText: '#14532d', badgeBg: '#dcfce7', badgeColor: '#15803d', btnBorder: '#86efac', btnColor: '#166534', infoBg: '#ffffffc2', infoBorder: '#bbf7d0' }, // Mint / Light Green
      { bg: '#eff6ff', border: '#93c5fd', text: '#1e40af', headerText: '#1e3a8a', badgeBg: '#dbeafe', badgeColor: '#1d4ed8', btnBorder: '#93c5fd', btnColor: '#1e40af', infoBg: '#ffffffc2', infoBorder: '#bfdbfe' }, // Azure / Light Blue
      { bg: '#faf5ff', border: '#d8b4fe', text: '#6b21a8', headerText: '#581c87', badgeBg: '#f3e8ff', badgeColor: '#7e22ce', btnBorder: '#d8b4fe', btnColor: '#6b21a8', infoBg: '#ffffffc2', infoBorder: '#e9d5ff' }, // Lavender / Light Purple
      { bg: '#fffbeb', border: '#fde68a', text: '#92400e', headerText: '#78350f', badgeBg: '#fef3c7', badgeColor: '#b45309', btnBorder: '#fde68a', btnColor: '#92400e', infoBg: '#ffffffc2', infoBorder: '#fef08a' }, // Warm Honey / Light Amber
      { bg: '#fff1f2', border: '#fecdd3', text: '#9f1239', headerText: '#881337', badgeBg: '#ffe4e6', badgeColor: '#be123c', btnBorder: '#fecdd3', btnColor: '#9f1239', infoBg: '#ffffffc2', infoBorder: '#fda4af' }, // Rose / Light Pink
      { bg: '#ecfeff', border: '#a5f3fc', text: '#155e75', headerText: '#164e63', badgeBg: '#cffafe', badgeColor: '#0e7490', btnBorder: '#a5f3fc', btnColor: '#155e75', infoBg: '#ffffffc2', infoBorder: '#67e8f9' }, // Cyan / Light Aqua
      { bg: '#fff7ed', border: '#fed7aa', text: '#9a3412', headerText: '#7c2d12', badgeBg: '#ffedd5', badgeColor: '#c2410c', btnBorder: '#fed7aa', btnColor: '#9a3412', infoBg: '#ffffffc2', infoBorder: '#fdba74' }, // Peach / Light Orange
      { bg: '#fdf4ff', border: '#f5d0fe', text: '#86198f', headerText: '#701a75', badgeBg: '#fae8ff', badgeColor: '#a21caf', btnBorder: '#f5d0fe', btnColor: '#86198f', infoBg: '#ffffffc2', infoBorder: '#f0abfc' }, // Orchid / Light Fuchsia
      { bg: '#f7fee7', border: '#bef264', text: '#3f6212', headerText: '#365314', badgeBg: '#ecfccb', badgeColor: '#4d7c0f', btnBorder: '#bef264', btnColor: '#3f6212', infoBg: '#ffffffc2', infoBorder: '#d9f99d' }, // Lime / Spring Green
      { bg: '#f8fafc', border: '#cbd5e1', text: '#334155', headerText: '#0f172a', badgeBg: '#e2e8f0', badgeColor: '#475569', btnBorder: '#cbd5e1', btnColor: '#334155', infoBg: '#ffffffc2', infoBorder: '#cbd5e1' }  // Cool Slate
    ];

    if (classContainer) {
      if (!classes.length) {
        classContainer.innerHTML = '<p class="text-muted">No classes created yet.</p>';
      } else {
        classContainer.innerHTML = classes.map((c, idx) => {
          const studentCount = students.filter(s => s.grade === c.name && s.section === c.section).length;
          const assignedTeacher = teacherMap[c.teacherId] || 'Unassigned';
          const t = sectionThemes[idx % sectionThemes.length];
          const cap = c.capacity || 35;
          const rollPct = Math.round((studentCount / cap) * 100);

          return `
            <div class="class-section-box" style="background:${t.bg}; border:1.5px solid ${t.border}; border-radius:10px; padding:10px 12px; box-shadow:0 1px 3px rgba(0,0,0,0.04); display:flex; flex-direction:column; justify-content:space-between;">
              <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:6px;">
                <div>
                  <h4 style="font-size:13.5px; font-weight:800; color:${t.headerText}; margin:0; line-height:1.2;">
                    ${c.name} <span style="font-weight:700; font-size:12px; opacity:0.9;">- Sec ${c.section}</span>
                  </h4>
                  <small style="color:${t.text}; font-size:10px; opacity:0.85;">${c.room || 'Main Block'} &bull; ID: ${c.id}</small>
                </div>
                <button class="action-icon-btn delete" onclick="App.deleteClassConfirm('${c.id}')" title="Delete Class" style="width:20px; height:20px; font-size:10px; padding:0; flex-shrink:0;">&#128465;</button>
              </div>

              <div style="margin:8px 0; background:${t.infoBg}; border:1px solid ${t.infoBorder}; padding:6px 8px; border-radius:6px; font-size:10.5px; color:${t.text}; display:grid; grid-template-columns:1fr 1fr; gap:4px;">
                <div style="overflow:hidden; text-overflow:ellipsis; white-space:nowrap;"><span style="font-size:9.5px; opacity:0.8; display:block;">Teacher:</span><strong title="${assignedTeacher}">${assignedTeacher}</strong></div>
                <div><span style="font-size:9.5px; opacity:0.8; display:block;">Students:</span><strong>${studentCount}</strong> / ${cap}</div>
              </div>

              <div style="display:flex; justify-content:space-between; align-items:center; gap:6px;">
                <span class="badge" style="background:${t.badgeBg}; color:${t.badgeColor}; font-size:9.5px; font-weight:700; padding:2px 6px; border-radius:4px;">${rollPct}% Roll</span>
                <button class="btn btn-sm" onclick="App.switchViewToClassStudents('${c.name}', '${c.section}')" style="background:#ffffff; border:1px solid ${t.btnBorder}; color:${t.btnColor}; font-weight:700; font-size:10px; padding:3px 8px; border-radius:4px; box-shadow:0 1px 2px rgba(0,0,0,0.03);" title="View class students">
                  View Pupils &rarr;
                </button>
              </div>
            </div>
          `;
        }).join('');
      }
    }

    if (subjectTbody) {
      if (!subjects.length) {
        subjectTbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No course subjects defined.</td></tr>';
      } else {
        subjectTbody.innerHTML = subjects.map(sub => `
          <tr>
            <td><strong>${sub.code}</strong></td>
            <td><strong>${sub.name}</strong></td>
            <td><span class="badge" style="background:#e0f2fe; color:#0369a1; font-weight:700; font-size:12px;">${sub.totalMarks || 100}</span></td>
            <td>${sub.grade}</td>
            <td>${teacherMap[sub.teacherId] || 'Unassigned'}</td>
            <td>
              <button class="action-icon-btn delete" onclick="App.deleteSubjectConfirm('${sub.code}')" title="Delete">&#128465;</button>
            </td>
          </tr>
        `).join('');
      }
    }
  },

  switchViewToClassStudents(className, section) {
    this.switchView('students');
    const classFilter = document.getElementById('students-filter-class');
    if (classFilter) {
      classFilter.value = className;
    }
    const secFilter = document.getElementById('students-filter-section');
    if (secFilter && section) {
      secFilter.value = section;
    }
    this.renderStudents();
  },

  openAddClassModal() {
    if (!this.requireAdmin()) return;
    document.getElementById('class-form').reset();
    this.populateTeacherDropdown('class-teacher-select');
    this.openModal('class-form-modal');
  },

  saveClassFromForm(e) {
    e.preventDefault();
    if (!this.requireAdmin()) return;
    const newClass = {
      name: document.getElementById('class-grade-name').value.trim(),
      section: document.getElementById('class-section-name').value.trim().toUpperCase(),
      room: document.getElementById('class-room-name').value.trim(),
      teacherId: document.getElementById('class-teacher-select').value,
      capacity: Number(document.getElementById('class-capacity').value) || 35
    };
    SchoolDB.saveClass(newClass);
    this.closeModal('class-form-modal');
    this.showToast('Class classroom added.');
    this.renderClasses();
  },

  deleteClassConfirm(id) {
    if (!this.requireAdmin()) return;
    if (confirm('Delete this class?')) {
      SchoolDB.deleteClass(id);
      this.showToast('Class removed.', 'warning');
      this.renderClasses();
    }
  },

  openAddSubjectModal() {
    if (!this.requireAdmin()) return;
    document.getElementById('subject-form').reset();
    this.populateTeacherDropdown('subject-teacher-select');
    this.openModal('subject-form-modal');
  },

  saveSubjectFromForm(e) {
    e.preventDefault();
    if (!this.requireAdmin()) return;
    const subj = {
      code: document.getElementById('subject-code').value.trim().toUpperCase(),
      name: document.getElementById('subject-name').value.trim(),
      grade: document.getElementById('subject-grade').value.trim(),
      teacherId: document.getElementById('subject-teacher-select').value,
      totalMarks: Number(document.getElementById('subject-total-marks')?.value) || 100
    };
    SchoolDB.saveSubject(subj);
    this.closeModal('subject-form-modal');
    this.showToast('Course subject added to catalog.');
    this.renderClasses();
  },

  deleteSubjectConfirm(code) {
    if (!this.requireAdmin()) return;
    if (confirm(`Remove subject ${code}?`)) {
      SchoolDB.deleteSubject(code);
      this.showToast('Subject removed.', 'warning');
      this.renderClasses();
    }
  },

  // ==================== ATTENDANCE MODULE ====================
  renderAttendanceView() {
    this.populateClassDropdowns();
    const dateInput = document.getElementById('attendance-date-input');
    if (dateInput && !dateInput.value) {
      dateInput.value = new Date().toISOString().split('T')[0];
    }
    this.loadAttendanceSheet();
  },

  loadAttendanceSheet() {
    const classId = document.getElementById('attendance-class-select')?.value || '';
    const date = document.getElementById('attendance-date-input')?.value || new Date().toISOString().split('T')[0];
    const tbody = document.getElementById('attendance-sheet-tbody');
    if (!tbody) return;

    const currentClass = SchoolDB.getClassById(classId) || SchoolDB.getClasses()[0];
    if (!currentClass) {
      tbody.innerHTML = '<tr><td colspan="5" class="text-center text-muted">No classes available. Create a class first.</td></tr>';
      return;
    }

    // Set select value if not set
    if (!document.getElementById('attendance-class-select').value) {
      document.getElementById('attendance-class-select').value = currentClass.id;
    }

    const students = SchoolDB.getStudents().filter(s => s.grade === currentClass.name && s.section === currentClass.section);

    if (!students.length) {
      tbody.innerHTML = `<tr><td colspan="5" class="text-center text-muted">No students enrolled in ${currentClass.name} - ${currentClass.section}.</td></tr>`;
      return;
    }

    const existingAtt = SchoolDB.getAttendance(currentClass.id, date);
    const records = existingAtt?.records || {};

    let presentCount = 0;
    let lateCount = 0;
    let absentCount = 0;

    tbody.innerHTML = students.map((s, idx) => {
      const currentStatus = records[s.id] || 'Present';
      if (currentStatus === 'Present') presentCount++;
      else if (currentStatus === 'Late') lateCount++;
      else absentCount++;

      return `
        <tr>
          <td>${idx + 1}</td>
          <td><strong>${s.rollNo}</strong></td>
          <td>${s.name}</td>
          <td>
            <div class="att-radio-group">
              <label><input type="radio" name="att_${s.id}" value="Present" ${currentStatus === 'Present' ? 'checked' : ''}> Present</label>
              <label><input type="radio" name="att_${s.id}" value="Late" ${currentStatus === 'Late' ? 'checked' : ''}> Late</label>
              <label><input type="radio" name="att_${s.id}" value="Absent" ${currentStatus === 'Absent' ? 'checked' : ''}> Absent</label>
              <label><input type="radio" name="att_${s.id}" value="Excused" ${currentStatus === 'Excused' ? 'checked' : ''}> Excused</label>
            </div>
          </td>
          <td>
            <div style="display: flex; align-items: center; gap: 8px;">
              <span class="badge status-${currentStatus.toLowerCase()}">${currentStatus}</span>
              ${currentStatus === 'Absent' ? `
                <button class="action-icon-btn" onclick="App.sendWhatsAppAbsentNotice('${s.id}')" title="Send WhatsApp Absent Notice to Guardian (غیر حاضری اطلاع)" style="color: #128C7E;">&#128172;</button>
              ` : ''}
            </div>
          </td>
        </tr>
      `;
    }).join('');

    // Summary banner
    const statSummary = document.getElementById('attendance-summary-stats');
    if (statSummary) {
      statSummary.innerHTML = `
        <span class="badge status-present">&#10004; Present: ${presentCount}</span>
        <span class="badge status-late">&#9200; Late: ${lateCount}</span>
        <span class="badge status-absent">&#10060; Absent: ${absentCount}</span>
        <span class="text-muted" style="margin-left:auto; font-size:12px;">Total: ${students.length} Students</span>
      `;
    }
  },

  markAllAttendance(status) {
    if (!this.requireAdmin()) return;
    const radios = document.querySelectorAll(`#attendance-sheet-tbody input[type="radio"][value="${status}"]`);
    radios.forEach(r => r.checked = true);
    this.showToast(`Marked all as ${status}. Click 'Save Attendance' to persist.`);
  },

  saveAttendanceSheet() {
    if (!this.requireAdmin()) return;
    const classId = document.getElementById('attendance-class-select').value;
    const date = document.getElementById('attendance-date-input').value;
    const currentClass = SchoolDB.getClassById(classId);
    if (!currentClass) return;

    const students = SchoolDB.getStudents().filter(s => s.grade === currentClass.name && s.section === currentClass.section);
    const records = {};

    students.forEach(s => {
      const checked = document.querySelector(`input[name="att_${s.id}"]:checked`);
      records[s.id] = checked ? checked.value : 'Present';
    });

    SchoolDB.saveAttendance(classId, date, records);
    this.showToast('Attendance recorded and saved successfully!');
    this.loadAttendanceSheet();
    this.updateDashboardCounters();
  },

  // ==================== EXAMS & MARKS MODULE ====================
  renderExams() {
    this.populateClassDropdowns();
    const filterClass = document.getElementById('exams-filter-class')?.value || '';
    const filterTerm = document.getElementById('exams-filter-term')?.value || '';
    const tbody = document.getElementById('exams-tbody');
    if (!tbody) return;

    let marksList = SchoolDB.getMarks(filterClass, filterTerm);
    const students = SchoolDB.getStudents();
    const studentMap = {};
    students.forEach(s => studentMap[s.id] = s);

    if (!marksList.length) {
      tbody.innerHTML = `
        <tr>
          <td colspan="8">
            <div class="empty-state">
              <div class="empty-state-icon">&#128221;</div>
              <h4>No Examination Records</h4>
              <p>Click "Enter Marks" to record student exam performance.</p>
            </div>
          </td>
        </tr>
      `;
      return;
    }

    tbody.innerHTML = marksList.map(m => {
      const student = studentMap[m.studentId];
      const isComb = !!m.isCombined;
      return `
        <tr>
          <td><strong>${student?.rollNo || 'N/A'}</strong></td>
          <td>
            <strong>${student?.name || 'Unknown Student'}</strong><br>
            <small class="text-muted">${student?.grade || ''} - ${student?.section || ''}</small>
          </td>
          <td>
            ${isComb ? `<span class="badge" style="background:#eef2ff; color:#4338ca; font-weight:600;">${m.examTerm}</span>` : m.examTerm}
          </td>
          <td style="text-align:center;"><span class="badge" style="background:#f0fdf4; color:#166534; font-weight:800; padding:3px 8px; border:1px solid #bbf7d0;">${m.maxMarks || 0}</span></td>
          <td style="text-align:center;"><strong style="color:#1e3a8a; font-size:13px;">${m.totalObtained}</strong></td>
          <td style="text-align:center;"><strong>${m.percentage}%</strong></td>
          <td style="text-align:center;"><span class="grade-pill grade-${(m.grade || 'F').replace('+', 'plus')}">${m.grade}</span></td>
          <td>
            <div class="table-actions">
              <button class="btn btn-primary btn-sm" onclick="App.viewReportCard('${m.id}')" title="Print Official Transcript">
                &#128424; ${isComb ? 'Combined Report' : 'Report Card'}
              </button>
              ${isComb ? `
                <span class="badge" style="background:#f8fafc; color:#64748b; font-size:10px; border:1px solid #cbd5e1;" title="Combined aggregate calculated from 1st & 2nd Semester">Aggregated</span>
              ` : `
                <button class="action-icon-btn" onclick="App.editMarksModal('${m.id}')" title="Edit Marks">&#9998;</button>
                <button class="action-icon-btn delete" onclick="App.deleteMarksConfirm('${m.id}')" title="Delete">&#128465;</button>
              `}
            </div>
          </td>
        </tr>
      `;
    }).join('');
  },

  openEnterMarksModal() {
    if (!this.requireAdmin()) return;
    document.getElementById('marks-form').reset();
    document.getElementById('marks-id-field').value = '';
    this.populateStudentDropdown('marks-student-select');
    const firstStudentId = document.getElementById('marks-student-select')?.value || null;
    this.buildSubjectMarksInputFields({}, firstStudentId);
    this.openModal('marks-form-modal');
  },

  getCurriculumGroupForStudent(student) {
    if (!student) return 'all';
    const grade = (student.grade || '').toLowerCase();
    const section = (student.section || '').toUpperCase().trim();

    // 6th, 7th, 8th (All sections) -> Middle
    if (grade.includes('6') || grade.includes('7') || grade.includes('8')) {
      return 'middle';
    }

    // 9th and 10th
    if (grade.includes('9') || grade.includes('10')) {
      if (section === 'A') {
        return 'science';
      } else if (section === 'B' || section === 'C') {
        return 'arts';
      }
    }
    return 'all';
  },

  buildSubjectMarksInputFields(existingScores = {}, studentId = null) {
    const container = document.getElementById('marks-subjects-inputs');
    if (!container) return;

    if (!studentId) {
      studentId = document.getElementById('marks-student-select')?.value || null;
    }

    const student = studentId ? SchoolDB.getStudentById(studentId) : null;
    const group = this.getCurriculumGroupForStudent(student);
    let subjects = SchoolDB.getSubjects();

    if (group === 'middle') {
      subjects = subjects.filter(s => s.code.startsWith('MID-'));
    } else if (group === 'science') {
      subjects = subjects.filter(s => s.code.startsWith('SCI-'));
    } else if (group === 'arts') {
      subjects = subjects.filter(s => s.code.startsWith('ART-'));
    }

    if (!subjects.length) {
      container.innerHTML = '<p class="text-muted" style="grid-column:1/-1;">No curriculum subjects configured for this class and section.</p>';
      return;
    }

    let groupBadge = '';
    if (group === 'middle') {
      groupBadge = '<span class="badge" style="background:#e0f2fe; color:#0369a1; margin-bottom:8px; display:inline-block;">Middle Section (Grades 6th, 7th, 8th - 13 Subjects)</span>';
    } else if (group === 'science') {
      groupBadge = '<span class="badge" style="background:#dcfce7; color:#15803d; margin-bottom:8px; display:inline-block;">Science Group (Section A - 9 Subjects)</span>';
    } else if (group === 'arts') {
      groupBadge = '<span class="badge" style="background:#fef3c7; color:#b45309; margin-bottom:8px; display:inline-block;">Arts / General Group (Section B &amp; C - 9 Subjects)</span>';
    }

    container.innerHTML = `
      <div style="grid-column: 1 / -1; margin-bottom: 6px;">
        ${groupBadge}
      </div>
      ${subjects.map(sub => {
        const subMax = Number(sub.totalMarks) || 100;
        return `
          <div class="form-group">
            <label style="display:flex; justify-content:space-between; align-items:center;">
              <span>${sub.name} <small class="text-muted">(${sub.code})</small></span>
              <span class="badge" style="background:#e0f2fe; color:#0369a1; font-weight:700; font-size:10.5px;">Max: ${subMax}</span>
            </label>
            <input type="number" min="0" max="${subMax}" class="sub-score-input" data-code="${sub.code}" placeholder="0 - ${subMax}" value="${existingScores[sub.code] ?? ''}" required>
          </div>
        `;
      }).join('')}
    `;
  },

  editMarksModal(id) {
    if (!this.requireAdmin()) return;
    const markEntry = SchoolDB.data.marks.find(m => m.id === id);
    if (!markEntry) return;
    this.populateStudentDropdown('marks-student-select');
    document.getElementById('marks-id-field').value = markEntry.id;
    document.getElementById('marks-student-select').value = markEntry.studentId;
    document.getElementById('marks-exam-term').value = markEntry.examTerm;
    document.getElementById('marks-remarks').value = markEntry.remarks || '';
    this.buildSubjectMarksInputFields(markEntry.scores, markEntry.studentId);
    this.openModal('marks-form-modal');
  },

  saveMarksFromForm(e) {
    e.preventDefault();
    if (!this.requireAdmin()) return;
    const id = document.getElementById('marks-id-field').value;
    const studentId = document.getElementById('marks-student-select').value;
    const student = SchoolDB.getStudentById(studentId);
    const examTerm = document.getElementById('marks-exam-term').value;
    const remarks = document.getElementById('marks-remarks').value.trim();

    const scoreInputs = document.querySelectorAll('.sub-score-input');
    const scores = {};
    scoreInputs.forEach(inp => {
      const code = inp.getAttribute('data-code');
      scores[code] = Number(inp.value) || 0;
    });

    const entry = {
      studentId,
      classId: student ? student.grade : '',
      examTerm,
      scores,
      remarks
    };

    if (id) entry.id = id;

    SchoolDB.saveMarks(entry);
    this.closeModal('marks-form-modal');
    this.showToast('Examination marks saved successfully!');
    this.renderExams();
  },

  viewReportCard(markId) {
    const markRecord = SchoolDB.getMarkByIdOrCombined(markId);
    if (!markRecord) return;
    const modalBody = document.getElementById('generic-modal-body');
    const modalTitle = document.getElementById('generic-modal-title');
    modalTitle.textContent = markRecord.isCombined 
      ? 'Combined Annual Academic Transcript (مشترکہ سالانہ رزلٹ کارڈ)' 
      : 'Official Student Academic Transcript (طلبہ رزلٹ کارڈ)';
    
    modalBody.innerHTML = `
      ${ReportEngine.generateReportCardHTML(markRecord)}
      <div style="margin-top: 24px; display: flex; justify-content: flex-end; gap: 12px;">
        <button class="btn btn-primary" onclick="ReportEngine.printElement(ReportEngine.generateReportCardHTML(SchoolDB.getMarkByIdOrCombined('${markRecord.id}')))">
          &#128424; Print Official Report Card
        </button>
      </div>
    `;
    this.openModal('generic-modal');
  },

  deleteMarksConfirm(id) {
    if (!this.requireAdmin()) return;
    if (confirm('Delete marks entry?')) {
      SchoolDB.deleteMarks(id);
      this.showToast('Marks deleted.', 'warning');
      this.renderExams();
    }
  },

  // ==================== SUBJECT TOTAL MARKS (OUT OF) MODULE ====================
  openSubjectMaxMarksModal() {
    if (!this.requireAdmin()) return;
    this.renderSubjectMaxMarksInputs();
    this.openModal('subject-max-marks-modal');
  },

  renderSubjectMaxMarksInputs() {
    const grid = document.getElementById('subject-max-marks-grid');
    if (!grid) return;

    const filterGroup = document.getElementById('subject-max-marks-filter-group')?.value || 'all';
    let subjects = SchoolDB.getSubjects();

    if (filterGroup === 'middle') {
      subjects = subjects.filter(s => s.code.startsWith('MID-'));
    } else if (filterGroup === 'science') {
      subjects = subjects.filter(s => s.code.startsWith('SCI-'));
    } else if (filterGroup === 'arts') {
      subjects = subjects.filter(s => s.code.startsWith('ART-'));
    }

    if (!subjects.length) {
      grid.innerHTML = '<p class="text-muted" style="grid-column: 1 / -1;">No curriculum subjects match this filter.</p>';
      return;
    }

    grid.innerHTML = subjects.map(sub => {
      const currentMax = Number(sub.totalMarks) || 100;
      let badgeColor = '#0369a1';
      let badgeBg = '#e0f2fe';
      let groupLabel = 'Middle';
      if (sub.code.startsWith('SCI-')) {
        badgeColor = '#15803d'; badgeBg = '#dcfce7'; groupLabel = 'Science';
      } else if (sub.code.startsWith('ART-')) {
        badgeColor = '#b45309'; badgeBg = '#fef3c7'; groupLabel = 'Arts';
      }

      return `
        <div style="background: #ffffff; border: 1.5px solid #cbd5e1; border-radius: 8px; padding: 12px 14px; box-shadow: 0 1px 3px rgba(0,0,0,0.04);">
          <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 8px;">
            <div>
              <strong style="font-size: 13px; color: var(--text-main); display: block;">${sub.name}</strong>
              <small style="color: #64748b; font-family: monospace;">${sub.code}</small>
            </div>
            <span class="badge" style="background: ${badgeBg}; color: ${badgeColor}; font-size: 10px; font-weight: 700;">${groupLabel}</span>
          </div>
          <div style="margin-top: 6px;">
            <label style="font-size: 11.5px; font-weight: 600; color: #475569; display: flex; justify-content: space-between; margin-bottom: 4px;">
              <span>Total Marks (Out of)</span>
              <span style="color: #1e3a8a; font-weight: 800;">${currentMax}</span>
            </label>
            <input type="number" min="1" max="500" class="sub-total-marks-input select-filter" style="width: 100%; font-weight: 700; color: #1e3a8a;" data-code="${sub.code}" value="${currentMax}" required>
          </div>
        </div>
      `;
    }).join('');
  },

  batchSetSubjectTotalMarks(val) {
    const inputs = document.querySelectorAll('#subject-max-marks-grid .sub-total-marks-input');
    inputs.forEach(inp => {
      inp.value = val;
    });
    this.showToast(`Set visible subject inputs to ${val} marks.`);
  },

  saveSubjectMaxMarksFromForm(e) {
    e.preventDefault();
    if (!this.requireAdmin()) return;

    const inputs = document.querySelectorAll('#subject-max-marks-modal .sub-total-marks-input');
    const marksMap = {};
    inputs.forEach(inp => {
      const code = inp.getAttribute('data-code');
      const val = Number(inp.value) || 100;
      if (code) marksMap[code] = val;
    });

    SchoolDB.saveSubjectTotalMarksMap(marksMap);
    this.closeModal('subject-max-marks-modal');
    this.showToast('Subject total marks (out of) updated successfully!');
    this.renderClasses();
    this.renderExams();
  },

  // ==================== FEES MODULE ====================
  renderFees() {
    const tbody = document.getElementById('fees-tbody');
    if (!tbody) return;

    let fees = SchoolDB.getFees();
    const filterStatus = document.getElementById('fees-filter-status')?.value || '';
    const query = (document.getElementById('fees-search')?.value || '').toLowerCase().trim();

    const students = SchoolDB.getStudents();
    const studentMap = {};
    students.forEach(s => studentMap[s.id] = s);

    fees = fees.filter(f => {
      let match = true;
      if (filterStatus) match = match && f.status === filterStatus;
      if (query) {
        const student = studentMap[f.studentId];
        match = match && (
          f.id.toLowerCase().includes(query) ||
          f.feeType.toLowerCase().includes(query) ||
          (student && student.name.toLowerCase().includes(query))
        );
      }
      return match;
    });

    if (!fees.length) {
      tbody.innerHTML = `
        <tr>
          <td colspan="8">
            <div class="empty-state">
              <div class="empty-state-icon">&#128181;</div>
              <h4>No Billing Records</h4>
              <p>Click "Create Invoice" to issue a fee voucher.</p>
            </div>
          </td>
        </tr>
      `;
      return;
    }

    const currency = SchoolDB.data.settings?.currency || '$';

    tbody.innerHTML = fees.map(f => {
      const student = studentMap[f.studentId];
      const balance = f.amount - f.paidAmount;
      return `
        <tr>
          <td><strong>${f.id}</strong></td>
          <td>
            <strong>${student?.name || 'Unknown'}</strong><br>
            <small class="text-muted">${student?.grade || ''} - ${student?.section || ''}</small>
          </td>
          <td>${f.feeType}</td>
          <td>${currency}${f.amount.toLocaleString()}</td>
          <td class="text-success font-bold">${currency}${f.paidAmount.toLocaleString()}</td>
          <td class="${balance > 0 ? 'text-danger font-bold' : 'text-muted'}">${currency}${balance.toLocaleString()}</td>
          <td><span class="badge status-${f.status.toLowerCase()}">${f.status}</span></td>
          <td>
            <div class="table-actions">
              <button class="action-icon-btn" onclick="App.sendWhatsAppFeeReminder('${f.id}')" title="Send WhatsApp Fee Reminder (فیس یاد دہانی)" style="color: #128C7E;">&#128172;</button>
              <button class="action-icon-btn" onclick="App.viewFeeReceipt('${f.id}')" title="Print Fee Receipt">&#128424;</button>
              <button class="action-icon-btn" onclick="App.quickPayFeeModal('${f.id}')" title="Update Payment">&#128179;</button>
              <button class="action-icon-btn delete" onclick="App.deleteFeeConfirm('${f.id}')" title="Delete">&#128465;</button>
            </div>
          </td>
        </tr>
      `;
    }).join('');
  },

  openAddFeeModal() {
    if (!this.requireAdmin()) return;
    document.getElementById('fee-form').reset();
    document.getElementById('fee-id-field').value = '';
    this.populateStudentDropdown('fee-student-select');
    this.openModal('fee-form-modal');
  },

  saveFeeFromForm(e) {
    e.preventDefault();
    if (!this.requireAdmin()) return;
    const id = document.getElementById('fee-id-field').value;
    const fee = {
      studentId: document.getElementById('fee-student-select').value,
      feeType: document.getElementById('fee-type-input').value.trim(),
      amount: Number(document.getElementById('fee-amount-input').value) || 0,
      paidAmount: Number(document.getElementById('fee-paid-input').value) || 0,
      dueDate: document.getElementById('fee-due-date').value,
      paidDate: document.getElementById('fee-paid-date').value,
      method: document.getElementById('fee-method-select').value
    };

    if (id) fee.id = id;

    SchoolDB.saveFee(fee);
    this.closeModal('fee-form-modal');
    this.showToast('Fee invoice updated successfully!');
    this.renderFees();
    this.updateDashboardCounters();
  },

  quickPayFeeModal(feeId) {
    if (!this.requireAdmin()) return;
    const fee = SchoolDB.data.fees.find(f => f.id === feeId);
    if (!fee) return;
    this.populateStudentDropdown('fee-student-select');
    document.getElementById('fee-id-field').value = fee.id;
    document.getElementById('fee-student-select').value = fee.studentId;
    document.getElementById('fee-type-input').value = fee.feeType;
    document.getElementById('fee-amount-input').value = fee.amount;
    document.getElementById('fee-paid-input').value = fee.paidAmount;
    document.getElementById('fee-due-date').value = fee.dueDate || '';
    document.getElementById('fee-paid-date').value = fee.paidDate || new Date().toISOString().split('T')[0];
    document.getElementById('fee-method-select').value = fee.method || 'Cash';
    this.openModal('fee-form-modal');
  },

  viewFeeReceipt(feeId) {
    const fee = SchoolDB.data.fees.find(f => f.id === feeId);
    if (!fee) return;
    const modalBody = document.getElementById('generic-modal-body');
    const modalTitle = document.getElementById('generic-modal-title');
    modalTitle.textContent = 'Official School Fee Receipt';
    
    modalBody.innerHTML = `
      ${ReportEngine.generateFeeReceiptHTML(fee)}
      <div style="margin-top: 24px; display: flex; justify-content: flex-end; gap: 12px;">
        <button class="btn btn-primary" onclick="ReportEngine.printElement(ReportEngine.generateFeeReceiptHTML(SchoolDB.data.fees.find(f => f.id === '${fee.id}')))">
          &#128424; Print Payment Voucher
        </button>
      </div>
    `;
    this.openModal('generic-modal');
  },

  deleteFeeConfirm(id) {
    if (!this.requireAdmin()) return;
    if (confirm('Delete fee record?')) {
      SchoolDB.deleteFee(id);
      this.showToast('Fee invoice deleted.', 'warning');
      this.renderFees();
      this.updateDashboardCounters();
    }
  },

  // ==================== NOTICES MODULE ====================
  renderNotices() {
    const container = document.getElementById('notices-cards-grid');
    if (!container) return;
    const notices = SchoolDB.getNotices();
    const filterAudience = document.getElementById('notices-filter-audience')?.value || '';

    const list = notices.filter(n => !filterAudience || n.audience === filterAudience || n.audience === 'All');

    if (!list.length) {
      container.innerHTML = '<div class="empty-state"><h4>No Announcements</h4><p>Post school circulars and reminders here.</p></div>';
      return;
    }

    container.innerHTML = list.map(n => `
      <div class="panel-card" style="margin-bottom:0;">
        <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:8px;">
          <h3 style="font-size:16px; font-weight:700; color:var(--text-main);">${n.title}</h3>
          <span class="badge status-${n.priority.toLowerCase()}">${n.priority}</span>
        </div>
        <p style="font-size:13px; color:var(--text-main); line-height:1.6; margin-bottom:16px;">${n.content}</p>
        <div style="display:flex; justify-content:space-between; align-items:center; border-top:1px solid var(--border-light); padding-top:12px; font-size:11px; color:var(--text-muted);">
          <span>&#128197; ${n.date} &bull; Audience: <strong>${n.audience}</strong></span>
          <button class="action-icon-btn delete" onclick="App.deleteNoticeConfirm('${n.id}')" title="Delete">&#128465;</button>
        </div>
      </div>
    `).join('');
  },

  openAddNoticeModal() {
    if (!this.requireAdmin()) return;
    document.getElementById('notice-form').reset();
    this.openModal('notice-form-modal');
  },

  saveNoticeFromForm(e) {
    e.preventDefault();
    if (!this.requireAdmin()) return;
    const notice = {
      title: document.getElementById('notice-title').value.trim(),
      date: document.getElementById('notice-date').value || new Date().toISOString().split('T')[0],
      audience: document.getElementById('notice-audience').value,
      priority: document.getElementById('notice-priority').value,
      content: document.getElementById('notice-content').value.trim()
    };
    SchoolDB.saveNotice(notice);
    this.closeModal('notice-form-modal');
    this.showToast('Announcement posted to notice board.');
    this.renderNotices();
  },

  deleteNoticeConfirm(id) {
    if (!this.requireAdmin()) return;
    if (confirm('Delete announcement?')) {
      SchoolDB.deleteNotice(id);
      this.showToast('Announcement deleted.', 'warning');
      this.renderNotices();
    }
  },

  // ==================== STOCK MODULE (GENERAL & PTC) ====================
  renderStock(type = 'general') {
    const isPTC = type === 'ptc';
    const prefix = isPTC ? 'stock-ptc' : 'stock-gen';
    const tbody = document.getElementById(`${prefix}-tbody`);
    if (!tbody) return;

    const query = (document.getElementById(`${prefix}-search`)?.value || '').toLowerCase().trim();
    const filterCategory = document.getElementById(`${prefix}-filter-category`)?.value || '';
    const filterCondition = document.getElementById(`${prefix}-filter-condition`)?.value || '';
    const filterYear = isPTC ? (document.getElementById('stock-ptc-filter-year')?.value || '') : '';

    const allItems = SchoolDB.getStockItems(type);
    const filteredItems = SchoolDB.getStockItems(type, filterCategory, filterCondition, query, filterYear);

    // Update Metrics
    let totalQty = 0;
    let totalWorth = 0;
    let workingCount = 0;
    let otherCount = 0;

    allItems.forEach(item => {
      totalQty += Number(item.quantity) || 0;
      totalWorth += Number(item.totalCost) || 0;
      const cond = (item.condition || '').toLowerCase();
      if (cond.includes('repair') || cond.includes('condemn') || cond.includes('write')) {
        otherCount++;
      } else {
        workingCount++;
      }
    });

    const currency = SchoolDB.data.settings?.currency || 'Rs. ';
    const countItemsEl = document.getElementById(`${prefix}-count-items`);
    if (countItemsEl) countItemsEl.textContent = allItems.length;

    const countQtyEl = document.getElementById(`${prefix}-count-qty`);
    if (countQtyEl) countQtyEl.textContent = totalQty.toLocaleString();

    const totalWorthEl = document.getElementById(`${prefix}-total-worth`);
    if (totalWorthEl) totalWorthEl.textContent = `${currency}${totalWorth.toLocaleString()}`;

    const statusSumEl = document.getElementById(`${prefix}-status-summary`);
    if (statusSumEl) statusSumEl.textContent = `${workingCount} / ${allItems.length}`;

    const workingRateEl = document.getElementById(`${prefix}-working-rate`);
    if (workingRateEl) {
      const pct = allItems.length > 0 ? Math.round((workingCount / allItems.length) * 100) : 100;
      workingRateEl.textContent = `${pct}% Usable (کارآمد)`;
    }

    // Update sidebar badge
    const badgeEl = document.getElementById(isPTC ? 'sidebar-count-stock-ptc' : 'sidebar-count-stock-general');
    if (badgeEl) badgeEl.textContent = allItems.length;

    if (!filteredItems.length) {
      tbody.innerHTML = `
        <tr>
          <td colspan="${isPTC ? 10 : 9}">
            <div class="empty-state">
              <div class="empty-state-icon">${isPTC ? '&#128203;' : '&#128230;'}</div>
              <h4>No ${isPTC ? 'PTC' : 'General'} Stock Items Found</h4>
              <p>Click "Add ${isPTC ? 'PTC' : 'Stock'} Item" to register articles in this register.</p>
            </div>
          </td>
        </tr>
      `;
      return;
    }

    tbody.innerHTML = filteredItems.map(item => {
      let condBadge = '';
      const cond = (item.condition || '').toLowerCase();
      if (cond.includes('repair')) {
        condBadge = `<span class="badge" style="background:#fef3c7; color:#b45309;">Under Repair (زیر مرمت)</span>`;
      } else if (cond.includes('condemn') || cond.includes('write')) {
        condBadge = `<span class="badge" style="background:#fee2e2; color:#b91c1c;">Condemned (ناکارہ)</span>`;
      } else {
        condBadge = `<span class="badge status-active">Working (کارآمد)</span>`;
      }

      const releaseYearCol = isPTC ? `
        <td>
          <span class="badge" style="background:#ede9fe; color:#6d28d9; font-weight:700; white-space:nowrap;">
            ${item.releaseYear || '2024 - 2025'}
          </span>
        </td>
      ` : '';

      return `
        <tr>
          <td><strong style="color: var(--primary);">${item.itemCode || '-'}</strong></td>
          <td>
            <div style="font-weight: 600; color: var(--text-main);">${item.name}</div>
            <small class="text-muted">${item.billNo ? item.billNo : ''} ${item.remarks ? `&bull; ${item.remarks}` : ''}</small>
          </td>
          ${releaseYearCol}
          <td><span class="badge" style="background:#f1f5f9; color:#475569;">${item.category || 'General'}</span></td>
          <td>${item.date || '-'}</td>
          <td><strong>${item.quantity}</strong> <small class="text-muted">${item.unit || 'Nos'}</small></td>
          <td><strong>${currency}${(Number(item.totalCost) || 0).toLocaleString()}</strong></td>
          <td>${item.location || '-'}</td>
          <td>${condBadge}</td>
          <td>
            <div class="table-actions">
              <button class="action-icon-btn" onclick="App.editStockModal('${type}', '${item.id}')" title="Edit Stock Item">&#9998;</button>
              <button class="action-icon-btn delete" onclick="App.deleteStockConfirm('${type}', '${item.id}')" title="Remove Record">&#128465;</button>
            </div>
          </td>
        </tr>
      `;
    }).join('');
  },

  openAddStockModal(type = 'general') {
    if (!this.requireAdmin()) return;
    const form = document.getElementById('stock-item-form');
    if (form) form.reset();
    document.getElementById('stock-item-id').value = '';
    document.getElementById('stock-item-type').value = type;
    document.getElementById('stock-item-date').value = new Date().toISOString().split('T')[0];
    document.getElementById('stock-item-condition').value = 'Working';
    document.getElementById('stock-item-unit').value = 'Nos';

    const yearGroup = document.getElementById('stock-item-release-year-group');
    const yearInput = document.getElementById('stock-item-release-year');
    if (yearGroup) {
      yearGroup.style.display = type === 'ptc' ? 'block' : 'none';
    }
    if (yearInput) {
      yearInput.value = type === 'ptc' ? '2024 - 2025' : '';
      yearInput.required = (type === 'ptc');
    }
    
    const count = SchoolDB.getStockItems(type).length + 1;
    document.getElementById('stock-item-code').value = `${type === 'ptc' ? 'PTC' : 'GEN'}-${String(count).padStart(3, '0')}`;

    const titleEl = document.getElementById('stock-modal-title');
    if (titleEl) {
      titleEl.innerHTML = type === 'ptc' 
        ? `New PTC Stock Entry <span class="urdu-title">(نیا اندراج پی ٹی سی اسٹاک)</span>`
        : `New General Stock Entry <span class="urdu-title">(نیا اندراج جنرل اسٹاک)</span>`;
    }
    this.openModal('stock-item-modal');
  },

  calculateStockTotalCost() {
    const qty = Number(document.getElementById('stock-item-qty')?.value) || 0;
    const unitPrice = Number(document.getElementById('stock-item-unitprice')?.value) || 0;
    if (qty > 0 && unitPrice > 0) {
      const totalCostEl = document.getElementById('stock-item-totalcost');
      if (totalCostEl) totalCostEl.value = qty * unitPrice;
    }
  },

  editStockModal(type, id) {
    if (!this.requireAdmin()) return;
    const item = SchoolDB.getStockItemById(type, id);
    if (!item) return;

    document.getElementById('stock-item-id').value = item.id;
    document.getElementById('stock-item-type').value = type;
    document.getElementById('stock-item-name').value = item.name || '';
    document.getElementById('stock-item-code').value = item.itemCode || '';
    document.getElementById('stock-item-category').value = item.category || '';
    document.getElementById('stock-item-date').value = item.date || new Date().toISOString().split('T')[0];
    document.getElementById('stock-item-qty').value = item.quantity || 1;
    document.getElementById('stock-item-unit').value = item.unit || 'Nos';
    document.getElementById('stock-item-unitprice').value = item.unitPrice || 0;
    document.getElementById('stock-item-totalcost').value = item.totalCost || 0;
    document.getElementById('stock-item-bill').value = item.billNo || '';
    document.getElementById('stock-item-location').value = item.location || '';
    document.getElementById('stock-item-condition').value = item.condition || 'Working';
    document.getElementById('stock-item-remarks').value = item.remarks || '';

    const yearGroup = document.getElementById('stock-item-release-year-group');
    const yearInput = document.getElementById('stock-item-release-year');
    if (yearGroup) {
      yearGroup.style.display = type === 'ptc' ? 'block' : 'none';
    }
    if (yearInput) {
      yearInput.value = item.releaseYear || (type === 'ptc' ? '2024 - 2025' : '');
      yearInput.required = (type === 'ptc');
    }

    const titleEl = document.getElementById('stock-modal-title');
    if (titleEl) {
      titleEl.innerHTML = `Edit Stock Item: ${item.name}`;
    }
    this.openModal('stock-item-modal');
  },

  saveStockFromForm(e) {
    if (e && e.preventDefault) e.preventDefault();
    if (!this.requireAdmin()) return;

    const type = document.getElementById('stock-item-type').value || 'general';
    const id = document.getElementById('stock-item-id').value;
    const qty = Number(document.getElementById('stock-item-qty').value) || 1;
    const unitPrice = Number(document.getElementById('stock-item-unitprice').value) || 0;
    let totalCost = Number(document.getElementById('stock-item-totalcost').value);
    if (!totalCost && qty && unitPrice) totalCost = qty * unitPrice;

    const item = {
      name: document.getElementById('stock-item-name').value.trim(),
      itemCode: document.getElementById('stock-item-code').value.trim(),
      category: document.getElementById('stock-item-category').value.trim() || 'General',
      date: document.getElementById('stock-item-date').value || new Date().toISOString().split('T')[0],
      quantity: qty,
      unit: document.getElementById('stock-item-unit').value,
      unitPrice: unitPrice,
      totalCost: totalCost || 0,
      billNo: document.getElementById('stock-item-bill').value.trim(),
      location: document.getElementById('stock-item-location').value.trim(),
      condition: document.getElementById('stock-item-condition').value,
      remarks: document.getElementById('stock-item-remarks').value.trim()
    };

    if (type === 'ptc') {
      const yearVal = document.getElementById('stock-item-release-year')?.value?.trim();
      item.releaseYear = yearVal || '2024 - 2025';
    }

    if (id) item.id = id;

    SchoolDB.saveStockItem(type, item);
    this.closeModal('stock-item-modal');
    this.showToast(`Stock item "${item.name}" saved successfully!`);
    this.renderStock(type);
    this.updateDashboardCounters();
  },

  deleteStockConfirm(type, id) {
    if (!this.requireAdmin()) return;
    const item = SchoolDB.getStockItemById(type, id);
    if (!item) return;

    if (confirm(`Are you sure you want to remove "${item.name}" from ${type === 'ptc' ? 'PTC' : 'General'} Stock Register?`)) {
      SchoolDB.deleteStockItem(type, id);
      this.showToast('Stock item record removed.', 'warning');
      this.renderStock(type);
      this.updateDashboardCounters();
    }
  },

  // ==================== FREE TEXT BOOKS (مفت درسی کتب) MODULE ====================
  renderFreeTextBooks() {
    const tbody = document.getElementById('ftb-tbody');
    const tfoot = document.getElementById('ftb-tfoot');
    if (!tbody) return;

    const query = (document.getElementById('ftb-search')?.value || '').toLowerCase().trim();
    const filterYear = document.getElementById('ftb-filter-year')?.value || '';
    const filterGrade = document.getElementById('ftb-filter-grade')?.value || '';

    const allBooks = SchoolDB.getFreeTextBooks();
    const filteredBooks = SchoolDB.getFreeTextBooks(filterYear, filterGrade, query);

    // Compute Metrics across allBooks
    let totalReceivedNew = 0;
    let totalDistributedNew = 0;
    let totalCollectedOld = 0;
    let totalDistributedOld = 0;
    let totalStockNew = 0;
    let totalStockOld = 0;
    let totalBalance = 0;

    allBooks.forEach(b => {
      totalReceivedNew += Number(b.receivedNew) || 0;
      totalDistributedNew += Number(b.distributedNew) || 0;
      totalCollectedOld += Number(b.collectedOld) || 0;
      totalDistributedOld += Number(b.distributedOld) || 0;
      totalStockNew += Number(b.stockNew) || 0;
      totalStockOld += Number(b.stockOld) || 0;
      totalBalance += Number(b.balance) || 0;
    });

    const countItemsEl = document.getElementById('ftb-count-items');
    if (countItemsEl) countItemsEl.textContent = allBooks.length;

    const countRecEl = document.getElementById('ftb-count-received');
    if (countRecEl) countRecEl.textContent = totalReceivedNew.toLocaleString();

    const countDistEl = document.getElementById('ftb-count-distributed');
    if (countDistEl) countDistEl.textContent = (totalDistributedNew + totalDistributedOld).toLocaleString();

    const distBreakdownEl = document.getElementById('ftb-dist-breakdown');
    if (distBreakdownEl) {
      distBreakdownEl.textContent = `${totalDistributedNew.toLocaleString()} New + ${totalDistributedOld.toLocaleString()} Old Distributed`;
    }

    const countBalEl = document.getElementById('ftb-count-balance');
    if (countBalEl) countBalEl.textContent = totalBalance.toLocaleString();

    const stockBreakdownEl = document.getElementById('ftb-stock-breakdown');
    if (stockBreakdownEl) {
      stockBreakdownEl.textContent = `${totalStockNew.toLocaleString()} New + ${totalStockOld.toLocaleString()} Old in Stock`;
    }

    // Sidebar badge
    const badgeEl = document.getElementById('sidebar-count-free-textbooks');
    if (badgeEl) badgeEl.textContent = allBooks.length;

    if (!filteredBooks.length) {
      tbody.innerHTML = `
        <tr>
          <td colspan="12">
            <div class="empty-state">
              <div class="empty-state-icon">&#128218;</div>
              <h4>No Free Text Book Records Found</h4>
              <p>Click "+ Add Book Entry" to add books received and distributed from 2012 onwards.</p>
            </div>
          </td>
        </tr>
      `;
      if (tfoot) tfoot.innerHTML = '';
      return;
    }

    // Filtered totals for tfoot
    let fRecNew = 0, fDistNew = 0, fCollOld = 0, fDistOld = 0, fTotDist = 0, fStockOld = 0, fStockNew = 0, fBal = 0;

    tbody.innerHTML = filteredBooks.map(item => {
      const recNew = Number(item.receivedNew) || 0;
      const distNew = Number(item.distributedNew) || 0;
      const collOld = Number(item.collectedOld) || 0;
      const distOld = Number(item.distributedOld) || 0;
      const totDist = distNew + distOld;
      const sOld = item.stockOld !== undefined ? Number(item.stockOld) : Math.max(0, collOld - distOld);
      const sNew = item.stockNew !== undefined ? Number(item.stockNew) : Math.max(0, recNew - distNew);
      const bal = item.balance !== undefined ? Number(item.balance) : (sNew + sOld);

      fRecNew += recNew;
      fDistNew += distNew;
      fCollOld += collOld;
      fDistOld += distOld;
      fTotDist += totDist;
      fStockOld += sOld;
      fStockNew += sNew;
      fBal += bal;

      return `
        <tr>
          <td>
            <span class="badge" style="background:#ecfdf5; color:#065f46; font-weight:700; white-space:nowrap;">
              ${item.year || '2024 - 2025'}
            </span>
          </td>
          <td>
            <strong style="color:var(--primary); white-space:nowrap;">${item.grade || 'Grade 6'}</strong>
          </td>
          <td>
            <div style="font-weight:600; color:var(--text-main); font-size:13px;">${item.bookTitle}</div>
            ${item.remarks ? `<small class="text-muted">${item.remarks}</small>` : ''}
          </td>
          <td style="text-align:center; font-weight:600; color:#0f766e;">${recNew}</td>
          <td style="text-align:center; font-weight:600; color:#1d4ed8;">${distNew}</td>
          <td style="text-align:center; font-weight:600; color:#b45309;">${collOld}</td>
          <td style="text-align:center; font-weight:600; color:#7c3aed;">${distOld}</td>
          <td style="text-align:center;">
            <span class="badge" style="background:#eff6ff; color:#1d4ed8; font-weight:800; font-size:12px; padding:3px 8px; border:1px solid #bfdbfe;">
              ${totDist}
            </span>
          </td>
          <td style="text-align:center;">
            <span class="badge" style="background:${sOld > 0 ? '#fef3c7' : '#f1f5f9'}; color:${sOld > 0 ? '#b45309' : '#64748b'}; font-weight:700;">
              ${sOld}
            </span>
          </td>
          <td style="text-align:center;">
            <span class="badge" style="background:${sNew > 0 ? '#dcfce7' : '#f1f5f9'}; color:${sNew > 0 ? '#15803d' : '#64748b'}; font-weight:700;">
              ${sNew}
            </span>
          </td>
          <td style="text-align:center;">
            <span class="badge" style="background:#059669; color:#ffffff; font-weight:800; font-size:12px; padding:3px 8px;">
              ${bal}
            </span>
          </td>
          <td style="text-align:center; white-space:nowrap;">
            <button class="action-btn edit-btn" title="Edit Book Entry" onclick="App.editFreeTextBookModal('${item.id}')">&#9998;</button>
            <button class="action-btn delete-btn" title="Delete Book Entry" onclick="App.deleteFreeTextBookConfirm('${item.id}')">&#128465;</button>
          </td>
        </tr>
      `;
    }).join('');

    if (tfoot) {
      tfoot.innerHTML = `
        <tr style="background:#f1f5f9; border-top:2px solid #cbd5e1;">
          <td colspan="3" style="text-align:right; font-weight:800; color:#0f172a; padding:10px;">
            Total Count: ${filteredBooks.length} Books / مجموعی میزان:
          </td>
          <td style="text-align:center; font-weight:800; color:#0f766e;">${fRecNew.toLocaleString()}</td>
          <td style="text-align:center; font-weight:800; color:#1d4ed8;">${fDistNew.toLocaleString()}</td>
          <td style="text-align:center; font-weight:800; color:#b45309;">${fCollOld.toLocaleString()}</td>
          <td style="text-align:center; font-weight:800; color:#7c3aed;">${fDistOld.toLocaleString()}</td>
          <td style="text-align:center; font-weight:900; color:#1e40af; background:#dbeafe;">${fTotDist.toLocaleString()}</td>
          <td style="text-align:center; font-weight:800; color:#b45309;">${fStockOld.toLocaleString()}</td>
          <td style="text-align:center; font-weight:800; color:#15803d;">${fStockNew.toLocaleString()}</td>
          <td style="text-align:center; font-weight:900; color:#065f46; font-size:13px; background:#dcfce7;">${fBal.toLocaleString()}</td>
          <td></td>
        </tr>
      `;
    }
  },

  openAddFreeTextBookModal() {
    if (!this.requireAdmin()) return;
    const form = document.getElementById('free-textbook-form');
    if (form) form.reset();

    document.getElementById('ftb-id').value = '';

    const filterYear = document.getElementById('ftb-filter-year')?.value;
    const filterGrade = document.getElementById('ftb-filter-grade')?.value;

    if (filterYear) document.getElementById('ftb-year').value = filterYear;
    else document.getElementById('ftb-year').value = '2024 - 2025';

    if (filterGrade) document.getElementById('ftb-grade').value = filterGrade;
    else document.getElementById('ftb-grade').value = 'Grade 6';

    document.getElementById('ftb-title').value = '';
    document.getElementById('ftb-received-new').value = '0';
    document.getElementById('ftb-distributed-new').value = '0';
    document.getElementById('ftb-stock-new').value = '0';
    document.getElementById('ftb-collected-old').value = '0';
    document.getElementById('ftb-distributed-old').value = '0';
    const totDistInput = document.getElementById('ftb-total-distributed');
    if (totDistInput) totDistInput.value = '0';
    document.getElementById('ftb-stock-old').value = '0';
    document.getElementById('ftb-balance').value = '0';
    document.getElementById('ftb-remarks').value = '';

    const titleEl = document.getElementById('free-textbook-modal-title');
    if (titleEl) {
      titleEl.innerHTML = `New Free Text Book Entry <span class="urdu-title">(نیا اندراج مفت درسی کتب)</span>`;
    }
    this.openModal('free-textbook-modal');
  },

  calculateFreeTextBookStock(manualOverride = false) {
    const recNew = Number(document.getElementById('ftb-received-new')?.value) || 0;
    const distNew = Number(document.getElementById('ftb-distributed-new')?.value) || 0;
    const collOld = Number(document.getElementById('ftb-collected-old')?.value) || 0;
    const distOld = Number(document.getElementById('ftb-distributed-old')?.value) || 0;

    let sNewEl = document.getElementById('ftb-stock-new');
    let sOldEl = document.getElementById('ftb-stock-old');
    let balEl = document.getElementById('ftb-balance');
    let totDistEl = document.getElementById('ftb-total-distributed');

    if (totDistEl) {
      totDistEl.value = distNew + distOld;
    }

    if (!manualOverride) {
      if (sNewEl) sNewEl.value = Math.max(0, recNew - distNew);
      if (sOldEl) sOldEl.value = Math.max(0, collOld - distOld);
    }

    const sNew = Number(sNewEl?.value) || 0;
    const sOld = Number(sOldEl?.value) || 0;
    if (balEl) balEl.value = sNew + sOld;
  },

  editFreeTextBookModal(id) {
    if (!this.requireAdmin()) return;
    const item = SchoolDB.getFreeTextBookById(id);
    if (!item) return;

    document.getElementById('ftb-id').value = item.id;
    document.getElementById('ftb-year').value = item.year || '2024 - 2025';
    document.getElementById('ftb-grade').value = item.grade || 'Grade 6';
    document.getElementById('ftb-title').value = item.bookTitle || '';
    document.getElementById('ftb-received-new').value = item.receivedNew ?? 0;
    document.getElementById('ftb-distributed-new').value = item.distributedNew ?? 0;
    document.getElementById('ftb-stock-new').value = item.stockNew ?? (Math.max(0, (item.receivedNew || 0) - (item.distributedNew || 0)));
    document.getElementById('ftb-collected-old').value = item.collectedOld ?? 0;
    document.getElementById('ftb-distributed-old').value = item.distributedOld ?? 0;
    const totDistInput = document.getElementById('ftb-total-distributed');
    if (totDistInput) {
      totDistInput.value = (Number(item.distributedNew) || 0) + (Number(item.distributedOld) || 0);
    }
    document.getElementById('ftb-stock-old').value = item.stockOld ?? (Math.max(0, (item.collectedOld || 0) - (item.distributedOld || 0)));
    document.getElementById('ftb-balance').value = item.balance ?? ((Number(document.getElementById('ftb-stock-new').value) || 0) + (Number(document.getElementById('ftb-stock-old').value) || 0));
    document.getElementById('ftb-remarks').value = item.remarks || '';

    const titleEl = document.getElementById('free-textbook-modal-title');
    if (titleEl) {
      titleEl.innerHTML = `Edit Free Text Book: ${item.bookTitle} (${item.grade})`;
    }
    this.openModal('free-textbook-modal');
  },

  saveFreeTextBookFromForm(e) {
    if (e && e.preventDefault) e.preventDefault();
    if (!this.requireAdmin()) return;

    const id = document.getElementById('ftb-id').value;
    const year = document.getElementById('ftb-year').value;
    const grade = document.getElementById('ftb-grade').value;
    const bookTitle = document.getElementById('ftb-title').value.trim();
    const receivedNew = Number(document.getElementById('ftb-received-new').value) || 0;
    const distributedNew = Number(document.getElementById('ftb-distributed-new').value) || 0;
    const stockNew = Number(document.getElementById('ftb-stock-new').value) || 0;
    const collectedOld = Number(document.getElementById('ftb-collected-old').value) || 0;
    const distributedOld = Number(document.getElementById('ftb-distributed-old').value) || 0;
    const stockOld = Number(document.getElementById('ftb-stock-old').value) || 0;
    const balance = Number(document.getElementById('ftb-balance').value) || (stockNew + stockOld);
    const remarks = document.getElementById('ftb-remarks').value.trim();

    if (!bookTitle) {
      alert('Please enter Book Title / Subject.');
      return;
    }

    const payload = {
      id: id || undefined,
      year,
      grade,
      bookTitle,
      receivedNew,
      distributedNew,
      stockNew,
      collectedOld,
      distributedOld,
      stockOld,
      balance,
      remarks
    };

    const saved = SchoolDB.saveFreeTextBook(payload);
    if (!saved) {
      alert('Error saving Free Text Book entry.');
      return;
    }

    this.closeModal('free-textbook-modal');
    this.showToast(`Free text book "${bookTitle}" for ${grade} saved successfully!`);
    this.renderFreeTextBooks();
    this.updateDashboardCounters();
  },

  deleteFreeTextBookConfirm(id) {
    if (!this.requireAdmin()) return;
    const item = SchoolDB.getFreeTextBookById(id);
    if (!item) return;

    if (confirm(`Are you sure you want to delete "${item.bookTitle}" (${item.grade} - ${item.year}) from Free Text Books register?`)) {
      SchoolDB.deleteFreeTextBook(id);
      this.showToast('Book entry deleted from register.', 'warning');
      this.renderFreeTextBooks();
      this.updateDashboardCounters();
    }
  },

  pendingCSVBooks: null,

  openFreeTextBookCSVModal() {
    if (!this.requireAdmin()) return;
    this.pendingCSVBooks = null;

    const fileInput = document.getElementById('ftb-csv-file-input');
    if (fileInput) fileInput.value = '';

    const prev = document.getElementById('ftb-csv-preview-container');
    if (prev) prev.style.display = 'none';

    const btn = document.getElementById('btn-confirm-ftb-csv-import');
    if (btn) btn.disabled = true;

    const dropzone = document.getElementById('ftb-csv-dropzone');
    if (dropzone) {
      dropzone.style.borderColor = '#059669';
      dropzone.style.background = '#f0fdf4';
    }
    this.openModal('free-textbook-csv-modal');
  },

  handleFreeTextBookCSVSelected(e) {
    const file = e.target.files ? e.target.files[0] : (e.dataTransfer ? e.dataTransfer.files[0] : null);
    if (!file) return;

    if (!file.name.toLowerCase().endsWith('.csv') && file.type !== 'text/csv' && file.type !== 'application/vnd.ms-excel') {
      this.showToast('Please select a valid .csv spreadsheet file.', 'warning');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const csvText = event.target.result;
      const books = ReportEngine.parseFreeTextBooksCSV(csvText);

      if (!books || !books.length) {
        this.showToast('No valid Free Text Book records found in this CSV file. Please ensure column headers match.', 'warning');
        this.pendingCSVBooks = null;
        const prev = document.getElementById('ftb-csv-preview-container');
        if (prev) prev.style.display = 'none';
        const btn = document.getElementById('btn-confirm-ftb-csv-import');
        if (btn) btn.disabled = true;
        return;
      }

      this.pendingCSVBooks = books;

      // Populate preview UI
      const countElem = document.getElementById('ftb-csv-detected-count');
      if (countElem) {
        countElem.textContent = `✅ Detected ${books.length} book records ready for import`;
      }

      const tbody = document.getElementById('ftb-csv-preview-tbody');
      if (tbody) {
        tbody.innerHTML = books.slice(0, 8).map(b => {
          const totDist = (Number(b.distributedNew) || 0) + (Number(b.distributedOld) || 0);
          return `
            <tr>
              <td><span class="badge" style="background:#ecfdf5; color:#065f46;">${b.year}</span></td>
              <td><strong>${b.grade}</strong></td>
              <td>${b.bookTitle}</td>
              <td style="text-align:center;">${b.receivedNew}</td>
              <td style="text-align:center;">${b.distributedNew}</td>
              <td style="text-align:center;">${b.collectedOld}</td>
              <td style="text-align:center;">${b.distributedOld}</td>
              <td style="text-align:center;"><span class="badge" style="background:#eff6ff; color:#1d4ed8; font-weight:700;">${totDist}</span></td>
              <td style="text-align:center;"><strong style="color:#065f46;">${b.balance}</strong></td>
            </tr>
          `;
        }).join('');
      }

      const previewContainer = document.getElementById('ftb-csv-preview-container');
      if (previewContainer) previewContainer.style.display = 'block';

      const btnConfirm = document.getElementById('btn-confirm-ftb-csv-import');
      if (btnConfirm) btnConfirm.disabled = false;

      this.showToast(`Found ${books.length} textbook records in ${file.name}. Review and confirm to import.`);
    };

    reader.onerror = () => {
      this.showToast('Failed to read the selected CSV file.', 'error');
    };

    reader.readAsText(file);
  },

  executeFreeTextBookCSVImport() {
    if (!this.requireAdmin()) return;
    if (!this.pendingCSVBooks || !this.pendingCSVBooks.length) {
      this.showToast('No book records selected for import.', 'warning');
      return;
    }

    const res = SchoolDB.importFreeTextBooks(this.pendingCSVBooks);
    if (res.success) {
      this.closeModal('free-textbook-csv-modal');
      this.showToast(`Successfully imported ${res.count} book records into database! (کامیابی سے شامل کر لیے گئے)`);
      this.pendingCSVBooks = null;
      this.renderFreeTextBooks();
      this.updateDashboardCounters();
    } else {
      this.showToast(res.message || 'Failed to import books.', 'error');
    }
  },

  // ==================== ADMISSION & WITHDRAWAL REGISTER (MIDDLE & HIGH) MODULE ====================
  currentAdmWithdrawalType: 'middle',
  pendingCSVAdmWithdrawals: null,

  convertDateToWords(dateStr) {
    if (!dateStr) return '';
    const parts = dateStr.split('-');
    if (parts.length !== 3) return '';
    const y = parseInt(parts[0], 10);
    const m = parseInt(parts[1], 10) - 1;
    const d = parseInt(parts[2], 10);
    if (isNaN(y) || isNaN(m) || isNaN(d)) return '';

    const dayWords = [
      '', 'First', 'Second', 'Third', 'Fourth', 'Fifth', 'Sixth', 'Seventh', 'Eighth', 'Ninth', 'Tenth',
      'Eleventh', 'Twelfth', 'Thirteenth', 'Fourteenth', 'Fifteenth', 'Sixteenth', 'Seventeenth', 'Eighteenth', 'Nineteenth', 'Twentieth',
      'Twenty First', 'Twenty Second', 'Twenty Third', 'Twenty Fourth', 'Twenty Fifth', 'Twenty Sixth', 'Twenty Seventh', 'Twenty Eighth', 'Twenty Ninth', 'Thirtieth', 'Thirty First'
    ];

    const monthNames = [
      'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December'
    ];

    const numToWords = (num) => {
      const ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine',
        'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
      const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
      if (num < 20) return ones[num];
      if (num < 100) return tens[Math.floor(num / 10)] + (num % 10 ? ' ' + ones[num % 10] : '');
      if (num < 1000) return ones[Math.floor(num / 100)] + ' Hundred' + (num % 100 ? ' and ' + numToWords(num % 100) : '');
      if (num < 10000) return numToWords(Math.floor(num / 1000)) + ' Thousand' + (num % 1000 ? ' ' + numToWords(num % 1000) : '');
      return String(num);
    };

    const dayStr = dayWords[d] || String(d);
    const monthStr = monthNames[m] || '';
    const yearStr = numToWords(y);

    return `${dayStr} ${monthStr} ${yearStr}`.trim();
  },

  handleAdmWithdrawalDOBChange(e) {
    const val = e.target.value;
    const wordsInput = document.getElementById('aw-dob-words');
    if (wordsInput && val) {
      wordsInput.value = this.convertDateToWords(val);
    }
  },

  handleAdmWithdrawalStatusAutoChange() {
    const wDate = document.getElementById('aw-withdrawal-date')?.value;
    const statusSelect = document.getElementById('aw-status');
    if (wDate && statusSelect) {
      statusSelect.value = 'Struck Off';
    }
  },

  renderAdmWithdrawal(type = 'middle') {
    this.currentAdmWithdrawalType = type;
    const isHigh = type === 'high';
    const prefix = isHigh ? 'awh' : 'awm';

    const tbody = document.getElementById(`${prefix}-tbody`);
    if (!tbody) return;

    const query = (document.getElementById(`${prefix}-search`)?.value || '').toLowerCase().trim();
    const filterGrade = document.getElementById(`${prefix}-filter-grade`)?.value || '';
    const filterStatus = document.getElementById(`${prefix}-filter-status`)?.value || '';

    const allRecords = SchoolDB.getAdmWithdrawals(type);
    const filteredRecords = SchoolDB.getAdmWithdrawals(type, query, filterGrade, filterStatus);

    // Compute Metrics across allRecords
    let totalActive = 0;
    let totalStruck = 0;
    allRecords.forEach(r => {
      if ((r.status || '').toLowerCase() === 'active') totalActive++;
      else totalStruck++;
    });

    const countTotalEl = document.getElementById(`${prefix}-count-total`);
    if (countTotalEl) countTotalEl.textContent = allRecords.length;

    const countActiveEl = document.getElementById(`${prefix}-count-active`);
    if (countActiveEl) countActiveEl.textContent = totalActive;

    const countStruckEl = document.getElementById(`${prefix}-count-struck`);
    if (countStruckEl) countStruckEl.textContent = totalStruck;

    // Sidebar badge
    const badgeEl = document.getElementById(`sidebar-count-adm-withdrawal-${type}`);
    if (badgeEl) badgeEl.textContent = allRecords.length;

    if (!filteredRecords.length) {
      tbody.innerHTML = `
        <tr>
          <td colspan="13">
            <div class="empty-state">
              <div class="empty-state-icon">${isHigh ? '&#128216;' : '&#128214;'}</div>
              <h4>No Admission &amp; Withdrawal Records Found</h4>
              <p>Click "+ Add Entry" or "Upload CSV" to register pupils into official Dakhla Kharij register.</p>
            </div>
          </td>
        </tr>
      `;
      return;
    }

    tbody.innerHTML = filteredRecords.map(item => {
      const isStruck = (item.status || '').toLowerCase().includes('struck');
      const statusBadge = isStruck
        ? `<span class="badge" style="background:#fef3c7; color:#b45309; border:1px solid #fde68a; font-weight:700;">Struck Off</span>`
        : `<span class="badge status-active">Active</span>`;

      return `
        <tr>
          <td>
            <span class="badge" style="background:${isHigh ? '#eff6ff' : '#ecfdf5'}; color:${isHigh ? '#1d4ed8' : '#047857'}; font-weight:800; font-size:12px; padding:3px 8px; border:1px solid ${isHigh ? '#bfdbfe' : '#a7f3d0'};">
              ${item.admissionNo || '-'}
            </span>
          </td>
          <td style="white-space:nowrap; font-size:11.5px; color:#475569;">
            ${item.admissionDate || '-'}
          </td>
          <td>
            <strong style="color:var(--text-main); font-size:13px;">${item.studentName}</strong>
          </td>
          <td>
            <strong style="color:#1e293b; font-size:12.5px;">${item.fatherName || '-'}</strong>
          </td>
          <td>
            <span style="font-size:12px; color:#334155;">${item.caste || '-'}</span>
          </td>
          <td>
            <span style="font-size:12px; color:#334155;">${item.occupation || '-'}</span>
          </td>
          <td>
            <span style="font-size:11.5px; color:#475569;">${item.residence || '-'}</span>
          </td>
          <td>
            <div style="font-weight:600; white-space:nowrap;">${item.dob || '-'}</div>
            ${item.dobWords ? `<small class="text-muted" style="display:block; font-size:10px; max-width:140px; line-height:1.2;">${item.dobWords}</small>` : ''}
          </td>
          <td>
            <strong style="color:var(--primary); white-space:nowrap;">${item.classAdmitted || '-'}</strong>
          </td>
          <td>
            <div style="font-size:12px; white-space:nowrap;">${item.withdrawalDate ? item.withdrawalDate : '<span class="text-muted">-</span>'}</div>
            ${item.classWithdrawn ? `<small class="text-muted">(${item.classWithdrawn})</small>` : ''}
          </td>
          <td>
            <div style="font-size:11.5px; max-width:160px;">${item.withdrawalReason || '<span class="text-muted">-</span>'}</div>
            ${item.slcNo ? `<span class="badge" style="background:#f1f5f9; color:#475569; font-size:10px; margin-top:2px;">SLC: ${item.slcNo}</span>` : ''}
          </td>
          <td style="text-align:center;">
            ${statusBadge}
          </td>
          <td style="text-align:center; white-space:nowrap;">
            <button class="action-btn edit-btn" title="Edit Entry" onclick="App.editAdmWithdrawalModal('${type}', '${item.id}')">&#9998;</button>
            <button class="action-btn delete-btn" title="Delete Entry" onclick="App.deleteAdmWithdrawalConfirm('${type}', '${item.id}')">&#128465;</button>
          </td>
        </tr>
      `;
    }).join('');
  },

  openAddAdmWithdrawalModal(type = 'middle') {
    if (!this.requireAdmin()) return;
    this.currentAdmWithdrawalType = type;
    const isHigh = type === 'high';

    const form = document.getElementById('adm-withdrawal-form');
    if (form) form.reset();

    document.getElementById('aw-id').value = '';
    document.getElementById('aw-type').value = type;

    // Header styling
    const header = document.getElementById('adm-withdrawal-modal-header');
    const saveBtn = document.getElementById('aw-save-btn');
    if (header) {
      header.style.background = isHigh ? 'linear-gradient(135deg, #1e3a8a, #1d4ed8)' : 'linear-gradient(135deg, #065f46, #059669)';
    }
    if (saveBtn) {
      saveBtn.style.background = isHigh ? '#1d4ed8' : '#059669';
      saveBtn.style.borderColor = isHigh ? '#1d4ed8' : '#059669';
    }

    const titleEl = document.getElementById('adm-withdrawal-modal-title');
    if (titleEl) {
      titleEl.innerHTML = isHigh
        ? `New Admission &amp; Withdrawal Entry - High Section <span class="urdu-title" style="color:#bfdbfe;">(نیا اندراج داخلہ خارج ہائی)</span>`
        : `New Admission &amp; Withdrawal Entry - Middle Section <span class="urdu-title" style="color:#a7f3d0;">(نیا اندراج داخلہ خارج مڈل)</span>`;
    }

    // Populate Class Admitted Options (Optional)
    const classSelect = document.getElementById('aw-class-admitted');
    if (classSelect) {
      if (isHigh) {
        classSelect.innerHTML = `
          <option value="">Select Class / Optional (اختیاری)</option>
          <option value="Grade 9">Grade 9 (نہم - سائنس / آرٹس)</option>
          <option value="Grade 10">Grade 10 (دہم - سائنس / آرٹس)</option>
        `;
      } else {
        classSelect.innerHTML = `
          <option value="">Select Class / Optional (اختیاری)</option>
          <option value="Grade 6">Grade 6 (ششم)</option>
          <option value="Grade 7">Grade 7 (ہفتم)</option>
          <option value="Grade 8">Grade 8 (ہشتم)</option>
        `;
      }
    }

    document.getElementById('aw-admission-date').value = new Date().toISOString().split('T')[0];
    document.getElementById('aw-conduct').value = 'Good (نیک چلن)';
    document.getElementById('aw-status').value = 'Active';
    document.getElementById('aw-residence').value = '';

    this.openModal('adm-withdrawal-modal');
  },

  editAdmWithdrawalModal(type, id) {
    if (!this.requireAdmin()) return;
    this.currentAdmWithdrawalType = type;
    const isHigh = type === 'high';

    const item = SchoolDB.getAdmWithdrawalById(type, id);
    if (!item) return;

    document.getElementById('aw-id').value = item.id;
    document.getElementById('aw-type').value = type;

    // Header styling
    const header = document.getElementById('adm-withdrawal-modal-header');
    const saveBtn = document.getElementById('aw-save-btn');
    if (header) {
      header.style.background = isHigh ? 'linear-gradient(135deg, #1e3a8a, #1d4ed8)' : 'linear-gradient(135deg, #065f46, #059669)';
    }
    if (saveBtn) {
      saveBtn.style.background = isHigh ? '#1d4ed8' : '#059669';
      saveBtn.style.borderColor = isHigh ? '#1d4ed8' : '#059669';
    }

    const titleEl = document.getElementById('adm-withdrawal-modal-title');
    if (titleEl) {
      titleEl.innerHTML = `Edit Register Entry: ${item.studentName} (Adm No: ${item.admissionNo})`;
    }

    // Populate Class Admitted Options (Optional)
    const classSelect = document.getElementById('aw-class-admitted');
    if (classSelect) {
      if (isHigh) {
        classSelect.innerHTML = `
          <option value="">Select Class / Optional (اختیاری)</option>
          <option value="Grade 9">Grade 9 (نہم - سائنس / آرٹس)</option>
          <option value="Grade 10">Grade 10 (دہم - سائنس / آرٹس)</option>
        `;
      } else {
        classSelect.innerHTML = `
          <option value="">Select Class / Optional (اختیاری)</option>
          <option value="Grade 6">Grade 6 (ششم)</option>
          <option value="Grade 7">Grade 7 (ہفتم)</option>
          <option value="Grade 8">Grade 8 (ہشتم)</option>
        `;
      }
    }

    document.getElementById('aw-admission-no').value = item.admissionNo || '';
    document.getElementById('aw-admission-date').value = item.admissionDate || '';
    document.getElementById('aw-student-name').value = item.studentName || '';
    document.getElementById('aw-father-name').value = item.fatherName || '';
    document.getElementById('aw-caste').value = item.caste || '';
    document.getElementById('aw-occupation').value = item.occupation || '';
    document.getElementById('aw-residence').value = item.residence || '';
    document.getElementById('aw-dob').value = item.dob || '';
    document.getElementById('aw-dob-words').value = item.dobWords || (item.dob ? this.convertDateToWords(item.dob) : '');
    document.getElementById('aw-prev-school').value = item.prevSchool || '';
    if (classSelect && item.classAdmitted) classSelect.value = item.classAdmitted;
    document.getElementById('aw-withdrawal-date').value = item.withdrawalDate || '';
    document.getElementById('aw-class-withdrawn').value = item.classWithdrawn || '';
    document.getElementById('aw-withdrawal-reason').value = item.withdrawalReason || '';
    document.getElementById('aw-slc-no').value = item.slcNo || '';
    document.getElementById('aw-conduct').value = item.conduct || 'Good (نیک چلن)';
    document.getElementById('aw-status').value = item.status || 'Active';
    document.getElementById('aw-remarks').value = item.remarks || '';

    this.openModal('adm-withdrawal-modal');
  },

  saveAdmWithdrawalFromForm(e) {
    if (e && e.preventDefault) e.preventDefault();
    if (!this.requireAdmin()) return;

    const id = document.getElementById('aw-id').value;
    const type = document.getElementById('aw-type').value || this.currentAdmWithdrawalType || 'middle';
    const admissionNo = document.getElementById('aw-admission-no').value.trim();
    const admissionDate = document.getElementById('aw-admission-date').value;
    const studentName = document.getElementById('aw-student-name').value.trim();
    const fatherName = document.getElementById('aw-father-name').value.trim();
    const caste = document.getElementById('aw-caste').value.trim();
    const occupation = document.getElementById('aw-occupation').value.trim();
    const residence = document.getElementById('aw-residence').value.trim();
    const dob = document.getElementById('aw-dob').value;
    const dobWords = document.getElementById('aw-dob-words').value.trim() || (dob ? this.convertDateToWords(dob) : '');
    const prevSchool = document.getElementById('aw-prev-school').value.trim();
    const classAdmitted = document.getElementById('aw-class-admitted').value;
    const withdrawalDate = document.getElementById('aw-withdrawal-date').value;
    const classWithdrawn = document.getElementById('aw-class-withdrawn').value.trim();
    const withdrawalReason = document.getElementById('aw-withdrawal-reason').value.trim();
    const slcNo = document.getElementById('aw-slc-no').value.trim();
    const conduct = document.getElementById('aw-conduct').value || 'Good (نیک چلن)';
    const status = document.getElementById('aw-status').value || 'Active';
    const remarks = document.getElementById('aw-remarks').value.trim();

    // Mandatory fields: Admission No, Date of Admission, Pupil Name, Father Name, Date of Birth
    if (!admissionNo || !admissionDate || !studentName || !fatherName || !dob) {
      alert('Mandatory fields required: Please fill Admission No, Date of Admission, Pupil Name, Father Name, and Date of Birth. All other fields are optional and will be accepted if left empty.');
      return;
    }

    const payload = {
      id: id || undefined,
      admissionNo,
      admissionDate,
      studentName,
      fatherName,
      caste: caste || '',
      occupation: occupation || '',
      residence: residence || '',
      dob,
      dobWords: dobWords || '',
      prevSchool: prevSchool || '',
      classAdmitted: classAdmitted || '',
      withdrawalDate: withdrawalDate || '',
      classWithdrawn: classWithdrawn || '',
      withdrawalReason: withdrawalReason || '',
      slcNo: slcNo || '',
      conduct: conduct || 'Good (نیک چلن)',
      status: status || 'Active',
      remarks: remarks || ''
    };

    const saved = SchoolDB.saveAdmWithdrawal(type, payload);
    if (!saved) {
      alert('Error saving Admission & Withdrawal entry.');
      return;
    }

    this.closeModal('adm-withdrawal-modal');
    this.showToast(`Admission record for "${studentName}" (Adm No: ${admissionNo}) saved successfully!`);
    this.renderAdmWithdrawal(type);
    this.updateDashboardCounters();
  },

  deleteAdmWithdrawalConfirm(type, id) {
    if (!this.requireAdmin()) return;
    const item = SchoolDB.getAdmWithdrawalById(type, id);
    if (!item) return;

    const label = type === 'high' ? 'High Section' : 'Middle Section';
    if (confirm(`Are you sure you want to delete ${item.studentName} (Adm No: ${item.admissionNo}) from ${label} register?`)) {
      SchoolDB.deleteAdmWithdrawal(type, id);
      this.showToast('Admission entry deleted from register.', 'warning');
      this.renderAdmWithdrawal(type);
      this.updateDashboardCounters();
    }
  },

  openAdmWithdrawalCSVModal(type = 'middle') {
    if (!this.requireAdmin()) return;
    this.currentAdmWithdrawalType = type;
    this.pendingCSVAdmWithdrawals = null;
    const isHigh = type === 'high';

    const fileInput = document.getElementById('aw-csv-file-input');
    if (fileInput) fileInput.value = '';

    const prev = document.getElementById('aw-csv-preview-container');
    if (prev) prev.style.display = 'none';

    const btn = document.getElementById('btn-confirm-aw-csv-import');
    if (btn) {
      btn.disabled = true;
      btn.style.background = isHigh ? '#1d4ed8' : '#059669';
      btn.style.borderColor = isHigh ? '#1d4ed8' : '#059669';
    }

    const dropzone = document.getElementById('aw-csv-dropzone');
    if (dropzone) {
      dropzone.style.borderColor = isHigh ? '#1d4ed8' : '#059669';
      dropzone.style.background = isHigh ? '#eff6ff' : '#f0fdf4';
    }

    const header = document.getElementById('adm-withdrawal-csv-modal-header');
    if (header) {
      header.style.background = isHigh ? 'linear-gradient(135deg, #1e3a8a, #1d4ed8)' : 'linear-gradient(135deg, #065f46, #059669)';
    }

    const titleEl = document.getElementById('adm-withdrawal-csv-modal-title');
    if (titleEl) {
      titleEl.innerHTML = isHigh
        ? `Upload Admission &amp; Withdrawal CSV (High Section) <span class="urdu-title" style="color:#bfdbfe;">(داخلہ خارج CSV اپلوڈ ہائی)</span>`
        : `Upload Admission &amp; Withdrawal CSV (Middle Section) <span class="urdu-title" style="color:#a7f3d0;">(داخلہ خارج CSV اپلوڈ مڈل)</span>`;
    }

    this.openModal('adm-withdrawal-csv-modal');
  },

  handleAdmWithdrawalCSVSelected(e) {
    const file = e.target.files ? e.target.files[0] : (e.dataTransfer ? e.dataTransfer.files[0] : null);
    if (!file) return;

    if (!file.name.toLowerCase().endsWith('.csv') && file.type !== 'text/csv' && file.type !== 'application/vnd.ms-excel') {
      this.showToast('Please select a valid .csv spreadsheet file.', 'warning');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const csvText = event.target.result;
      const records = ReportEngine.parseAdmWithdrawalCSV(csvText);

      if (!records || !records.length) {
        this.showToast('No valid pupil records found in this CSV file. Please ensure column headers match.', 'warning');
        this.pendingCSVAdmWithdrawals = null;
        const prev = document.getElementById('aw-csv-preview-container');
        if (prev) prev.style.display = 'none';
        const btn = document.getElementById('btn-confirm-aw-csv-import');
        if (btn) btn.disabled = true;
        return;
      }

      this.pendingCSVAdmWithdrawals = records;

      // Populate preview UI
      const countElem = document.getElementById('aw-csv-detected-count');
      if (countElem) {
        countElem.textContent = `✅ Detected ${records.length} pupil records ready for import`;
      }

      const tbody = document.getElementById('aw-csv-preview-tbody');
      if (tbody) {
        tbody.innerHTML = records.slice(0, 6).map(r => `
          <tr>
            <td><strong style="color:var(--primary);">${r.admissionNo || '-'}</strong></td>
            <td>${r.admissionDate || '-'}</td>
            <td><strong>${r.studentName}</strong></td>
            <td>${r.fatherName || '-'}</td>
            <td><span class="badge" style="background:#eff6ff; color:#1d4ed8;">${r.classAdmitted || '-'}</span></td>
            <td>${r.dob || '-'}</td>
            <td><span class="badge ${r.status === 'Active' ? 'status-active' : ''}">${r.status || 'Active'}</span></td>
          </tr>
        `).join('');
      }

      const previewContainer = document.getElementById('aw-csv-preview-container');
      if (previewContainer) previewContainer.style.display = 'block';

      const btnConfirm = document.getElementById('btn-confirm-aw-csv-import');
      if (btnConfirm) btnConfirm.disabled = false;

      this.showToast(`Found ${records.length} records in ${file.name}. Review and confirm to import.`);
    };

    reader.onerror = () => {
      this.showToast('Failed to read the selected CSV file.', 'error');
    };

    reader.readAsText(file);
  },

  executeAdmWithdrawalCSVImport() {
    if (!this.requireAdmin()) return;
    if (!this.pendingCSVAdmWithdrawals || !this.pendingCSVAdmWithdrawals.length) {
      this.showToast('No records selected for import.', 'warning');
      return;
    }

    const type = this.currentAdmWithdrawalType || 'middle';
    const res = SchoolDB.importAdmWithdrawals(type, this.pendingCSVAdmWithdrawals);
    if (res.success) {
      this.closeModal('adm-withdrawal-csv-modal');
      this.showToast(`Successfully imported ${res.count} records into ${type === 'high' ? 'High' : 'Middle'} register! (کامیابی سے شامل کر لیے گئے)`);
      this.pendingCSVAdmWithdrawals = null;
      this.renderAdmWithdrawal(type);
      this.updateDashboardCounters();
    } else {
      this.showToast(res.message || 'Failed to import records.', 'error');
    }
  },

  // ==================== DOWNLOADS & DOCUMENT REPOSITORY MODULE ====================
  tempDocFilePayload: null,
  tempDocFileMeta: null,

  renderDownloads() {
    const tbody = document.getElementById('downloads-tbody');
    if (!tbody) return;

    const query = (document.getElementById('doc-search')?.value || '').toLowerCase().trim();
    const filterCategory = document.getElementById('doc-filter-category')?.value || '';

    const allDocs = SchoolDB.getDocuments();
    const filteredDocs = SchoolDB.getDocuments(filterCategory, query);

    // Update Metrics
    let totalDownloads = 0;
    const catSet = new Set();
    allDocs.forEach(d => {
      totalDownloads += Number(d.downloadsCount) || 0;
      if (d.category) catSet.add(d.category);
    });

    const countTotalEl = document.getElementById('doc-count-total');
    if (countTotalEl) countTotalEl.textContent = allDocs.length;

    const countDownloadsEl = document.getElementById('doc-count-downloads');
    if (countDownloadsEl) countDownloadsEl.textContent = totalDownloads.toLocaleString();

    const countCategoriesEl = document.getElementById('doc-count-categories');
    if (countCategoriesEl) countCategoriesEl.textContent = catSet.size;

    const badgeEl = document.getElementById('sidebar-count-downloads');
    if (badgeEl) badgeEl.textContent = allDocs.length;

    if (!filteredDocs.length) {
      tbody.innerHTML = `
        <tr>
          <td colspan="9">
            <div class="empty-state">
              <div class="empty-state-icon">&#128193;</div>
              <h4>No Documents Found</h4>
              <p>Click "Upload New Document" to store application forms, admission papers, schedules, or notifications.</p>
            </div>
          </td>
        </tr>
      `;
      return;
    }

    const formatBadgeMap = {
      pdf: { bg: '#fee2e2', color: '#b91c1c', icon: '&#128196; PDF' },
      docx: { bg: '#e0e7ff', color: '#3730a3', icon: '&#128196; DOCX' },
      doc: { bg: '#e0e7ff', color: '#3730a3', icon: '&#128196; DOC' },
      xlsx: { bg: '#dcfce7', color: '#15803d', icon: '&#128202; XLSX' },
      xls: { bg: '#dcfce7', color: '#15803d', icon: '&#128202; XLS' },
      csv: { bg: '#ecfdf5', color: '#047857', icon: '&#128196; CSV' },
      jpg: { bg: '#fef3c7', color: '#b45309', icon: '&#128444; JPG' },
      jpeg: { bg: '#fef3c7', color: '#b45309', icon: '&#128444; JPEG' },
      png: { bg: '#fef3c7', color: '#b45309', icon: '&#128444; PNG' },
      zip: { bg: '#ede9fe', color: '#6d28d9', icon: '&#128451; ZIP' },
      rar: { bg: '#ede9fe', color: '#6d28d9', icon: '&#128451; RAR' },
      mp3: { bg: '#fce7f3', color: '#be185d', icon: '&#127908; AUDIO' },
      wav: { bg: '#fce7f3', color: '#be185d', icon: '&#127908; AUDIO' }
    };

    tbody.innerHTML = filteredDocs.map((doc, idx) => {
      const ext = (doc.ext || 'bin').toLowerCase();
      const fmt = formatBadgeMap[ext] || { bg: '#f1f5f9', color: '#475569', icon: `&#128196; ${ext.toUpperCase()}` };

      return `
        <tr>
          <td style="text-align: center;">
            <span class="badge" style="background: ${fmt.bg}; color: ${fmt.color}; font-weight: 700; font-size: 10.5px;">
              ${fmt.icon}
            </span>
          </td>
          <td>
            <div style="font-weight: 700; color: var(--text-main); font-size: 13.5px;">${doc.title}</div>
            ${doc.description ? `<small class="text-muted" style="line-height: 1.4; display:block; margin-top:2px;">${doc.description}</small>` : ''}
          </td>
          <td>
            <code style="background: #f8fafc; border: 1px solid #e2e8f0; padding: 2px 6px; border-radius: 4px; font-size: 11px; color: #0f172a;">
              ${doc.filename || 'document.' + ext}
            </code>
          </td>
          <td><span class="badge" style="background:#f1f5f9; color:#475569; font-weight: 600;">${doc.category || 'General'}</span></td>
          <td><strong style="color: #0369a1;">${doc.formattedSize || 'Unknown Size'}</strong></td>
          <td>${doc.uploadDate || '-'}</td>
          <td><small style="color: #475569;">${doc.uploadedBy || 'Admin'}</small></td>
          <td style="text-align: center;">
            <span class="badge" style="background:#e0f2fe; color:#0369a1; font-weight:700;">
              &#11015; ${doc.downloadsCount || 0}
            </span>
          </td>
          <td style="text-align: center;">
            <div style="display: inline-flex; align-items: center; gap: 6px;">
              <button class="btn btn-primary btn-sm" onclick="App.downloadDocFile('${doc.id}')" title="Download Document Now (ڈاؤنلوڈ کریں)" style="background: #0284c7; border-color: #0284c7; padding: 5px 12px; font-weight: 700;">
                &#11015; Download
              </button>
              <button class="action-icon-btn" onclick="App.editDocumentModal('${doc.id}')" title="Edit Document Details">&#9998;</button>
              <button class="action-icon-btn delete" onclick="App.deleteDocumentConfirm('${doc.id}')" title="Delete Document">&#128465;</button>
            </div>
          </td>
        </tr>
      `;
    }).join('');
  },

  openUploadDocModal() {
    if (!this.requireAdmin()) return;
    const form = document.getElementById('doc-upload-form');
    if (form) form.reset();
    document.getElementById('doc-item-id').value = '';
    document.getElementById('doc-item-date').value = new Date().toISOString().split('T')[0];
    document.getElementById('doc-item-uploader').value = SchoolDB.getAdminProfile().fullName || 'Principal Office';

    this.tempDocFilePayload = null;
    this.tempDocFileMeta = null;

    const pill = document.getElementById('doc-selected-file-pill');
    if (pill) pill.style.display = 'none';

    const titleEl = document.getElementById('doc-modal-title');
    if (titleEl) {
      titleEl.innerHTML = `Upload &amp; Store Document <span class="urdu-title">(دستاویز اپلوڈ کریں)</span>`;
    }

    this.openModal('doc-upload-modal');
  },

  handleDocumentFileSelected(event) {
    const file = event.target.files && event.target.files[0];
    if (!file) return;

    const name = file.name;
    const size = file.size;
    const ext = name.includes('.') ? name.split('.').pop().toLowerCase() : '';

    let formattedSize = '';
    if (size < 1024) formattedSize = size + ' B';
    else if (size < 1048576) formattedSize = (size / 1024).toFixed(1) + ' KB';
    else formattedSize = (size / 1048576).toFixed(2) + ' MB';

    this.tempDocFileMeta = {
      filename: name,
      fileSize: size,
      formattedSize: formattedSize,
      fileType: file.type || 'application/octet-stream',
      ext: ext
    };

    // Pre-populate fields if empty
    const filenameInput = document.getElementById('doc-item-filename');
    if (filenameInput) filenameInput.value = name;

    const titleInput = document.getElementById('doc-item-title');
    if (titleInput && !titleInput.value.trim()) {
      const cleanTitle = name.replace(/\.[^/.]+$/, "").replace(/[-_]/g, " ");
      titleInput.value = cleanTitle.charAt(0).toUpperCase() + cleanTitle.slice(1);
    }

    // Auto-detect category based on filename
    const catInput = document.getElementById('doc-item-category');
    if (catInput) {
      const lower = name.toLowerCase();
      if (lower.includes('admiss') || lower.includes('form') || lower.includes('entry')) catInput.value = 'Admission Forms';
      else if (lower.includes('calen') || lower.includes('sched') || lower.includes('holid')) catInput.value = 'Academic Schedule';
      else if (lower.includes('syllab') || lower.includes('book') || lower.includes('curric')) catInput.value = 'Curriculum & Books';
      else if (lower.includes('ptc') || lower.includes('resolut') || lower.includes('grant')) catInput.value = 'PTC & Financial';
      else if (lower.includes('fee') || lower.includes('challan') || lower.includes('bill')) catInput.value = 'Fee & Billing';
      else if (lower.includes('exam') || lower.includes('paper') || lower.includes('date')) catInput.value = 'Examination';
      else if (lower.includes('notif') || lower.includes('order') || lower.includes('govt')) catInput.value = 'Government Notification';
    }

    // Show pill
    const pill = document.getElementById('doc-selected-file-pill');
    const fnSpan = document.getElementById('doc-selected-filename');
    const szBadge = document.getElementById('doc-selected-filesize');
    if (pill && fnSpan && szBadge) {
      fnSpan.textContent = name;
      szBadge.textContent = formattedSize;
      pill.style.display = 'inline-flex';
    }

    // Read payload as DataURL
    const reader = new FileReader();
    reader.onload = (e) => {
      this.tempDocFilePayload = e.target.result;
      this.showToast(`File "${name}" (${formattedSize}) loaded successfully!`);
    };
    reader.onerror = () => {
      this.showToast('Error reading selected file.', 'error');
    };
    reader.readAsDataURL(file);
  },

  async editDocumentModal(docId) {
    if (!this.requireAdmin()) return;
    const doc = SchoolDB.getDocumentById(docId);
    if (!doc) return;

    this.tempDocFilePayload = null;
    this.tempDocFileMeta = null;

    document.getElementById('doc-item-id').value = doc.id;
    document.getElementById('doc-item-title').value = doc.title || '';
    document.getElementById('doc-item-category').value = doc.category || 'General';
    document.getElementById('doc-item-date').value = doc.uploadDate || new Date().toISOString().split('T')[0];
    document.getElementById('doc-item-uploader').value = doc.uploadedBy || '';
    document.getElementById('doc-item-filename').value = doc.filename || '';
    document.getElementById('doc-item-desc').value = doc.description || '';

    const pill = document.getElementById('doc-selected-file-pill');
    const fnSpan = document.getElementById('doc-selected-filename');
    const szBadge = document.getElementById('doc-selected-filesize');
    if (pill && fnSpan && szBadge) {
      fnSpan.textContent = doc.filename || 'existing_document';
      szBadge.textContent = doc.formattedSize || 'Stored';
      pill.style.display = 'inline-flex';
    }

    const titleEl = document.getElementById('doc-modal-title');
    if (titleEl) {
      titleEl.innerHTML = `Edit Document Details: ${doc.title}`;
    }

    this.openModal('doc-upload-modal');
  },

  async saveDocumentFromForm(e) {
    if (e && e.preventDefault) e.preventDefault();
    if (!this.requireAdmin()) return;

    const id = document.getElementById('doc-item-id').value;
    const title = document.getElementById('doc-item-title').value.trim();
    const category = document.getElementById('doc-item-category').value;
    const uploadDate = document.getElementById('doc-item-date').value || new Date().toISOString().split('T')[0];
    const uploadedBy = document.getElementById('doc-item-uploader').value.trim() || 'Principal Office';
    let filename = document.getElementById('doc-item-filename').value.trim();
    const description = document.getElementById('doc-item-desc').value.trim();

    let existingDoc = id ? SchoolDB.getDocumentById(id) : null;

    let meta = this.tempDocFileMeta || {};
    if (!filename) {
      filename = meta.filename || (existingDoc ? existingDoc.filename : `${title.replace(/\s+/g, '_')}.pdf`);
    }

    const ext = meta.ext || (filename.includes('.') ? filename.split('.').pop().toLowerCase() : (existingDoc ? existingDoc.ext : 'pdf'));

    const docObj = {
      title: title,
      category: category,
      filename: filename,
      uploadDate: uploadDate,
      uploadedBy: uploadedBy,
      description: description,
      ext: ext,
      fileType: meta.fileType || (existingDoc ? existingDoc.fileType : 'application/octet-stream'),
      fileSize: meta.fileSize || (existingDoc ? existingDoc.fileSize : 50000),
      formattedSize: meta.formattedSize || (existingDoc ? existingDoc.formattedSize : '50 KB')
    };

    if (id) docObj.id = id;

    // Check if new payload or keep existing
    const payload = this.tempDocFilePayload;

    await SchoolDB.saveDocument(docObj, payload);
    this.closeModal('doc-upload-modal');
    this.showToast(`Document "${title}" saved and available for download!`);
    this.renderDownloads();
    this.updateDashboardCounters();
  },

  async deleteDocumentConfirm(id) {
    if (!this.requireAdmin()) return;
    const doc = SchoolDB.getDocumentById(id);
    if (!doc) return;

    if (confirm(`Are you sure you want to delete document "${doc.title}" from downloads repository?`)) {
      await SchoolDB.deleteDocument(id);
      this.showToast('Document record deleted.', 'warning');
      this.renderDownloads();
      this.updateDashboardCounters();
    }
  },

  async downloadDocFile(id) {
    await SchoolDB.triggerDocumentDownload(id);
    this.renderDownloads();
    this.showToast('Download started! Check your browser downloads.');
  },

  exportDocsManifestCSV() {
    const docs = SchoolDB.getDocuments();
    const columns = [
      { label: 'Document ID', key: 'id' },
      { label: 'Title', key: 'title' },
      { label: 'Filename', key: 'filename' },
      { label: 'Category', key: 'category' },
      { label: 'Format / Extension', key: 'ext' },
      { label: 'File Size', key: 'formattedSize' },
      { label: 'Upload Date', key: 'uploadDate' },
      { label: 'Issued / Uploaded By', key: 'uploadedBy' },
      { label: 'Downloads Served', key: 'downloadsCount' },
      { label: 'Description', key: 'description' }
    ];
    const csv = ReportEngine.toCSV(docs, columns);
    ReportEngine.downloadCSV(csv, `Documents_Downloads_Catalog_${new Date().toISOString().split('T')[0]}.csv`);
  },

  // ==================== SETTINGS & DATA ====================
  renderSettings() {
    const s = SchoolDB.data.settings;
    if (!s) return;
    document.getElementById('settings-school-name').value = s.schoolName || '';
    document.getElementById('settings-emis-code').value = s.emisCode || '18456';
    document.getElementById('settings-tagline').value = s.tagline || '';
    document.getElementById('settings-address').value = s.address || '';
    document.getElementById('settings-phone').value = s.phone || '';
    document.getElementById('settings-email').value = s.email || '';
    document.getElementById('settings-academic-year').value = s.academicYear || '';
    document.getElementById('settings-currency').value = s.currency || 'Rs. ';
  },

  saveSettingsForm(e) {
    e.preventDefault();
    if (!this.requireAdmin()) return;
    SchoolDB.data.settings = {
      ...SchoolDB.data.settings,
      schoolName: document.getElementById('settings-school-name').value.trim(),
      emisCode: document.getElementById('settings-emis-code').value.trim() || '18456',
      tagline: document.getElementById('settings-tagline').value.trim(),
      address: document.getElementById('settings-address').value.trim(),
      phone: document.getElementById('settings-phone').value.trim(),
      email: document.getElementById('settings-email').value.trim(),
      academicYear: document.getElementById('settings-academic-year').value.trim(),
      currency: document.getElementById('settings-currency').value.trim()
    };
    SchoolDB.save();
    document.getElementById('brand-school-name').textContent = SchoolDB.data.settings.schoolName;
    document.getElementById('academic-year-tag').textContent = SchoolDB.data.settings.academicYear;
    this.showToast('School profile and EMIS code saved.');
  },

  resetDatabasePrompt() {
    if (!this.requireAdmin()) return;
    if (confirm('Are you sure you want to reset all data to default demo sample data? Custom additions will be overwritten.')) {
      SchoolDB.reset();
      this.showToast('Database reset to demo scenarios.', 'warning');
      location.reload();
    }
  },

  // ==================== DROPDOWN POPULATORS ====================
  populateClassDropdowns() {
    const classes = SchoolDB.getClasses();
    
    // Extract unique grade names and sort them numerically (e.g. Grade 6, 7, 8, 9, 10, 11, 12)
    const uniqueGrades = [];
    classes.forEach(c => {
      if (c.name && !uniqueGrades.includes(c.name)) {
        uniqueGrades.push(c.name);
      }
    });
    uniqueGrades.sort((a, b) => {
      const numA = parseInt(a.replace(/\D/g, ''), 10) || 0;
      const numB = parseInt(b.replace(/\D/g, ''), 10) || 0;
      return numA - numB;
    });

    // 1. Student Grade Dropdown (#student-grade) -> Clean list of grades without section suffixes
    const studentGradeEl = document.getElementById('student-grade');
    if (studentGradeEl) {
      const curVal = studentGradeEl.value;
      studentGradeEl.innerHTML = uniqueGrades.map(g => `<option value="${g}">${g}</option>`).join('');
      if (curVal && uniqueGrades.includes(curVal)) {
        studentGradeEl.value = curVal;
      } else if (uniqueGrades.length > 0) {
        studentGradeEl.selectedIndex = 0;
      }
    }

    // 2. Class Filters & Class Room Selectors
    const otherDropdowns = ['students-filter-class', 'attendance-class-select', 'exams-filter-class', 'wa-class-select'];
    otherDropdowns.forEach(id => {
      const el = document.getElementById(id);
      if (!el) return;
      const currentVal = el.value;
      const isFilter = id.includes('filter');

      let options = isFilter ? '<option value="">All Classes (تمام کلاسیں)</option>' : '';
      if (id === 'students-filter-class') {
        // Allow filtering by grade level cleanly
        uniqueGrades.forEach(g => {
          options += `<option value="${g}">${g}</option>`;
        });
      } else {
        classes.forEach(c => {
          options += `<option value="${c.id}">${c.name} (${c.section})</option>`;
        });
      }

      el.innerHTML = options;
      if (currentVal) {
        el.value = currentVal;
      } else if (!isFilter && el.options.length > 0) {
        el.selectedIndex = 0;
      }
    });
  },

  populateTeacherDropdown(selectId) {
    const el = document.getElementById(selectId);
    if (!el) return;
    const teachers = SchoolDB.getTeachers();
    el.innerHTML = '<option value="">-- Select Teacher --</option>' + teachers.map(t => `
      <option value="${t.id}">${t.name} (${t.qualification || 'Faculty'})</option>
    `).join('');
  },

  populateStudentDropdown(selectId) {
    const el = document.getElementById(selectId);
    if (!el) return;
    const students = SchoolDB.getStudents();
    el.innerHTML = '<option value="">-- Select Student --</option>' + students.map(s => `
      <option value="${s.id}">${s.name} (${s.rollNo} - ${s.grade})</option>
    `).join('');
  },

  // ==================== MODAL HELPERS ====================
  bindModals() {
    // Backdrop click close
    document.querySelectorAll('.modal-overlay').forEach(overlay => {
      overlay.addEventListener('click', (e) => {
        if (e.target === overlay) {
          overlay.classList.remove('active');
          if (overlay.id === 'admin-login-modal' && !App.isAdminLoggedIn) {
            App.showToast('Continuing in Read-Only Mode. Changes require Admin log on.', 'warning');
          }
        }
      });
    });

    // Close button close
    document.querySelectorAll('.modal-close-btn, [data-modal-close]').forEach(btn => {
      btn.addEventListener('click', () => {
        const overlay = btn.closest('.modal-overlay');
        if (overlay) overlay.classList.remove('active');
      });
    });
  },

  openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) modal.classList.add('active');
  },

  closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) modal.classList.remove('active');
  },

  // Global events & Search input bindings
  bindGlobalEvents() {
    // Form submit handlers
    document.getElementById('student-form')?.addEventListener('submit', (e) => this.saveStudentFromForm(e));
    document.getElementById('student-photo-input')?.addEventListener('change', (e) => this.handleStudentPhotoUpload(e));
    document.getElementById('teacher-form')?.addEventListener('submit', (e) => this.saveTeacherFromForm(e));
    document.getElementById('teacher-photo-input')?.addEventListener('change', (e) => this.handleTeacherPhotoUpload(e));
    document.getElementById('class-form')?.addEventListener('submit', (e) => this.saveClassFromForm(e));
    document.getElementById('subject-form')?.addEventListener('submit', (e) => this.saveSubjectFromForm(e));
    document.getElementById('subject-max-marks-form')?.addEventListener('submit', (e) => this.saveSubjectMaxMarksFromForm(e));
    document.getElementById('marks-form')?.addEventListener('submit', (e) => this.saveMarksFromForm(e));
    document.getElementById('marks-student-select')?.addEventListener('change', (e) => {
      this.buildSubjectMarksInputFields({}, e.target.value);
    });
    document.getElementById('fee-form')?.addEventListener('submit', (e) => this.saveFeeFromForm(e));
    document.getElementById('notice-form')?.addEventListener('submit', (e) => this.saveNoticeFromForm(e));
    document.getElementById('settings-form')?.addEventListener('submit', (e) => this.saveSettingsForm(e));
    document.getElementById('admin-login-form')?.addEventListener('submit', (e) => this.handleAdminLogin(e));
    document.getElementById('admin-credentials-form')?.addEventListener('submit', (e) => this.handleAdminCredentialsUpdate(e));

    // Database JSON file upload listener
    const fileInput = document.getElementById('db-import-file');
    if (fileInput) {
      fileInput.addEventListener('change', (e) => {
        if (!this.requireAdmin()) {
          fileInput.value = '';
          return;
        }
        const file = e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (event) => {
          const res = SchoolDB.importJSON(event.target.result);
          if (res.success) {
            App.showToast('Database backup successfully restored!');
            setTimeout(() => location.reload(), 600);
          } else {
            alert(res.message);
          }
        };
        reader.readAsText(file);
      });
    }

    // Drag & drop on CSV student dropzone
    const csvDropzone = document.getElementById('csv-student-dropzone');
    if (csvDropzone) {
      csvDropzone.addEventListener('dragover', (e) => {
        e.preventDefault();
        csvDropzone.style.borderColor = '#2563eb';
        csvDropzone.style.background = '#dbeafe';
      });
      csvDropzone.addEventListener('dragleave', (e) => {
        e.preventDefault();
        csvDropzone.style.borderColor = '#93c5fd';
        csvDropzone.style.background = '#eff6ff';
      });
      csvDropzone.addEventListener('drop', (e) => {
        e.preventDefault();
        csvDropzone.style.borderColor = '#93c5fd';
        csvDropzone.style.background = '#eff6ff';
        if (e.dataTransfer && e.dataTransfer.files.length) {
          this.handleStudentCSVSelected({ target: { files: e.dataTransfer.files } });
        }
      });
    }
  },

  bindSearchAndFilters() {
    // Students search & filter
    document.getElementById('students-search')?.addEventListener('input', () => this.renderStudents());
    document.getElementById('students-filter-class')?.addEventListener('change', () => this.renderStudents());
    document.getElementById('students-filter-section')?.addEventListener('change', () => this.renderStudents());
    document.getElementById('students-filter-status')?.addEventListener('change', () => this.renderStudents());

    // Teachers search & filter
    document.getElementById('teachers-search')?.addEventListener('input', () => this.renderTeachers());
    document.getElementById('teachers-filter-status')?.addEventListener('change', () => this.renderTeachers());

    // Attendance class/date switcher
    document.getElementById('attendance-class-select')?.addEventListener('change', () => this.loadAttendanceSheet());
    document.getElementById('attendance-date-input')?.addEventListener('change', () => this.loadAttendanceSheet());

    // Exams filters
    document.getElementById('exams-filter-class')?.addEventListener('change', () => this.renderExams());
    document.getElementById('exams-filter-term')?.addEventListener('change', () => this.renderExams());

    // Fees filter
    document.getElementById('fees-filter-status')?.addEventListener('change', () => this.renderFees());
    document.getElementById('fees-search')?.addEventListener('input', () => this.renderFees());

    // Stock General filters
    document.getElementById('stock-gen-search')?.addEventListener('input', () => this.renderStock('general'));
    document.getElementById('stock-gen-filter-category')?.addEventListener('change', () => this.renderStock('general'));
    document.getElementById('stock-gen-filter-condition')?.addEventListener('change', () => this.renderStock('general'));

    // Stock PTC filters
    document.getElementById('stock-ptc-search')?.addEventListener('input', () => this.renderStock('ptc'));
    document.getElementById('stock-ptc-filter-year')?.addEventListener('change', () => this.renderStock('ptc'));
    document.getElementById('stock-ptc-filter-category')?.addEventListener('change', () => this.renderStock('ptc'));
    document.getElementById('stock-ptc-filter-condition')?.addEventListener('change', () => this.renderStock('ptc'));

    // Free Text Books filters
    document.getElementById('ftb-search')?.addEventListener('input', () => this.renderFreeTextBooks());
    document.getElementById('ftb-filter-year')?.addEventListener('change', () => this.renderFreeTextBooks());
    document.getElementById('ftb-filter-grade')?.addEventListener('change', () => this.renderFreeTextBooks());

    // Admission & Withdrawal Middle filters
    document.getElementById('awm-search')?.addEventListener('input', () => this.renderAdmWithdrawal('middle'));
    document.getElementById('awm-filter-grade')?.addEventListener('change', () => this.renderAdmWithdrawal('middle'));
    document.getElementById('awm-filter-status')?.addEventListener('change', () => this.renderAdmWithdrawal('middle'));

    // Admission & Withdrawal High filters
    document.getElementById('awh-search')?.addEventListener('input', () => this.renderAdmWithdrawal('high'));
    document.getElementById('awh-filter-grade')?.addEventListener('change', () => this.renderAdmWithdrawal('high'));
    document.getElementById('awh-filter-status')?.addEventListener('change', () => this.renderAdmWithdrawal('high'));

    // Notice audience filter
    document.getElementById('notices-filter-audience')?.addEventListener('change', () => this.renderNotices());

    // Downloads filters & drag-drop
    document.getElementById('doc-search')?.addEventListener('input', () => this.renderDownloads());
    document.getElementById('doc-filter-category')?.addEventListener('change', () => this.renderDownloads());

    const quickDrop = document.getElementById('doc-quick-dropzone');
    if (quickDrop) {
      quickDrop.addEventListener('dragover', (e) => {
        e.preventDefault();
        quickDrop.style.borderColor = '#0284c7';
        quickDrop.style.background = '#e0f2fe';
      });
      quickDrop.addEventListener('dragleave', (e) => {
        e.preventDefault();
        quickDrop.style.borderColor = '#93c5fd';
        quickDrop.style.background = '#f0f9ff';
      });
      quickDrop.addEventListener('drop', (e) => {
        e.preventDefault();
        quickDrop.style.borderColor = '#93c5fd';
        quickDrop.style.background = '#f0f9ff';
        if (e.dataTransfer && e.dataTransfer.files.length) {
          this.openUploadDocModal();
          this.handleDocumentFileSelected({ target: { files: e.dataTransfer.files } });
        }
      });
    }

    const ftbDrop = document.getElementById('ftb-csv-dropzone');
    if (ftbDrop) {
      ftbDrop.addEventListener('dragover', (e) => {
        e.preventDefault();
        ftbDrop.style.borderColor = '#047857';
        ftbDrop.style.background = '#dcfce7';
      });
      ftbDrop.addEventListener('dragleave', (e) => {
        e.preventDefault();
        ftbDrop.style.borderColor = '#059669';
        ftbDrop.style.background = '#f0fdf4';
      });
      ftbDrop.addEventListener('drop', (e) => {
        e.preventDefault();
        ftbDrop.style.borderColor = '#059669';
        ftbDrop.style.background = '#f0fdf4';
        this.handleFreeTextBookCSVSelected(e);
      });
    }

    const awDrop = document.getElementById('aw-csv-dropzone');
    if (awDrop) {
      awDrop.addEventListener('dragover', (e) => {
        e.preventDefault();
        awDrop.style.borderColor = '#047857';
        awDrop.style.background = '#dcfce7';
      });
      awDrop.addEventListener('dragleave', (e) => {
        e.preventDefault();
        awDrop.style.borderColor = '#059669';
        awDrop.style.background = '#f0fdf4';
      });
      awDrop.addEventListener('drop', (e) => {
        e.preventDefault();
        awDrop.style.borderColor = '#059669';
        awDrop.style.background = '#f0fdf4';
        this.handleAdmWithdrawalCSVSelected(e);
      });
    }

    // WhatsApp Center live input bindings
    document.getElementById('wa-recipient-search')?.addEventListener('input', () => this.renderWhatsAppRecipients());
    document.getElementById('wa-message-textarea')?.addEventListener('input', () => this.updateWhatsAppMessagePreview());
  },

  // ==================== WHATSAPP CENTER & BROADCASTING ====================
  waTargetType: 'class',
  waTemplate: 'custom',
  waCurrentQueueIndex: 0,
  mediaRecorder: null,
  audioChunks: [],
  recordedAudioBlob: null,
  recordedAudioUrl: null,
  recordingTimerInterval: null,
  recordingSeconds: 0,
  isRecording: false,

  renderWhatsAppView() {
    this.populateClassDropdowns();
    const classSelect = document.getElementById('wa-class-select');
    if (classSelect && !classSelect.value && classSelect.options.length > 0) {
      classSelect.selectedIndex = 0;
    }

    const textarea = document.getElementById('wa-message-textarea');
    if (textarea && !textarea.value.trim()) {
      this.applyWhatsAppTemplate('custom');
    } else {
      this.updateWhatsAppMessagePreview();
    }

    this.renderWhatsAppRecipients();
  },

  handleWhatsAppTargetChange() {
    const targetType = document.getElementById('wa-target-type')?.value || 'class';
    this.waTargetType = targetType;
    this.waCurrentQueueIndex = 0;

    const classWrap = document.getElementById('wa-class-filter-wrap');
    if (classWrap) classWrap.style.display = (targetType === 'class') ? 'flex' : 'none';

    this.renderWhatsAppRecipients();
  },

  getWhatsAppTemplates() {
    const schoolName = SchoolDB.data.settings?.schoolName || 'GOVT: HIGH SCHOOL ZANDO DHERI, MARDAN PAKISTAN';
    const today = new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
    return {
      custom: `السلام علیکم!\n${schoolName} کی جانب سے ضروری اطلاع۔\n\nAssalam-o-Alaikum! Official announcement from ${schoolName} for {name}.`,
      
      absent: `السلام علیکم محترم سرپرست،\nمطلع کیا جاتا ہے کہ آپ کا فرزند/دختر {name} (رول نمبر {roll_no}، جماعت {class}) آج بتاریخ {date} اسکول سے غیر حاضر ہے۔ براہ کرم غیر حاضری کی وجہ تحریر فرمائیں یا اسکول دفتر رابطہ کریں۔\n\nRespected Guardian, this is to inform you that {name} (Roll No: {roll_no}, Class: {class}) is ABSENT today ({date}) from ${schoolName}. Kindly intimate the reason of absence.`,
      
      fee: `السلام علیکم محترم سرپرست،\nطالب علم {name} (رول نمبر {roll_no}، جماعت {class}) کا ماہانہ اسکول فیس چالان جاری ہو چکا ہے۔ برائے مہربانی مقررہ تاریخ سے قبل بقایا جات اسکول اکاؤنٹ یا کاؤنٹر پر جمع کروا کر رسید حاصل فرمائیں۔ شکریہ۔\n\nDear Parent/Guardian, fee voucher for {name} (Roll No: {roll_no}, Class: {class}) has been issued. Please clear outstanding dues by the due date. - ${schoolName}`,
      
      exam: `السلام علیکم محترم سرپرست،\nطالب علم {name} (رول نمبر {roll_no}، جماعت {class}) کے امتحانی نتائج مرتب ہو چکے ہیں۔ تفصیلی رزلٹ کارڈ و پروگریس رپورٹ کے لیے اسکول تشریف لائیں اور اساتذہ سے ملاقات فرمائیں۔\n\nDear Guardian, academic examination results for {name} (Roll No: {roll_no}, Class: {class}) have been prepared. Please visit ${schoolName} to collect the official progress card.`,
      
      meeting: `السلام علیکم محترم سرپرست،\nطالب علم {name} (جماعت {class}) کی تعلیمی و اخلاقی کارکردگی کے حوالے سے اسکول میں والدین اور اساتذہ کا اہم مشاورتی اجلاس (PTM) مقرر کیا گیا ہے۔ آپ کی تشریف آوری انتہائی ضروری ہے۔\n\nRespected Parent, you are cordially invited to attend the Parent-Teacher Meeting (PTM) regarding {name} ({class}) at ${schoolName}.`,
      
      holiday: `السلام علیکم،\nتمام طلباء و سرپرستوں کو مطلع کیا جاتا ہے کہ سرکاری/اسکول شیڈول کے مطابق اسکول میں تعطیل رہے گی۔ تدریسی سرگرمیاں اگلے روز معمول کے مطابق بحال ہوں گی۔\n\nNotification: ${schoolName} will observe a holiday. Regular academic classes will resume on the next working day.`
    };
  },

  applyWhatsAppTemplate(templateKey) {
    this.waTemplate = templateKey;
    document.querySelectorAll('.template-chip').forEach(chip => {
      chip.classList.toggle('active', chip.getAttribute('data-template') === templateKey);
    });

    const templates = this.getWhatsAppTemplates();
    const text = templates[templateKey] || templates.custom;
    const textarea = document.getElementById('wa-message-textarea');
    if (textarea) {
      textarea.value = text;
      this.updateWhatsAppMessagePreview();
    }
  },

  updateWhatsAppMessagePreview() {
    const textarea = document.getElementById('wa-message-textarea');
    let text = textarea ? textarea.value : '';
    if (!text.trim()) {
      text = 'Type your WhatsApp announcement message above... (اپنا پیغام درج کریں)';
    }

    const sample = {
      name: 'Muhammad Ali',
      guardian: 'Tariq Khan',
      roll_no: '1001',
      class: 'Grade 10',
      school: SchoolDB.data.settings?.schoolName || 'GOVT: HIGH SCHOOL ZANDO DHERI, MARDAN',
      date: new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })
    };

    let preview = text
      .replace(/{name}/g, sample.name)
      .replace(/{guardian}/g, sample.guardian)
      .replace(/{roll_no}/g, sample.roll_no)
      .replace(/{class}/g, sample.class)
      .replace(/{school}/g, sample.school)
      .replace(/{date}/g, sample.date);

    let formattedHtml = preview
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/\*(.*?)\*/g, '<strong>$1</strong>')
      .replace(/_(.*?)_/g, '<em>$1</em>')
      .replace(/~(.*?)~/g, '<del>$1</del>')
      .replace(/\n/g, '<br>');

    const bubbleText = document.getElementById('wa-preview-bubble-text');
    if (bubbleText) bubbleText.innerHTML = formattedHtml;

    const timeElem = document.getElementById('wa-preview-bubble-time');
    if (timeElem) {
      const now = new Date();
      timeElem.textContent = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }
  },

  renderWhatsAppRecipients() {
    const tbody = document.getElementById('wa-recipients-tbody');
    if (!tbody) return;

    const targetType = document.getElementById('wa-target-type')?.value || 'class';
    const selectedClass = document.getElementById('wa-class-select')?.value || '';
    const query = (document.getElementById('wa-recipient-search')?.value || '').toLowerCase().trim();

    let items = [];

    if (targetType === 'class') {
      const students = SchoolDB.getStudents();
      const cls = SchoolDB.getClassById(selectedClass);
      items = students.filter(s => {
        let match = true;
        if (cls) {
          match = match && s.grade === cls.name && s.section === cls.section;
        } else if (selectedClass) {
          match = match && (s.grade === selectedClass || `${s.grade} (${s.section})` === selectedClass);
        }
        return match;
      }).map(s => ({
        id: s.id,
        type: 'student',
        name: s.name,
        rollNo: s.rollNo,
        classOrDept: `${s.grade} - Sec ${s.section}`,
        grade: s.grade,
        guardian: s.guardian,
        phone: s.phone
      }));
    } else if (targetType === 'teachers') {
      const teachers = SchoolDB.getTeachers();
      items = teachers.map(t => ({
        id: t.id,
        type: 'teacher',
        name: t.name,
        rollNo: t.id,
        classOrDept: t.qualification || 'Faculty',
        grade: 'Faculty',
        guardian: 'Staff / Faculty',
        phone: t.phone
      }));
    } else {
      // All students
      const students = SchoolDB.getStudents();
      items = students.map(s => ({
        id: s.id,
        type: 'student',
        name: s.name,
        rollNo: s.rollNo,
        classOrDept: `${s.grade} - Sec ${s.section}`,
        grade: s.grade,
        guardian: s.guardian,
        phone: s.phone
      }));
    }

    if (query) {
      items = items.filter(it => 
        it.name.toLowerCase().includes(query) ||
        it.rollNo.toLowerCase().includes(query) ||
        it.classOrDept.toLowerCase().includes(query) ||
        (it.guardian && it.guardian.toLowerCase().includes(query)) ||
        (it.phone && it.phone.includes(query))
      );
    }

    if (!items.length) {
      tbody.innerHTML = `
        <tr>
          <td colspan="7">
            <div class="empty-state" style="padding: 24px;">
              <div class="empty-state-icon">&#128172;</div>
              <h4>No Recipients Found (کوئی وصول کنندہ نہیں ملا)</h4>
              <p>No matching students or teachers for the selected filter criteria.</p>
            </div>
          </td>
        </tr>
      `;
      this.updateWhatsAppRecipientCount();
      return;
    }

    tbody.innerHTML = items.map((it, idx) => {
      const cleanPhone = SchoolDB.formatWhatsAppNumber(it.phone);
      const isValid = Boolean(cleanPhone);

      return `
        <tr data-recipient-index="${idx}">
          <td>
            <input type="checkbox" class="wa-recipient-check" data-id="${it.id}" data-type="${it.type}" data-phone="${it.phone || ''}" checked onchange="App.updateWhatsAppRecipientCount()">
          </td>
          <td>
            <div style="font-weight: 600; color: var(--text-main);">${it.name}</div>
            <small class="text-muted">ID: ${it.id} ${it.type === 'student' ? '| Roll: ' + it.rollNo : ''}</small>
          </td>
          <td><span class="badge" style="background: #e0f2fe; color: #0284c7;">${it.classOrDept}</span></td>
          <td>${it.guardian || '-'}</td>
          <td>
            ${it.phone ? `<strong>${it.phone}</strong>` : `<span class="text-muted">No number</span>`}
          </td>
          <td>
            ${isValid ? 
              `<span class="badge status-active" style="font-size: 11px;"><span style="color:#25D366; font-size:14px; vertical-align:middle;">&#9679;</span> +${cleanPhone}</span>` : 
              `<span class="badge status-absent" style="font-size: 11px;">&#9888; Invalid Phone</span>`
            }
          </td>
          <td>
            <button class="btn btn-whatsapp btn-sm" onclick="App.openWhatsAppForRecipientById('${it.id}', '${it.type}')" title="Open direct WhatsApp chat with this recipient" ${!isValid ? 'disabled style="opacity:0.5; cursor:not-allowed;"' : ''}>
              &#128172; Chat
            </button>
          </td>
        </tr>
      `;
    }).join('');

    this.updateWhatsAppRecipientCount();
  },

  updateWhatsAppRecipientCount() {
    const checkboxes = document.querySelectorAll('.wa-recipient-check:checked');
    const badge = document.getElementById('wa-recipients-counter-badge');
    const selectAllBox = document.getElementById('wa-select-all-checkbox');
    const allCheckboxes = document.querySelectorAll('.wa-recipient-check');

    if (selectAllBox && allCheckboxes.length > 0) {
      selectAllBox.checked = (checkboxes.length === allCheckboxes.length);
    }

    if (badge) {
      badge.textContent = `👥 ${checkboxes.length} Selected Recipients`;
    }
  },

  toggleAllWhatsAppRecipients(isChecked) {
    const checkboxes = document.querySelectorAll('.wa-recipient-check');
    checkboxes.forEach(cb => cb.checked = isChecked);
    this.updateWhatsAppRecipientCount();
  },

  buildRecipientMessage(rawTemplate, entity, type) {
    const schoolName = SchoolDB.data.settings?.schoolName || 'GOVT: HIGH SCHOOL ZANDO DHERI, MARDAN PAKISTAN';
    const today = new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });

    let message = rawTemplate || '';
    if (type === 'student') {
      message = message
        .replace(/{name}/g, entity.name || '')
        .replace(/{guardian}/g, entity.guardian || 'Guardian')
        .replace(/{roll_no}/g, entity.rollNo || '')
        .replace(/{class}/g, `${entity.grade || ''} (${entity.section || ''})`)
        .replace(/{school}/g, schoolName)
        .replace(/{date}/g, today);
    } else {
      message = message
        .replace(/{name}/g, entity.name || '')
        .replace(/{guardian}/g, 'Respected Colleague')
        .replace(/{roll_no}/g, entity.id || '')
        .replace(/{class}/g, entity.qualification || 'Faculty')
        .replace(/{school}/g, schoolName)
        .replace(/{date}/g, today);
    }
    return message;
  },

  openWhatsAppForRecipientById(id, type) {
    if (!this.requireAdmin()) return;

    let entity = (type === 'student') ? SchoolDB.getStudentById(id) : SchoolDB.getTeacherById(id);
    if (!entity) {
      this.showToast('Recipient not found in database.', 'error');
      return;
    }

    const cleanPhone = SchoolDB.formatWhatsAppNumber(entity.phone);
    if (!cleanPhone) {
      this.showToast(`Cannot launch WhatsApp: ${entity.name} has an invalid or missing mobile number.`, 'warning');
      return;
    }

    const rawTemplate = document.getElementById('wa-message-textarea')?.value || '';
    const message = this.buildRecipientMessage(rawTemplate, entity, type);
    const url = SchoolDB.getWhatsAppLink(entity.phone, message);

    if (url) {
      window.open(url, '_blank');
      this.showToast(`Launching WhatsApp chat for ${entity.name}...`);
    }
  },

  launchNextWhatsAppRecipient() {
    if (!this.requireAdmin()) return;

    const checkedBoxes = Array.from(document.querySelectorAll('.wa-recipient-check:checked'));
    if (!checkedBoxes.length) {
      this.showToast('No recipients selected! Please check recipients to message.', 'warning');
      return;
    }

    const validRecipients = [];
    checkedBoxes.forEach(cb => {
      const id = cb.getAttribute('data-id');
      const type = cb.getAttribute('data-type');
      const entity = (type === 'student') ? SchoolDB.getStudentById(id) : SchoolDB.getTeacherById(id);
      if (entity && SchoolDB.formatWhatsAppNumber(entity.phone)) {
        validRecipients.push({ entity, type });
      }
    });

    if (!validRecipients.length) {
      this.showToast('None of the selected recipients have valid mobile numbers.', 'warning');
      return;
    }

    if (this.waCurrentQueueIndex >= validRecipients.length) {
      this.waCurrentQueueIndex = 0;
    }

    const current = validRecipients[this.waCurrentQueueIndex];
    const currentIndex = this.waCurrentQueueIndex + 1;
    this.waCurrentQueueIndex++;

    const rawTemplate = document.getElementById('wa-message-textarea')?.value || '';
    const message = this.buildRecipientMessage(rawTemplate, current.entity, current.type);
    const url = SchoolDB.getWhatsAppLink(current.entity.phone, message);

    if (url) {
      window.open(url, '_blank');
      this.showToast(`[${currentIndex}/${validRecipients.length}] WhatsApp opened for ${current.entity.name}. Click 'Launch Next' for next recipient!`);
    }
  },

  copyAllWhatsAppNumbers() {
    const checkedBoxes = Array.from(document.querySelectorAll('.wa-recipient-check:checked'));
    if (!checkedBoxes.length) {
      this.showToast('No recipients selected to copy.', 'warning');
      return;
    }

    const numbers = [];
    checkedBoxes.forEach(cb => {
      const phone = cb.getAttribute('data-phone');
      const formatted = SchoolDB.formatWhatsAppNumber(phone);
      if (formatted && !numbers.includes(formatted)) {
        numbers.push('+' + formatted);
      }
    });

    if (!numbers.length) {
      this.showToast('No valid phone numbers found among selected recipients.', 'warning');
      return;
    }

    const textToCopy = numbers.join(', ');
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(textToCopy).then(() => {
        this.showToast(`Copied ${numbers.length} mobile numbers to clipboard! Ready to paste into WhatsApp.`);
      }).catch(() => {
        prompt('Copy mobile numbers:', textToCopy);
      });
    } else {
      prompt('Copy mobile numbers:', textToCopy);
    }
  },

  copyWhatsAppMessage() {
    const textarea = document.getElementById('wa-message-textarea');
    if (!textarea || !textarea.value.trim()) {
      this.showToast('No message text to copy.', 'warning');
      return;
    }
    const textToCopy = textarea.value;
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(textToCopy).then(() => {
        this.showToast('WhatsApp message announcement copied to clipboard!');
      }).catch(() => {
        prompt('Copy message text:', textToCopy);
      });
    } else {
      prompt('Copy message text:', textToCopy);
    }
  },

  // Audio Voice Note In-Browser Studio
  async startAudioRecording() {
    if (!this.requireAdmin()) return;

    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      this.showToast('Microphone recording is not supported in this browser.', 'error');
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      this.audioChunks = [];
      
      let mimeType = '';
      if (typeof MediaRecorder !== 'undefined') {
        if (MediaRecorder.isTypeSupported('audio/webm;codecs=opus')) mimeType = 'audio/webm;codecs=opus';
        else if (MediaRecorder.isTypeSupported('audio/webm')) mimeType = 'audio/webm';
        else if (MediaRecorder.isTypeSupported('audio/mp4')) mimeType = 'audio/mp4';
        else if (MediaRecorder.isTypeSupported('audio/ogg')) mimeType = 'audio/ogg';
      }

      this.mediaRecorder = mimeType ? new MediaRecorder(stream, { mimeType }) : new MediaRecorder(stream);

      this.mediaRecorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
          this.audioChunks.push(e.data);
        }
      };

      this.mediaRecorder.onstop = () => {
        const finalMime = this.mediaRecorder.mimeType || 'audio/webm';
        this.recordedAudioBlob = new Blob(this.audioChunks, { type: finalMime });
        if (this.recordedAudioUrl) {
          URL.revokeObjectURL(this.recordedAudioUrl);
        }
        this.recordedAudioUrl = URL.createObjectURL(this.recordedAudioBlob);
        const player = document.getElementById('audio-playback-player');
        if (player) {
          player.src = this.recordedAudioUrl;
        }
        stream.getTracks().forEach(track => track.stop());
      };

      this.mediaRecorder.start();
      this.isRecording = true;
      this.recordingSeconds = 0;

      const idle = document.getElementById('audio-recorder-idle-state');
      const rec = document.getElementById('audio-recorder-recording-state');
      const play = document.getElementById('audio-recorder-playback-state');
      if (idle) idle.style.display = 'none';
      if (rec) rec.style.display = 'block';
      if (play) play.style.display = 'none';

      const timer = document.getElementById('audio-record-timer');
      if (timer) timer.textContent = '00:00';
      clearInterval(this.recordingTimerInterval);
      this.recordingTimerInterval = setInterval(() => {
        this.recordingSeconds++;
        const mins = String(Math.floor(this.recordingSeconds / 60)).padStart(2, '0');
        const secs = String(this.recordingSeconds % 60).padStart(2, '0');
        if (timer) timer.textContent = `${mins}:${secs}`;
      }, 1000);

      this.showToast('Microphone recording started! Speak clearly.');
    } catch (err) {
      console.error('Audio recorder error:', err);
      this.showToast('Microphone access denied or error: ' + err.message, 'error');
    }
  },

  stopAudioRecording() {
    if (this.mediaRecorder && this.isRecording) {
      this.mediaRecorder.stop();
      this.isRecording = false;
      clearInterval(this.recordingTimerInterval);

      const rec = document.getElementById('audio-recorder-recording-state');
      const play = document.getElementById('audio-recorder-playback-state');
      if (rec) rec.style.display = 'none';
      if (play) play.style.display = 'block';

      this.showToast('Voice note recorded! You can listen, download, or re-record.');
    }
  },

  downloadAudioRecording() {
    if (!this.recordedAudioBlob) {
      this.showToast('No audio recording available to download.', 'warning');
      return;
    }
    const ext = this.recordedAudioBlob.type.includes('mp4') ? 'mp4' : 'webm';
    const a = document.createElement('a');
    a.href = this.recordedAudioUrl;
    a.download = `voice_note_ghs_zando_dheri_${Date.now()}.${ext}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    this.showToast('Voice note downloaded! Attach it directly in WhatsApp Web chat.');
  },

  // Contextual Quick WhatsApp Action Triggers
  quickWhatsAppStudent(studentId) {
    if (!this.requireAdmin()) return;
    const student = SchoolDB.getStudentById(studentId);
    if (!student) return;
    const cleanPhone = SchoolDB.formatWhatsAppNumber(student.phone);
    if (!cleanPhone) {
      this.showToast(`Cannot message: Student ${student.name} does not have a valid mobile number.`, 'warning');
      return;
    }
    const schoolName = SchoolDB.data.settings?.schoolName || 'GOVT: HIGH SCHOOL ZANDO DHERI, MARDAN PAKISTAN';
    const msg = `السلام علیکم محترم سرپرست! ${schoolName} کی طرف سے طالب علم ${student.name} (رول نمبر: ${student.rollNo}، جماعت: ${student.grade} - ${student.section}) کے سلسلے میں رابطہ کیا جا رہا ہے۔\n\nAssalam-o-Alaikum! Official communication regarding ${student.name} (Roll No: ${student.rollNo}, Class: ${student.grade}).`;
    const url = SchoolDB.getWhatsAppLink(student.phone, msg);
    if (url) {
      window.open(url, '_blank');
      this.showToast(`Opening WhatsApp chat for ${student.name}...`);
    }
  },

  quickWhatsAppTeacher(teacherId) {
    if (!this.requireAdmin()) return;
    const teacher = SchoolDB.getTeacherById(teacherId);
    if (!teacher) return;
    const cleanPhone = SchoolDB.formatWhatsAppNumber(teacher.phone);
    if (!cleanPhone) {
      this.showToast(`Cannot message: Teacher ${teacher.name} does not have a valid mobile number.`, 'warning');
      return;
    }
    const schoolName = SchoolDB.data.settings?.schoolName || 'GOVT: HIGH SCHOOL ZANDO DHERI, MARDAN PAKISTAN';
    const msg = `السلام علیکم محترم ${teacher.name} صاحب! ${schoolName} کی انتظامیہ کی جانب سے تدریسی امور اور اجلاس کے حوالے سے نوٹس۔\n\nAssalam-o-Alaikum ${teacher.name}! Official notification from Administration, ${schoolName}.`;
    const url = SchoolDB.getWhatsAppLink(teacher.phone, msg);
    if (url) {
      window.open(url, '_blank');
      this.showToast(`Opening WhatsApp chat for ${teacher.name}...`);
    }
  },

  sendWhatsAppAbsentNotice(studentId) {
    if (!this.requireAdmin()) return;
    const student = SchoolDB.getStudentById(studentId);
    if (!student) return;
    const cleanPhone = SchoolDB.formatWhatsAppNumber(student.phone);
    if (!cleanPhone) {
      this.showToast(`Cannot message: Student ${student.name} has no valid mobile number.`, 'warning');
      return;
    }
    const schoolName = SchoolDB.data.settings?.schoolName || 'GOVT: HIGH SCHOOL ZANDO DHERI, MARDAN PAKISTAN';
    const today = new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
    const msg = `السلام علیکم محترم سرپرست،\nمطلع کیا جاتا ہے کہ آپ کا فرزند/دختر ${student.name} (رول نمبر: ${student.rollNo}، جماعت: ${student.grade}) آج بتاریخ ${today} اسکول سے غیر حاضر ہے۔ براہ کرم غیر حاضری کی وجہ تحریر فرمائیں یا اسکول دفتر رابطہ کریں۔\n\nRespected Guardian, your child ${student.name} (Roll No: ${student.rollNo}, ${student.grade}) is ABSENT today (${today}) from ${schoolName}.`;
    const url = SchoolDB.getWhatsAppLink(student.phone, msg);
    if (url) {
      window.open(url, '_blank');
      this.showToast(`Opening WhatsApp absent notice for ${student.name}...`);
    }
  },

  sendWhatsAppFeeReminder(feeId) {
    if (!this.requireAdmin()) return;
    const fees = SchoolDB.getFees();
    const fee = fees.find(f => f.id === feeId);
    if (!fee) return;
    const student = SchoolDB.getStudentById(fee.studentId);
    if (!student) return;
    const cleanPhone = SchoolDB.formatWhatsAppNumber(student.phone);
    if (!cleanPhone) {
      this.showToast(`Cannot message: Student ${student.name} has no valid mobile number.`, 'warning');
      return;
    }
    const schoolName = SchoolDB.data.settings?.schoolName || 'GOVT: HIGH SCHOOL ZANDO DHERI, MARDAN PAKISTAN';
    const currency = SchoolDB.data.settings?.currency || 'Rs. ';
    const balance = fee.amount - fee.paidAmount;
    const msg = `السلام علیکم محترم سرپرست،\nطالب علم ${student.name} (رول نمبر: ${student.rollNo}، جماعت: ${student.grade}) کا فیس چالان ${fee.id} (${fee.feeType}) کے واجبات (${currency}${balance}) بقایا ہیں۔ برائے مہربانی اسکول فیس کاؤنٹر پر جمع کروا کر رسید حاصل فرمائیں۔\n\nDear Parent, fee voucher reminder for ${student.name} (${student.grade}): Outstanding balance ${currency}${balance}. - ${schoolName}`;
    const url = SchoolDB.getWhatsAppLink(student.phone, msg);
    if (url) {
      window.open(url, '_blank');
      this.showToast(`Opening WhatsApp fee reminder for ${student.name}...`);
    }
  },

  // ====================================================================
  // PWA (Progressive Web App) Mobile & PC Installation Management
  // ====================================================================
  deferredPwaPrompt: null,

  initPWA() {
    // Register Service Worker on HTTPS or localhost
    if ('serviceWorker' in navigator && (window.location.protocol === 'https:' || window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1')) {
      navigator.serviceWorker.register('./sw.js')
        .then(reg => console.log('[PWA] Service worker active:', reg.scope))
        .catch(err => console.log('[PWA] Service worker notice:', err));
    }

    // Capture install prompt
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      this.deferredPwaPrompt = e;
      const installBtns = document.querySelectorAll('.btn-pwa-install');
      installBtns.forEach(btn => btn.style.display = 'inline-flex');
    });

    window.addEventListener('appinstalled', () => {
      this.deferredPwaPrompt = null;
      const installBtns = document.querySelectorAll('.btn-pwa-install');
      installBtns.forEach(btn => btn.style.display = 'none');
      this.showToast('App installed successfully! (ایپ کامیابی سے انسٹال ہو گئی)', 'success');
    });
  },

  promptPWAInstall() {
    if (this.deferredPwaPrompt) {
      this.deferredPwaPrompt.prompt();
      this.deferredPwaPrompt.userChoice.then((choice) => {
        if (choice && choice.outcome === 'accepted') {
          console.log('[PWA] User accepted install prompt');
        }
        this.deferredPwaPrompt = null;
      });
    } else {
      const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
      if (isIOS) {
        alert('To Install on iPhone/iPad:\n1. Tap the Share button (⎋) at the bottom of Safari.\n2. Scroll down and tap "Add to Home Screen" (⊞).\n\n(آئی فون پر انسٹال کرنے کے لیے سفاری کے شیئر بٹن پر ٹیپ کریں اور Add to Home Screen منتخب کریں)');
      } else {
        alert('To install this app on your PC or phone:\n- On Google Chrome / MS Edge: Click the "Install" icon (⊞) in the browser address bar.\n- On Android: Tap browser menu (⋮) -> "Install App" or "Add to Home screen".');
      }
    }
  },

  // ====================================================================
  // Multi-Device Cloud Sync & Database Sharing
  // ====================================================================
  bindCloudSyncUI() {
    const enableCheck = document.getElementById('cloud-sync-enabled');
    const urlInput = document.getElementById('cloud-sync-url');
    const keyInput = document.getElementById('cloud-sync-key');
    const autoCheck = document.getElementById('cloud-sync-auto');

    if (enableCheck && typeof CloudSync !== 'undefined' && CloudSync.config) {
      enableCheck.checked = !!CloudSync.config.enabled;
      if (urlInput) urlInput.value = CloudSync.config.firebaseUrl || '';
      if (keyInput) keyInput.value = CloudSync.config.syncKey || '';
      if (autoCheck) autoCheck.checked = CloudSync.config.autoSync !== false;
    }
  },

  openCloudSyncModal() {
    this.bindCloudSyncUI();
    this.openModal('modal-cloud-sync');
  },

  saveCloudSyncSettings() {
    if (!this.requireAdmin()) return;
    const enableCheck = document.getElementById('cloud-sync-enabled');
    const urlInput = document.getElementById('cloud-sync-url');
    const keyInput = document.getElementById('cloud-sync-key');
    const autoCheck = document.getElementById('cloud-sync-auto');

    const newConfig = {
      enabled: enableCheck ? enableCheck.checked : false,
      firebaseUrl: urlInput ? urlInput.value.trim() : '',
      syncKey: keyInput ? keyInput.value.trim() : '',
      autoSync: autoCheck ? autoCheck.checked : true
    };

    CloudSync.saveConfig(newConfig);
    this.closeModal('modal-cloud-sync');

    if (newConfig.enabled && newConfig.firebaseUrl) {
      this.showToast('Cloud Sync settings saved! Syncing with cloud...', 'info');
      CloudSync.sync().then(res => {
        if (res && res.success) {
          this.showToast('Cloud database synchronized successfully! (کلاؤڈ سنک کامیاب)', 'success');
        } else {
          this.showToast('Connected! (No remote changes needed)', 'info');
        }
      }).catch(err => {
        this.showToast('Cloud sync error: ' + err.message, 'danger');
      });
    } else {
      this.showToast('Cloud Sync disabled. Local database active.', 'info');
    }
  },

  async triggerManualSync() {
    if (!navigator.onLine) {
      this.showToast('Device is offline. Reconnect to internet to sync.', 'warning');
      return;
    }
    if (!CloudSync.config.enabled || !CloudSync.config.firebaseUrl) {
      this.openCloudSyncModal();
      return;
    }
    this.showToast('Synchronizing with Cloud...', 'info');
    const res = await CloudSync.sync();
    if (res && res.success) {
      this.showToast('Synchronized with all devices! (تمام ڈیوائسز سے سنک ہو گیا)', 'success');
    } else {
      this.showToast('Sync completed: ' + (res?.reason || res?.error || 'OK'), 'info');
    }
  },

  async triggerPushToCloud() {
    if (!this.requireAdmin()) return;
    if (!navigator.onLine) {
      this.showToast('Device is offline.', 'warning');
      return;
    }
    try {
      this.showToast('Pushing local database to Cloud...', 'info');
      await CloudSync.pushToFirebase();
      this.showToast('Local database uploaded to Cloud successfully!', 'success');
    } catch (err) {
      this.showToast('Push error: ' + err.message, 'danger');
    }
  },

  async triggerPullFromCloud() {
    if (!this.requireAdmin()) return;
    if (!navigator.onLine) {
      this.showToast('Device is offline.', 'warning');
      return;
    }
    if (!confirm('Warning: Pulling from Cloud will replace or merge with your cloud database. Continue?')) {
      return;
    }
    try {
      this.showToast('Pulling newest data from Cloud...', 'info');
      await CloudSync.pullFromFirebase();
      this.showToast('Database updated from Cloud successfully!', 'success');
      this.syncBranding();
      this.updateDashboardCounters();
      this.renderCurrentView();
    } catch (err) {
      this.showToast('Pull error: ' + err.message, 'danger');
    }
  },

  async shareDatabaseSnapshot() {
    try {
      const dataStr = JSON.stringify(SchoolDB.data, null, 2);
      const schoolName = SchoolDB.data.settings?.schoolName || 'School';
      const cleanName = schoolName.replace(/[^a-zA-Z0-9]/g, '_').toLowerCase();
      const dateStr = new Date().toISOString().split('T')[0];
      const filename = `${cleanName}_backup_${dateStr}.json`;
      const blob = new Blob([dataStr], { type: 'application/json' });

      // Try native Web Share API (Android, iOS Safari, Windows Edge)
      if (navigator.share && navigator.canShare) {
        const file = new File([blob], filename, { type: 'application/json' });
        if (navigator.canShare({ files: [file] })) {
          await navigator.share({
            title: `${schoolName} - Database Backup`,
            text: `Official School Database Backup (${dateStr}) for Mobile & PC`,
            files: [file]
          });
          this.showToast('Shared successfully via WhatsApp / App!', 'success');
          return;
        }
      }

      // Fallback: download directly
      SchoolDB.exportJSON();
      this.showToast('Backup downloaded! You can share this JSON file via WhatsApp or Bluetooth.', 'info');
    } catch (err) {
      if (err.name !== 'AbortError') {
        SchoolDB.exportJSON();
      }
    }
  }
};

// Initialize application on DOM ready
document.addEventListener('DOMContentLoaded', () => {
  App.init();
});
