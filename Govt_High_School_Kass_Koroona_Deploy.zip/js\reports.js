/**
 * School Management Database - Reporting, Export, and Printing Engine
 */

const ReportEngine = {
  // Convert an array of objects to CSV string
  toCSV(dataArray, columns) {
    if (!dataArray || !dataArray.length) return '';
    const headers = columns.map(c => `"${c.label}"`).join(',');
    const rows = dataArray.map(item => {
      return columns.map(col => {
        let val = typeof col.key === 'function' ? col.key(item) : (item[col.key] ?? '');
        if (typeof val === 'string') {
          val = val.replace(/"/g, '""');
        }
        return `"${val}"`;
      }).join(',');
    });
    return [headers, ...rows].join('\r\n');
  },

  // Trigger file download
  downloadCSV(csvContent, filename) {
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  },

  // Export Students as CSV
  exportStudentsCSV() {
    const students = SchoolDB.getStudents();
    const columns = [
      { label: 'Admission No', key: 'id' },
      { label: 'Roll Number', key: 'rollNo' },
      { label: 'Full Name', key: 'name' },
      { label: 'Gender', key: 'gender' },
      { label: 'Date of Birth', key: 'dob' },
      { label: 'Class', key: 'grade' },
      { label: 'Section', key: 'section' },
      { label: 'Father Name', key: 'guardian' },
      { label: 'Phone', key: 'phone' },
      { label: 'Orphan / Disable', key: s => s.specialCategory || 'None' },
      { label: 'Status', key: 'status' },
      { label: 'Admission Date', key: 'admissionDate' }
    ];
    const csv = this.toCSV(students, columns);
    this.downloadCSV(csv, `students_roster_${new Date().toISOString().split('T')[0]}.csv`);
  },

  // Export Teaching & Non-teaching Staff as CSV
  exportTeachersCSV() {
    const teachers = SchoolDB.getTeachers();
    const columns = [
      { label: 'Employee ID', key: 'id' },
      { label: 'Full Name', key: 'name' },
      { label: 'Father Name', key: t => t.fatherName || '' },
      { label: 'Designation', key: t => t.designation || 'Staff' },
      { label: 'BPS', key: t => t.bps || 'BPS-16' },
      { label: 'Academic Qualification', key: t => t.qualification || '' },
      { label: 'Professional Qualification', key: t => t.profQualification || t.professionalQualification || '' },
      { label: 'Personal No', key: t => t.personalNo || '' },
      { label: 'CNIC No', key: t => t.cnic || '' },
      { label: 'Salary Account No', key: t => t.salaryAccount || '' },
      { label: 'Bank Code', key: t => t.bankCode || '' },
      { label: 'Bank Name', key: t => t.bankName || '' },
      { label: 'Phone', key: 'phone' },
      { label: 'Email', key: 'email' },
      { label: 'Gender', key: 'gender' },
      { label: 'Employment Status', key: 'status' },
      { label: 'Join Date', key: 'joinDate' }
    ];
    const csv = this.toCSV(teachers, columns);
    this.downloadCSV(csv, `teaching_and_non_teaching_staff_${new Date().toISOString().split('T')[0]}.csv`);
  },

  // Download Sample CSV Template for importing students
  downloadStudentCSVTemplate() {
    const columns = [
      { label: 'Admission No', key: 'id' },
      { label: 'Roll Number', key: 'rollNo' },
      { label: 'Full Name', key: 'name' },
      { label: 'Father Name', key: 'guardian' },
      { label: 'Gender', key: 'gender' },
      { label: 'Class', key: 'grade' },
      { label: 'Section', key: 'section' },
      { label: 'Date of Birth', key: 'dob' },
      { label: 'Phone', key: 'phone' },
      { label: 'Orphan / Disable', key: 'specialCategory' },
      { label: 'Home Address', key: 'address' },
      { label: 'Status', key: 'status' },
      { label: 'Admission Date', key: 'admissionDate' }
    ];
    const sampleData = [
      {
        id: '1001',
        rollNo: '101',
        name: 'Muhammad Tariq Khan',
        guardian: 'Abdul Qayyum',
        gender: 'Male',
        grade: 'Grade 10',
        section: 'A',
        dob: '2009-04-12',
        phone: '0300-8811001',
        specialCategory: 'None',
        address: 'Zando Dheri, Mardan, KP',
        status: 'Active',
        admissionDate: '2024-03-15'
      },
      {
        id: '1002',
        rollNo: '102',
        name: 'Sajid Ahmad',
        guardian: 'Farhad Ali',
        gender: 'Male',
        grade: 'Grade 10',
        section: 'A',
        dob: '2009-08-20',
        phone: '0300-8811002',
        specialCategory: 'Orphan',
        address: 'Zando Dheri, Mardan, KP',
        status: 'Active',
        admissionDate: '2024-03-15'
      },
      {
        id: '1003',
        rollNo: '103',
        name: 'Usman Ali',
        guardian: 'Hazrat Noor',
        gender: 'Male',
        grade: 'Grade 9',
        section: 'B',
        dob: '2010-01-10',
        phone: '0300-8811003',
        specialCategory: 'Disabled',
        address: 'Mardan City, KP',
        status: 'Active',
        admissionDate: '2024-03-15'
      }
    ];
    const csv = this.toCSV(sampleData, columns);
    this.downloadCSV(csv, 'students_sample_template.csv');
  },

  // Parse CSV text into array of student objects
  parseStudentsCSV(csvText) {
    if (!csvText || !csvText.trim()) return [];

    const rows = [];
    let row = [];
    let inQuotes = false;
    let currentVal = '';
    const cleanText = csvText.replace(/\r\n/g, '\n').replace(/\r/g, '\n');

    for (let i = 0; i < cleanText.length; i++) {
      const char = cleanText[i];
      const nextChar = cleanText[i + 1];

      if (char === '"') {
        if (inQuotes && nextChar === '"') {
          currentVal += '"';
          i++;
        } else {
          inQuotes = !inQuotes;
        }
      } else if (char === ',' && !inQuotes) {
        row.push(currentVal.trim());
        currentVal = '';
      } else if (char === '\n' && !inQuotes) {
        row.push(currentVal.trim());
        if (row.some(val => val.length > 0)) {
          rows.push(row);
        }
        row = [];
        currentVal = '';
      } else {
        currentVal += char;
      }
    }
    if (currentVal.length > 0 || row.length > 0) {
      row.push(currentVal.trim());
      if (row.some(val => val.length > 0)) {
        rows.push(row);
      }
    }

    if (rows.length < 2) return [];

    const headerRow = rows[0];
    const headerMap = {};

    headerRow.forEach((hdr, idx) => {
      const h = String(hdr).toLowerCase().replace(/[^a-z0-9]/g, '');
      if (h.includes('roll')) headerMap.rollNo = idx;
      else if (h.includes('guardian') || h.includes('father') || h.includes('parent') || h.includes('walid') || h.includes('sarparast')) headerMap.guardian = idx;
      else if (h.includes('fullname') || h.includes('studentname') || h === 'name' || h.includes('student')) headerMap.name = idx;
      else if (h.includes('gender') || h.includes('sex')) headerMap.gender = idx;
      else if (h.includes('dob') || h.includes('birth')) headerMap.dob = idx;
      else if (h.includes('class') || h.includes('grade')) headerMap.grade = idx;
      else if (h.includes('section') || h.includes('sec')) headerMap.section = idx;
      else if (h.includes('phone') || h.includes('mobile') || h.includes('contact')) headerMap.phone = idx;
      else if (h.includes('orphan') || h.includes('disable') || h.includes('special') || h.includes('maazoor') || h.includes('yateem')) headerMap.specialCategory = idx;
      else if (h.includes('email')) headerMap.email = idx;
      else if (h.includes('address') || h.includes('location')) headerMap.address = idx;
      else if (h.includes('status')) headerMap.status = idx;
      else if (h.includes('admissionno') || h.includes('admissionnum') || h.includes('admno') || h === 'id' || h.includes('studentid') || h.includes('admission')) {
        if (h.includes('date')) headerMap.admissionDate = idx;
        else headerMap.id = idx;
      }
    });

    if (headerMap.name === undefined) {
      if (headerRow.length >= 3) headerMap.name = 2;
      else headerMap.name = 0;
    }

    const students = [];
    for (let r = 1; r < rows.length; r++) {
      const data = rows[r];
      if (!data || !data.length) continue;

      const getVal = (field) => {
        const idx = headerMap[field];
        return (idx !== undefined && data[idx] !== undefined) ? String(data[idx]).trim() : '';
      };

      const name = getVal('name');
      if (!name) continue;

      let cat = getVal('specialCategory') || 'None';
      if (cat.toLowerCase().includes('orphan') && cat.toLowerCase().includes('disab')) cat = 'Orphan & Disabled';
      else if (cat.toLowerCase().includes('orphan') || cat.toLowerCase().includes('yateem')) cat = 'Orphan';
      else if (cat.toLowerCase().includes('disab') || cat.toLowerCase().includes('maazoor') || cat.toLowerCase().includes('handicap')) cat = 'Disabled';
      else if (!cat || cat.toLowerCase() === 'normal' || cat.toLowerCase() === 'no') cat = 'None';

      students.push({
        id: getVal('id'),
        rollNo: getVal('rollNo') || '',
        name: name,
        guardian: getVal('guardian') || '',
        gender: getVal('gender') || 'Male',
        grade: getVal('grade') || 'Grade 10',
        section: getVal('section') || 'A',
        dob: getVal('dob') || '',
        phone: getVal('phone') || '',
        specialCategory: cat,
        address: getVal('address') || 'Zando Dheri, Mardan, KP',
        status: getVal('status') || 'Active',
        admissionDate: getVal('admissionDate') || new Date().toISOString().split('T')[0],
        photo: ''
      });
    }

    return students;
  },

  // Export Fees as CSV
  exportFeesCSV() {
    const fees = SchoolDB.getFees();
    const students = SchoolDB.getStudents();
    const studentMap = {};
    students.forEach(s => studentMap[s.id] = s);

    const columns = [
      { label: 'Invoice ID', key: 'id' },
      { label: 'Student ID', key: 'studentId' },
      { label: 'Student Name', key: item => studentMap[item.studentId]?.name || 'Unknown' },
      { label: 'Class', key: item => `${studentMap[item.studentId]?.grade || ''} ${studentMap[item.studentId]?.section || ''}`.trim() },
      { label: 'Fee Type', key: 'feeType' },
      { label: 'Total Amount', key: 'amount' },
      { label: 'Paid Amount', key: 'paidAmount' },
      { label: 'Balance Due', key: item => item.amount - item.paidAmount },
      { label: 'Due Date', key: 'dueDate' },
      { label: 'Paid Date', key: 'paidDate' },
      { label: 'Status', key: 'status' },
      { label: 'Payment Method', key: 'method' }
    ];
    const csv = this.toCSV(fees, columns);
    this.downloadCSV(csv, `fee_records_${new Date().toISOString().split('T')[0]}.csv`);
  },

  // Export Stock items as CSV
  exportStockCSV(type = 'general') {
    const isPTC = type === 'ptc';
    const filterYear = isPTC ? (document.getElementById('stock-ptc-filter-year')?.value || '') : '';
    const items = isPTC && filterYear ? SchoolDB.getStockItems('ptc', '', '', '', filterYear) : SchoolDB.getStockItems(type);

    const columns = [
      { label: 'Record ID', key: 'id' },
      { label: isPTC ? 'PTC Ref / Voucher #' : 'Stock Code / Page #', key: 'itemCode' },
      { label: 'Item / Article Description', key: 'name' }
    ];

    if (isPTC) {
      columns.push({ label: 'PTC Release Year', key: item => item.releaseYear || '2024 - 2025' });
    }

    columns.push(
      { label: 'Category', key: 'category' },
      { label: isPTC ? 'Procurement Date' : 'Purchase / Entry Date', key: 'date' },
      { label: 'Quantity', key: 'quantity' },
      { label: 'Unit', key: 'unit' },
      { label: 'Unit Price (PKR)', key: 'unitPrice' },
      { label: 'Total Cost (PKR)', key: 'totalCost' },
      { label: isPTC ? 'PTC Resolution / Bill #' : 'Bill No / Vendor', key: 'billNo' },
      { label: isPTC ? 'Allocation / Room' : 'Location / Room', key: 'location' },
      { label: 'Condition / Status', key: 'condition' },
      { label: 'Remarks', key: 'remarks' }
    );

    const csv = this.toCSV(items, columns);
    const yearSuffix = isPTC && filterYear ? `_${filterYear.replace(/\s+/g, '')}` : '';
    const filename = isPTC ? `Stock_PTC_Register${yearSuffix}_${new Date().toISOString().split('T')[0]}.csv` : `Stock_General_Register_${new Date().toISOString().split('T')[0]}.csv`;
    this.downloadCSV(csv, filename);
  },

  // Print Official Stock Register (General or PTC) in A4 Landscape
  printStockRegister(type = 'general') {
    const isPTC = type === 'ptc';
    const filterYear = isPTC ? (document.getElementById('stock-ptc-filter-year')?.value || '') : '';
    const items = isPTC && filterYear ? SchoolDB.getStockItems('ptc', '', '', '', filterYear) : SchoolDB.getStockItems(type);
    const settings = SchoolDB.data.settings;

    let totalQty = 0;
    let totalWorth = 0;
    let workingCount = 0;
    let repairCount = 0;
    let condemnedCount = 0;

    items.forEach(i => {
      totalQty += Number(i.quantity) || 0;
      totalWorth += Number(i.totalCost) || 0;
      const cond = (i.condition || '').toLowerCase();
      if (cond.includes('repair')) repairCount++;
      else if (cond.includes('condemn') || cond.includes('write')) condemnedCount++;
      else workingCount++;
    });

    const regTitle = isPTC 
      ? `STOCK REGISTER - PARENT TEACHER COUNCIL (PTC FUND)${filterYear ? ` [${filterYear}]` : ''}`
      : 'STOCK REGISTER - GENERAL STORE & PERMANENT ASSETS';
    const regUrdu = isPTC
      ? `(اسٹاک رجسٹر پی ٹی سی فنڈ - والدین و اساتذہ کونسل ${filterYear ? `سال ${filterYear}` : ''})`
      : '(اسٹاک رجسٹر جنرل - مستقل اثاثہ جات و سازوسامان)';

    const rowsHTML = items.map((item, idx) => {
      let condColor = '#15803d';
      let condBg = '#dcfce7';
      if ((item.condition || '').toLowerCase().includes('repair')) {
        condColor = '#b45309'; condBg = '#fef3c7';
      } else if ((item.condition || '').toLowerCase().includes('condemn')) {
        condColor = '#b91c1c'; condBg = '#fee2e2';
      }

      const yearCell = isPTC ? `
        <td style="text-align: center; white-space: nowrap; font-weight: 700; color: #6d28d9; background: #faf5ff;">
          ${item.releaseYear || '2024 - 2025'}
        </td>
      ` : '';

      return `
        <tr>
          <td style="text-align: center; font-weight: 600;">${idx + 1}</td>
          <td style="font-weight: 700; color: #1e3a8a; white-space: nowrap;">${item.itemCode || '-'}</td>
          <td>
            <strong>${item.name}</strong>
            ${item.remarks ? `<br><small style="color: #64748b;">${item.remarks}</small>` : ''}
          </td>
          ${yearCell}
          <td><span style="background: #f1f5f9; padding: 2px 6px; border-radius: 4px; font-size: 10px;">${item.category || '-'}</span></td>
          <td style="text-align: center; white-space: nowrap;">${item.date || '-'}</td>
          <td style="text-align: center; font-weight: 700;">${item.quantity} ${item.unit || 'Nos'}</td>
          <td style="text-align: right;">${settings.currency}${(Number(item.unitPrice) || 0).toLocaleString()}</td>
          <td style="text-align: right; font-weight: 800; color: #0f172a;">${settings.currency}${(Number(item.totalCost) || 0).toLocaleString()}</td>
          <td style="font-size: 10px;">${item.billNo || '-'}</td>
          <td style="font-size: 10.5px;">${item.location || '-'}</td>
          <td style="text-align: center;">
            <span style="background: ${condBg}; color: ${condColor}; padding: 2px 6px; border-radius: 4px; font-size: 10px; font-weight: 600;">
              ${item.condition || 'Working'}
            </span>
          </td>
        </tr>
      `;
    }).join('');

    const htmlContent = `
      <div class="printable-target" style="padding: 10px; font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, Arial, sans-serif;">
        <!-- Header -->
        <div style="display: flex; align-items: center; justify-content: space-between; border-bottom: 2px solid #1e3a8a; padding-bottom: 8px; margin-bottom: 10px;">
          <div style="display: flex; align-items: center; gap: 12px;">
            <img src="images/monogram school.jpg" alt="Monogram" style="width: 55px; height: 55px; object-fit: contain; border-radius: 6px;">
            <div>
              <h2 style="margin: 0; font-size: 17px; color: #1e3a8a; font-weight: 800; text-transform: uppercase;">
                ${settings.schoolName}
              </h2>
              <p style="margin: 2px 0 0; font-size: 11px; color: #475569;">
                ${settings.address} &bull; Ph: ${settings.phone} &bull; Academic Year: ${settings.academicYear}
              </p>
            </div>
          </div>
          <div style="text-align: right;">
            <div style="font-size: 14px; font-weight: 800; color: #0f172a; letter-spacing: 0.3px;">
              ${regTitle}
            </div>
            <div style="font-size: 11px; color: #1e3a8a; font-weight: 700;">
              ${regUrdu}
            </div>
          </div>
        </div>

        <!-- Summary Metrics Strip -->
        <div style="display: flex; justify-content: space-between; background: #f8fafc; border: 1px solid #cbd5e1; border-radius: 6px; padding: 6px 14px; margin-bottom: 10px; font-size: 11px;">
          <div>Total Articles / Items: <strong>${items.length}</strong> <span class="urdu-title">(کل اشیاء)</span></div>
          <div>Total Stock Units: <strong>${totalQty.toLocaleString()}</strong> <span class="urdu-title">(کل مقدار)</span></div>
          <div>Total Estimated Value: <strong style="color: #0369a1;">${settings.currency}${totalWorth.toLocaleString()}</strong> <span class="urdu-title">(کل مالیت)</span></div>
          <div>Working / Usable: <strong style="color: #15803d;">${workingCount}</strong> &bull; Under Repair: <strong style="color: #b45309;">${repairCount}</strong> &bull; Condemned: <strong style="color: #b91c1c;">${condemnedCount}</strong></div>
        </div>

        <!-- Stock Table -->
        <table style="width: 100%; border-collapse: collapse; font-size: 10.5px;">
          <thead>
            <tr style="background-color: #f1f5f9;">
              <th style="padding: 5px 4px; border: 1px solid #cbd5e1; text-align: center; width: 30px;">#</th>
              <th style="padding: 5px 4px; border: 1px solid #cbd5e1; text-align: left; width: 85px;">Code / Page</th>
              <th style="padding: 5px 6px; border: 1px solid #cbd5e1; text-align: left;">Article / Description (نام اشیاء)</th>
              ${isPTC ? '<th style="padding: 5px 4px; border: 1px solid #cbd5e1; text-align: center; width: 85px;">Release Year</th>' : ''}
              <th style="padding: 5px 4px; border: 1px solid #cbd5e1; text-align: left; width: 80px;">Category</th>
              <th style="padding: 5px 4px; border: 1px solid #cbd5e1; text-align: center; width: 75px;">Date</th>
              <th style="padding: 5px 4px; border: 1px solid #cbd5e1; text-align: center; width: 70px;">Quantity</th>
              <th style="padding: 5px 4px; border: 1px solid #cbd5e1; text-align: right; width: 75px;">Unit Price</th>
              <th style="padding: 5px 6px; border: 1px solid #cbd5e1; text-align: right; width: 85px;">Total Cost</th>
              <th style="padding: 5px 6px; border: 1px solid #cbd5e1; text-align: left; width: 140px;">Bill / Resolution</th>
              <th style="padding: 5px 6px; border: 1px solid #cbd5e1; text-align: left; width: 110px;">Room / Location</th>
              <th style="padding: 5px 4px; border: 1px solid #cbd5e1; text-align: center; width: 75px;">Condition</th>
            </tr>
          </thead>
          <tbody>
            ${rowsHTML || `<tr><td colspan="${isPTC ? 12 : 11}" style="text-align:center; padding:15px;">No stock items recorded.</td></tr>`}
          </tbody>
          <tfoot>
            <tr style="background: #f8fafc; font-weight: 700;">
              <td colspan="${isPTC ? 6 : 5}" style="padding: 6px 8px; border: 1px solid #cbd5e1; text-align: right;">Total Cumulative Value (میزان کل رقم):</td>
              <td style="padding: 6px 4px; border: 1px solid #cbd5e1; text-align: center;">${totalQty.toLocaleString()}</td>
              <td style="padding: 6px 4px; border: 1px solid #cbd5e1;"></td>
              <td style="padding: 6px 6px; border: 1px solid #cbd5e1; text-align: right; color: #1e3a8a;">${settings.currency}${totalWorth.toLocaleString()}</td>
              <td colspan="3" style="padding: 6px 6px; border: 1px solid #cbd5e1;"></td>
            </tr>
          </tfoot>
        </table>

        <!-- Signatures -->
        <div style="margin-top: 24px; display: flex; justify-content: space-between; align-items: flex-end; font-size: 11.5px; padding-top: 12px; border-top: 1.5px solid #cbd5e1;">
          <div style="text-align: center; width: 220px;">
            <div style="border-bottom: 1px solid #000; height: 30px; margin-bottom: 5px;"></div>
            <span>${isPTC ? 'General Secretary PTC (سیکرٹری پی ٹی سی)' : 'Stock / Store Incharge (اسٹاک انچارج)'}</span>
          </div>
          <div style="text-align: center; width: 220px;">
            <div style="border-bottom: 1px solid #000; height: 30px; margin-bottom: 5px;"></div>
            <span>${isPTC ? 'Chairman PTC (چیئرمین پی ٹی سی)' : 'Stock Verification Member (ممبر کمیٹی)'}</span>
          </div>
          <div style="text-align: center; width: 220px;">
            <div style="border-bottom: 1px solid #000; height: 30px; margin-bottom: 5px;"></div>
            <strong style="font-size: 12px;">Principal / Headmaster <span class="urdu-title">(پرنسپل / ہیڈ ماسٹر)</span></strong>
          </div>
        </div>

        <!-- Footer watermark -->
        <div style="margin-top: 10px; font-size: 9.5px; color: #64748b; display: flex; justify-content: space-between; align-items: center; border-top: 1px dotted #cbd5e1; padding-top: 4px;">
          <span>Govt: High School Zando Dheri, Mardan &bull; Official Inventory Register Document</span>
          <span>Designed &amp; Developed by: <strong>Shaukat Zando</strong></span>
        </div>
      </div>
    `;

    this.printLandscapeElement(htmlContent);
  },

  // Export Free Text Books as CSV
  exportFreeTextBooksCSV() {
    const filterYear = document.getElementById('ftb-filter-year')?.value || '';
    const filterGrade = document.getElementById('ftb-filter-grade')?.value || '';
    const items = SchoolDB.getFreeTextBooks(filterYear, filterGrade);

    const mappedItems = items.map(item => ({
      ...item,
      totalDistributed: (Number(item.distributedNew) || 0) + (Number(item.distributedOld) || 0)
    }));

    const columns = [
      { label: 'Record ID', key: 'id' },
      { label: 'Academic Year (تعلیمی سال)', key: 'year' },
      { label: 'Class / Grade (جماعت)', key: 'grade' },
      { label: 'Book Title / Subject (کتاب / مضمون)', key: 'bookTitle' },
      { label: 'Books Received New (نئی موصول شدہ)', key: 'receivedNew' },
      { label: 'Books Distributed New (نئی تقسیم شدہ)', key: 'distributedNew' },
      { label: 'Old Books Collected (پرانی وصول شدہ)', key: 'collectedOld' },
      { label: 'Old Books Distributed (پرانی تقسیم شدہ)', key: 'distributedOld' },
      { label: 'Total Books Distributed (کل تقسیم شدہ کتب)', key: 'totalDistributed' },
      { label: 'Old in Stock (پرانی اسٹاک)', key: 'stockOld' },
      { label: 'New in Stock (نئی اسٹاک)', key: 'stockNew' },
      { label: 'Total Balance in Stock (کل بقایا)', key: 'balance' },
      { label: 'Remarks / Notes (کیفیات)', key: 'remarks' }
    ];

    const csv = this.toCSV(mappedItems, columns);
    const yearSuffix = filterYear ? `_${filterYear.replace(/\s+/g, '')}` : '';
    const gradeSuffix = filterGrade ? `_${filterGrade.replace(/\s+/g, '')}` : '';
    const filename = `Free_Text_Books_Register${yearSuffix}${gradeSuffix}_${new Date().toISOString().split('T')[0]}.csv`;
    this.downloadCSV(csv, filename);
  },

  // Download Sample CSV Template for Free Text Books
  downloadFreeTextBooksCSVTemplate() {
    const headers = [
      'Year',
      'Class',
      'Book Title',
      'Books Received',
      'Books Distributed',
      'Old Books Collected',
      'Old Books Distributed',
      'Old in Stock',
      'New in Stock',
      'Balance',
      'Remarks'
    ];

    const sampleRows = [
      ['2024 - 2025', 'Grade 6', 'English Grade 6', '125', '120', '75', '70', '5', '5', '10', 'KP Textbook Board Peshawar'],
      ['2024 - 2025', 'Grade 6', 'Mathematics (ریاضی)', '130', '124', '80', '78', '2', '6', '8', 'KP Textbook Board Peshawar'],
      ['2024 - 2025', 'Grade 6', 'History (تاریخ)', '120', '115', '70', '68', '2', '5', '7', 'Separate Middle Curriculum Subject'],
      ['2024 - 2025', 'Grade 6', 'Geography (جغرافیہ)', '120', '116', '68', '66', '2', '4', '6', 'Separate Middle Curriculum Subject'],
      ['2024 - 2025', 'Grade 6', 'Islamiyat (Compulsory) (اسلامیات لازمی)', '125', '120', '90', '88', '2', '5', '7', 'KP Textbook Board Peshawar'],
      ['2024 - 2025', 'Grade 9', 'Islamiyat (E) (اسلامیات اختیاری)', '45', '42', '20', '18', '2', '3', '5', 'Elective Arts Subject'],
      ['2024 - 2025', 'Grade 9', 'Physics (طبیعیات)', '95', '90', '40', '38', '2', '5', '7', 'Science Section'],
      ['2024 - 2025', 'Grade 10', 'Pakistan Studies (مطالعہ پاکستان)', '90', '89', '55', '53', '2', '1', '3', 'KP Textbook Board Peshawar']
    ];

    const csvLines = [headers.join(',')];
    sampleRows.forEach(row => {
      const escaped = row.map(cell => `"${String(cell).replace(/"/g, '""')}"`);
      csvLines.push(escaped.join(','));
    });

    const csvContent = '\uFEFF' + csvLines.join('\r\n');
    this.downloadCSV(csvContent, 'Free_Text_Books_Template.csv');
  },

  // Parse Uploaded Free Text Books CSV / SVC Text
  parseFreeTextBooksCSV(csvText) {
    if (!csvText || !csvText.trim()) return [];

    const lines = [];
    let currentRow = [];
    let currentField = '';
    let insideQuotes = false;

    const cleanText = csvText.replace(/\r\n/g, '\n').replace(/\r/g, '\n');

    for (let i = 0; i < cleanText.length; i++) {
      const ch = cleanText[i];
      if (ch === '"') {
        if (insideQuotes && cleanText[i + 1] === '"') {
          currentField += '"';
          i++;
        } else {
          insideQuotes = !insideQuotes;
        }
      } else if (ch === ',' && !insideQuotes) {
        currentRow.push(currentField.trim());
        currentField = '';
      } else if (ch === '\n' && !insideQuotes) {
        currentRow.push(currentField.trim());
        if (currentRow.some(val => val.length > 0)) {
          lines.push(currentRow);
        }
        currentRow = [];
        currentField = '';
      } else {
        currentField += ch;
      }
    }
    if (currentField.length > 0 || currentRow.length > 0) {
      currentRow.push(currentField.trim());
      if (currentRow.some(val => val.length > 0)) {
        lines.push(currentRow);
      }
    }

    if (lines.length < 2) return [];

    const headerRow = lines[0];
    const headerMap = {};

    headerRow.forEach((hdr, idx) => {
      const h = String(hdr).toLowerCase().replace(/[^a-z0-9]/g, '');
      if (h.includes('year') || h.includes('sal') || h.includes('academic')) headerMap.year = idx;
      else if (h.includes('class') || h.includes('grade') || h.includes('jamaat')) headerMap.grade = idx;
      else if (h.includes('title') || h.includes('book') || h.includes('subject') || h.includes('kitab') || h.includes('mazmoon') || h.includes('item')) headerMap.bookTitle = idx;
      else if (h.includes('received') && !h.includes('old') && !h.includes('coll')) headerMap.receivedNew = idx;
      else if (h.includes('distributed') && !h.includes('old')) headerMap.distributedNew = idx;
      else if (h.includes('collected') || (h.includes('old') && h.includes('rec')) || (h.includes('old') && h.includes('coll'))) headerMap.collectedOld = idx;
      else if (h.includes('old') && h.includes('dist')) headerMap.distributedOld = idx;
      else if (h.includes('stockold') || (h.includes('old') && h.includes('stock'))) headerMap.stockOld = idx;
      else if (h.includes('stocknew') || (h.includes('new') && h.includes('stock'))) headerMap.stockNew = idx;
      else if (h.includes('balance') || h.includes('baqaya') || h.includes('totstock')) headerMap.balance = idx;
      else if (h.includes('remark') || h.includes('note') || h.includes('kaifiyat') || h.includes('detail')) headerMap.remarks = idx;
      else if (h.includes('id') || h.includes('code')) headerMap.id = idx;
    });

    if (headerMap.bookTitle === undefined) {
      if (headerRow.length >= 3) headerMap.bookTitle = 2;
      else headerMap.bookTitle = 0;
    }

    const books = [];
    for (let r = 1; r < lines.length; r++) {
      const data = lines[r];
      if (!data || !data.length) continue;

      const getVal = (field) => {
        const idx = headerMap[field];
        return (idx !== undefined && data[idx] !== undefined) ? String(data[idx]).trim() : '';
      };

      const bookTitle = getVal('bookTitle');
      if (!bookTitle) continue;

      const recNew = Number(getVal('receivedNew')) || 0;
      const distNew = Number(getVal('distributedNew')) || 0;
      const collOld = Number(getVal('collectedOld')) || 0;
      const distOld = Number(getVal('distributedOld')) || 0;

      let sNew = getVal('stockNew') !== '' ? Number(getVal('stockNew')) : Math.max(0, recNew - distNew);
      let sOld = getVal('stockOld') !== '' ? Number(getVal('stockOld')) : Math.max(0, collOld - distOld);
      let bal = getVal('balance') !== '' ? Number(getVal('balance')) : (sNew + sOld);

      books.push({
        id: getVal('id'),
        year: getVal('year') || '2024 - 2025',
        grade: getVal('grade') || 'Grade 6',
        bookTitle: bookTitle,
        receivedNew: recNew,
        distributedNew: distNew,
        collectedOld: collOld,
        distributedOld: distOld,
        stockNew: sNew,
        stockOld: sOld,
        balance: bal,
        remarks: getVal('remarks') || ''
      });
    }

    return books;
  },

  // Print Official Free Text Books Register in A4 Landscape
  printFreeTextBooksRegister() {
    const filterYear = document.getElementById('ftb-filter-year')?.value || '';
    const filterGrade = document.getElementById('ftb-filter-grade')?.value || '';
    const items = SchoolDB.getFreeTextBooks(filterYear, filterGrade);
    const settings = SchoolDB.data.settings;

    let totRecNew = 0, totDistNew = 0, totCollOld = 0, totDistOld = 0, totTotalDist = 0, totStockOld = 0, totStockNew = 0, totBalance = 0;

    items.forEach(i => {
      const dNew = Number(i.distributedNew) || 0;
      const dOld = Number(i.distributedOld) || 0;
      totRecNew += Number(i.receivedNew) || 0;
      totDistNew += dNew;
      totCollOld += Number(i.collectedOld) || 0;
      totDistOld += dOld;
      totTotalDist += (dNew + dOld);
      totStockOld += Number(i.stockOld) || 0;
      totStockNew += Number(i.stockNew) || 0;
      totBalance += Number(i.balance) || 0;
    });

    const regTitle = `FREE TEXT BOOKS REGISTER${filterYear ? ` - ACADEMIC YEAR ${filterYear}` : ''}${filterGrade ? ` [${filterGrade.toUpperCase()}]` : ''}`;
    const regUrdu = `(رجسٹر مفت درسی کتب - خیبر پختونخوا ٹیکسٹ بک بورڈ پشاور${filterYear ? ` سال ${filterYear}` : ''}${filterGrade ? ` جماعت ${filterGrade}` : ''})`;

    const rowsHTML = items.map((item, idx) => {
      const dNew = Number(item.distributedNew) || 0;
      const dOld = Number(item.distributedOld) || 0;
      const tDist = dNew + dOld;
      return `
        <tr>
          <td style="text-align: center; font-weight: 600; padding: 4px;">${idx + 1}</td>
          <td style="text-align: center; font-weight: 700; color: #047857; white-space: nowrap; padding: 4px;">${item.year || '2024 - 2025'}</td>
          <td style="text-align: center; font-weight: 700; color: #1e3a8a; white-space: nowrap; padding: 4px;">${item.grade || 'Grade 6'}</td>
          <td style="padding: 4px 6px;">
            <strong style="color: #0f172a;">${item.bookTitle}</strong>
            ${item.remarks ? `<br><small style="color: #64748b;">${item.remarks}</small>` : ''}
          </td>
          <td style="text-align: center; font-weight: 700; color: #0f766e; padding: 4px;">${item.receivedNew || 0}</td>
          <td style="text-align: center; font-weight: 700; color: #1d4ed8; padding: 4px;">${dNew}</td>
          <td style="text-align: center; font-weight: 700; color: #b45309; padding: 4px;">${item.collectedOld || 0}</td>
          <td style="text-align: center; font-weight: 700; color: #7c3aed; padding: 4px;">${dOld}</td>
          <td style="text-align: center; font-weight: 800; color: #1e40af; background: #eff6ff; padding: 4px;">${tDist}</td>
          <td style="text-align: center; font-weight: 700; color: #b45309; background: #fffbeb; padding: 4px;">${item.stockOld || 0}</td>
          <td style="text-align: center; font-weight: 700; color: #15803d; background: #f0fdf4; padding: 4px;">${item.stockNew || 0}</td>
          <td style="text-align: center; font-weight: 900; color: #065f46; background: #dcfce7; font-size: 11px; padding: 4px;">${item.balance || 0}</td>
        </tr>
      `;
    }).join('');

    const htmlContent = `
      <div style="font-family: Arial, sans-serif; color: #000; padding: 10px; width: 100%;">
        <!-- Header -->
        <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #000; padding-bottom: 8px; margin-bottom: 10px;">
          <div>
            <h1 style="font-size: 18px; margin: 0; font-weight: 900; letter-spacing: 0.5px; color: #065f46;">
              ${settings.schoolName || 'GOVT: HIGH SCHOOL ZANDO DHERI, MARDAN PAKISTAN'}
            </h1>
            <div style="font-size: 11px; color: #334155; margin-top: 2px;">
              ${settings.address || 'Zando Dheri, Mardan, Khyber Pakhtunkhwa, Pakistan'} &bull; Phone: ${settings.phone || '-'}
            </div>
          </div>
          <div style="text-align: right;">
            <div style="font-size: 13px; font-weight: 800; color: #0f172a; letter-spacing: 0.3px;">
              ${regTitle}
            </div>
            <div style="font-size: 11px; color: #065f46; font-weight: 700;">
              ${regUrdu}
            </div>
          </div>
        </div>

        <!-- Summary Metrics Strip -->
        <div style="display: flex; justify-content: space-between; background: #f8fafc; border: 1px solid #cbd5e1; border-radius: 6px; padding: 6px 14px; margin-bottom: 10px; font-size: 11px;">
          <div>Total Titles: <strong>${items.length}</strong> <span class="urdu-title">(کل کتابیں)</span></div>
          <div>New Books Received: <strong style="color: #0f766e;">${totRecNew.toLocaleString()}</strong> <span class="urdu-title">(نئی موصولہ)</span></div>
          <div>New Books Distributed: <strong style="color: #1d4ed8;">${totDistNew.toLocaleString()}</strong> <span class="urdu-title">(نئی تقسیم شدہ)</span></div>
          <div>Old Books Collected: <strong style="color: #b45309;">${totCollOld.toLocaleString()}</strong> <span class="urdu-title">(پرانی وصول شدہ)</span></div>
          <div>Old Books Distributed: <strong style="color: #7c3aed;">${totDistOld.toLocaleString()}</strong> <span class="urdu-title">(پرانی تقسیم شدہ)</span></div>
          <div>Total Distributed: <strong style="color: #1e40af;">${totTotalDist.toLocaleString()}</strong> <span class="urdu-title">(کل تقسیم شدہ)</span></div>
          <div>Current Stock: <strong>${totStockNew.toLocaleString()} New + ${totStockOld.toLocaleString()} Old</strong></div>
          <div>Total Balance: <strong style="color: #065f46; font-size: 12px;">${totBalance.toLocaleString()}</strong> <span class="urdu-title">(کل بقایا)</span></div>
        </div>

        <!-- Table -->
        <table style="width: 100%; border-collapse: collapse; font-size: 10px;">
          <thead>
            <tr style="background-color: #f1f5f9;">
              <th style="padding: 5px 3px; border: 1px solid #cbd5e1; text-align: center; width: 28px;">#</th>
              <th style="padding: 5px 4px; border: 1px solid #cbd5e1; text-align: center; width: 75px;">Year (سال)</th>
              <th style="padding: 5px 4px; border: 1px solid #cbd5e1; text-align: center; width: 70px;">Class (جماعت)</th>
              <th style="padding: 5px 6px; border: 1px solid #cbd5e1; text-align: left;">Book Title / Subject (نام درسی کتاب و مضمون)</th>
              <th style="padding: 5px 4px; border: 1px solid #cbd5e1; text-align: center; width: 75px;">Received (New) (نئی موصولہ)</th>
              <th style="padding: 5px 4px; border: 1px solid #cbd5e1; text-align: center; width: 75px;">Distributed (New) (نئی تقسیم)</th>
              <th style="padding: 5px 4px; border: 1px solid #cbd5e1; text-align: center; width: 75px;">Old Collected (پرانی وصول)</th>
              <th style="padding: 5px 4px; border: 1px solid #cbd5e1; text-align: center; width: 75px;">Old Distributed (پرانی تقسیم)</th>
              <th style="padding: 5px 4px; border: 1px solid #cbd5e1; text-align: center; width: 75px; background: #eff6ff; color: #1e40af;">Total Distributed (کل تقسیم شدہ)</th>
              <th style="padding: 5px 4px; border: 1px solid #cbd5e1; text-align: center; width: 68px;">Old in Stock (پرانی اسٹاک)</th>
              <th style="padding: 5px 4px; border: 1px solid #cbd5e1; text-align: center; width: 68px;">New in Stock (نئی اسٹاک)</th>
              <th style="padding: 5px 4px; border: 1px solid #cbd5e1; text-align: center; width: 68px;">Balance (کل بقایا)</th>
            </tr>
          </thead>
          <tbody>
            ${rowsHTML || `<tr><td colspan="12" style="text-align:center; padding:15px;">No Free Text Book records found for selected filters.</td></tr>`}
          </tbody>
          <tfoot>
            <tr style="background: #f8fafc; font-weight: 800; border-top: 2px solid #000;">
              <td colspan="4" style="text-align: right; padding: 6px 10px; font-size: 11px;">
                Grand Totals / کل میزان:
              </td>
              <td style="text-align: center; color: #0f766e; padding: 6px;">${totRecNew.toLocaleString()}</td>
              <td style="text-align: center; color: #1d4ed8; padding: 6px;">${totDistNew.toLocaleString()}</td>
              <td style="text-align: center; color: #b45309; padding: 6px;">${totCollOld.toLocaleString()}</td>
              <td style="text-align: center; color: #7c3aed; padding: 6px;">${totDistOld.toLocaleString()}</td>
              <td style="text-align: center; color: #1e40af; background: #dbeafe; font-weight: 900; padding: 6px;">${totTotalDist.toLocaleString()}</td>
              <td style="text-align: center; color: #b45309; background: #fef3c7; padding: 6px;">${totStockOld.toLocaleString()}</td>
              <td style="text-align: center; color: #15803d; background: #dcfce7; padding: 6px;">${totStockNew.toLocaleString()}</td>
              <td style="text-align: center; color: #065f46; background: #bbf7d0; font-size: 12px; font-weight: 900; padding: 6px;">${totBalance.toLocaleString()}</td>
            </tr>
          </tfoot>
        </table>

        <!-- Signatures Strip -->
        <div style="display: flex; justify-content: space-between; margin-top: 35px; padding-top: 10px;">
          <div style="text-align: center; width: 220px;">
            <div style="border-bottom: 1px solid #000; height: 30px; margin-bottom: 5px;"></div>
            <strong style="font-size: 11px;">In-Charge Free Text Books <span class="urdu-title">(انچارج مفت درسی کتب)</span></strong>
          </div>
          <div style="text-align: center; width: 220px;">
            <div style="border-bottom: 1px solid #000; height: 30px; margin-bottom: 5px;"></div>
            <strong style="font-size: 11px;">Class Teacher / In-Charge <span class="urdu-title">(کلاس انچارج / استاد)</span></strong>
          </div>
          <div style="text-align: center; width: 220px;">
            <div style="border-bottom: 1px solid #000; height: 30px; margin-bottom: 5px;"></div>
            <strong style="font-size: 11px;">Principal / Headmaster <span class="urdu-title">(پرنسپل / ہیڈ ماسٹر)</span></strong>
          </div>
        </div>

        <!-- Footer watermark -->
        <div style="margin-top: 15px; font-size: 9.5px; color: #64748b; display: flex; justify-content: space-between; align-items: center; border-top: 1px dotted #cbd5e1; padding-top: 4px;">
          <span>Govt: High School Zando Dheri, Mardan &bull; KP Textbook Board Peshawar Free Distribution Register</span>
          <span>Designed &amp; Developed by: <strong>Shaukat Zando</strong></span>
        </div>
      </div>
    `;

    this.printLandscapeElement(htmlContent);
  },

  // Export Admission & Withdrawal Register as CSV (Middle or High)
  exportAdmWithdrawalCSV(type = 'middle') {
    const isHigh = type === 'high';
    const filterGrade = document.getElementById(isHigh ? 'awh-filter-grade' : 'awm-filter-grade')?.value || '';
    const filterStatus = document.getElementById(isHigh ? 'awh-filter-status' : 'awm-filter-status')?.value || '';
    const searchQuery = document.getElementById(isHigh ? 'awh-search' : 'awm-search')?.value || '';
    const records = SchoolDB.getAdmWithdrawals(type, searchQuery, filterGrade, filterStatus);

    const columns = [
      { label: 'Record ID', key: 'id' },
      { label: 'Admission No (داخلہ نمبر)', key: 'admissionNo' },
      { label: 'Date of Admission (تاریخ داخلہ)', key: 'admissionDate' },
      { label: "Pupil's Full Name (نام بمعہ ولدیت)", key: 'studentName' },
      { label: "Father's Name (نام والد)", key: 'fatherName' },
      { label: 'Caste / Tribe (قوم یا قبیلہ)', key: 'caste' },
      { label: "Father's Occupation (پیشہ والد)", key: 'occupation' },
      { label: 'Permanent Residence / Address (سکونت / مستقل پتہ)', key: 'residence' },
      { label: 'Date of Birth in Figures (تاریخ پیدائش ہندسوں میں)', key: 'dob' },
      { label: 'Date of Birth in Words (تاریخ پیدائش الفاظ میں)', key: 'dobWords' },
      { label: 'Previous School Attended (سابقہ اسکول کا نام)', key: 'prevSchool' },
      { label: 'Class Admitted (کلاس داخلہ)', key: 'classAdmitted' },
      { label: 'Date of Withdrawal / Leaving (تاریخ اخراج)', key: 'withdrawalDate' },
      { label: 'Class Withdrawn From (جماعت اخراج)', key: 'classWithdrawn' },
      { label: 'Reason for Withdrawal (وجہ اخراج)', key: 'withdrawalReason' },
      { label: 'School Leaving Certificate (SLC) No (نمبر سرٹیفکیٹ)', key: 'slcNo' },
      { label: 'Conduct / Character (چال چلن)', key: 'conduct' },
      { label: 'Status (کیفیت)', key: 'status' },
      { label: 'Remarks / Notes (کیفیات)', key: 'remarks' }
    ];

    const csv = this.toCSV(records, columns);
    const typeLabel = isHigh ? 'High_Section' : 'Middle_Section';
    const gradeSuffix = filterGrade ? `_${filterGrade.replace(/\s+/g, '')}` : '';
    const filename = `Admission_Withdrawal_Register_${typeLabel}${gradeSuffix}_${new Date().toISOString().split('T')[0]}.csv`;
    this.downloadCSV(csv, filename);
  },

  // Download Sample CSV Template for Admission & Withdrawal Register
  downloadAdmWithdrawalCSVTemplate(type = 'middle') {
    const isHigh = type === 'high';
    const headers = [
      'Admission No',
      'Date of Admission',
      'Pupil Full Name',
      'Father Name',
      'Caste',
      'Occupation',
      'Residence',
      'Date of Birth',
      'Date of Birth in Words',
      'Previous School',
      'Class Admitted',
      'Date of Withdrawal',
      'Class Withdrawn',
      'Reason for Withdrawal',
      'SLC No',
      'Conduct',
      'Status',
      'Remarks'
    ];

    const sampleRows = isHigh ? [
      ['820', '2024-04-10', 'Muhammad Usman', 'Tariq Mehmood', 'Yousafzai', 'Govt Servant', 'Zando Dheri, Mardan', '2009-04-12', 'Twelfth April Two Thousand Nine', 'GMS Zando Dheri', 'Grade 9', '', '', '', '', 'Good', 'Active', 'Science Group Matric'],
      ['821', '2024-04-12', 'Hamza Khan', 'Sardar Khan', 'Mohmand', 'Business', 'Main Bazar, Zando Dheri', '2008-11-30', 'Thirtieth November Two Thousand Eight', 'GMS Chamtar', 'Grade 9', '2025-03-31', 'Grade 10', 'Passed SSC Board Exam', 'SLC-2025-089', 'Excellent', 'Struck Off', 'Cleared BISE Mardan'],
      ['822', '2023-04-05', 'Umar Farooq', 'Farooq Ahmad', 'Khattak', 'Farmer', 'Zando Dheri, Mardan', '2010-01-20', 'Twentieth January Two Thousand Ten', 'GPS Chamtar', 'Grade 9', '', '', '', '', 'Good', 'Active', 'Science Group']
    ] : [
      ['145', '2024-04-15', 'Muhammad Salman', 'Noor Muhammad', 'Yousafzai', 'Farmer', 'Zando Dheri, Mardan', '2012-05-10', 'Tenth May Two Thousand Twelve', 'GPS Zando Dheri No 1', 'Grade 6', '', '', '', '', 'Good', 'Active', 'Admitted in 6th'],
      ['146', '2024-04-16', 'Abdur Rehman', 'Fazal Subhan', 'Khattak', 'Shopkeeper', 'Zando Dheri, Mardan', '2011-08-14', 'Fourteenth August Two Thousand Eleven', 'GPS Chamtar', 'Grade 6', '', '', '', '', 'Good', 'Active', 'Admitted in 6th'],
      ['147', '2023-04-10', 'Ahmad Ali', 'Sher Ali', 'Mohmand', 'Driver', 'Near Canal, Zando Dheri', '2010-03-22', 'Twenty Second March Two Thousand Ten', 'GPS Zando Dheri No 2', 'Grade 6', '2025-03-25', 'Grade 8', 'Passed Middle Standard Examination', 'SLC-2025-042', 'Very Good', 'Struck Off', 'Promoted to High Section']
    ];

    const csvLines = [headers.join(',')];
    sampleRows.forEach(row => {
      const escaped = row.map(cell => `"${String(cell).replace(/"/g, '""')}"`);
      csvLines.push(escaped.join(','));
    });

    const csvContent = '\uFEFF' + csvLines.join('\r\n');
    const filename = isHigh ? 'Admission_Withdrawal_High_Template.csv' : 'Admission_Withdrawal_Middle_Template.csv';
    this.downloadCSV(csvContent, filename);
  },

  // Parse Uploaded Admission & Withdrawal CSV
  parseAdmWithdrawalCSV(csvText) {
    if (!csvText || !csvText.trim()) return [];

    const lines = [];
    let currentRow = [];
    let currentField = '';
    let insideQuotes = false;

    const cleanText = csvText.replace(/\r\n/g, '\n').replace(/\r/g, '\n');

    for (let i = 0; i < cleanText.length; i++) {
      const ch = cleanText[i];
      if (ch === '"') {
        if (insideQuotes && cleanText[i + 1] === '"') {
          currentField += '"';
          i++;
        } else {
          insideQuotes = !insideQuotes;
        }
      } else if (ch === ',' && !insideQuotes) {
        currentRow.push(currentField.trim());
        currentField = '';
      } else if (ch === '\n' && !insideQuotes) {
        currentRow.push(currentField.trim());
        if (currentRow.some(val => val.length > 0)) {
          lines.push(currentRow);
        }
        currentRow = [];
        currentField = '';
      } else {
        currentField += ch;
      }
    }
    if (currentField.length > 0 || currentRow.length > 0) {
      currentRow.push(currentField.trim());
      if (currentRow.some(val => val.length > 0)) {
        lines.push(currentRow);
      }
    }

    if (lines.length < 2) return [];

    const headerRow = lines[0];
    const headerMap = {};

    headerRow.forEach((hdr, idx) => {
      const h = String(hdr).toLowerCase().replace(/[^a-z0-9]/g, '');
      if (h.includes('admno') || h.includes('admissionno') || h.includes('dakhla') || (h.includes('admission') && h.includes('number'))) headerMap.admissionNo = idx;
      else if (h.includes('admissiondate') || h.includes('dateofadmission') || h.includes('tarikhadakhla')) headerMap.admissionDate = idx;
      else if (h.includes('pupil') || h.includes('student') || h.includes('talib') || h === 'name' || h.includes('fullname')) headerMap.studentName = idx;
      else if (h.includes('father') || h.includes('walid') || h.includes('guardian')) headerMap.fatherName = idx;
      else if (h.includes('caste') || h.includes('tribe') || h.includes('qaum') || h.includes('qabila')) headerMap.caste = idx;
      else if (h.includes('occupation') || h.includes('pesha') || h.includes('profession')) headerMap.occupation = idx;
      else if (h.includes('residence') || h.includes('address') || h.includes('sakunat') || h.includes('pata')) headerMap.residence = idx;
      else if (h.includes('dobwords') || (h.includes('birth') && h.includes('word'))) headerMap.dobWords = idx;
      else if (h.includes('dob') || h.includes('birth') || h.includes('paidaish')) headerMap.dob = idx;
      else if (h.includes('prevschool') || h.includes('previous') || h.includes('sabiqa')) headerMap.prevSchool = idx;
      else if (h.includes('classadmitted') || (h.includes('class') && h.includes('admit')) || (h.includes('jamaat') && h.includes('dakhla'))) headerMap.classAdmitted = idx;
      else if (h.includes('withdrawaldate') || (h.includes('date') && h.includes('withdr')) || h.includes('tarikhikhraj')) headerMap.withdrawalDate = idx;
      else if (h.includes('classwithdrawn') || (h.includes('class') && h.includes('withdr')) || (h.includes('jamaat') && h.includes('ikhraj'))) headerMap.classWithdrawn = idx;
      else if (h.includes('reason') || h.includes('wajah') || h.includes('cause')) headerMap.withdrawalReason = idx;
      else if (h.includes('slc') || h.includes('certificate') || h.includes('sanad')) headerMap.slcNo = idx;
      else if (h.includes('conduct') || h.includes('chal') || h.includes('character')) headerMap.conduct = idx;
      else if (h.includes('status') || h.includes('kaifiyat') || h.includes('active')) headerMap.status = idx;
      else if (h.includes('remark') || h.includes('note')) headerMap.remarks = idx;
    });

    if (headerMap.studentName === undefined) {
      if (headerRow.length >= 3) headerMap.studentName = 2;
      else headerMap.studentName = 0;
    }

    const records = [];
    for (let r = 1; r < lines.length; r++) {
      const data = lines[r];
      if (!data || !data.length) continue;

      const getVal = (field) => {
        const idx = headerMap[field];
        return (idx !== undefined && data[idx] !== undefined) ? String(data[idx]).trim() : '';
      };

      const studentName = getVal('studentName');
      if (!studentName) continue;

      const admNo = getVal('admissionNo') || String(r);
      const admDate = getVal('admissionDate') || new Date().toISOString().split('T')[0];
      const dob = getVal('dob');
      const wDate = getVal('withdrawalDate');
      let status = getVal('status');
      if (!status) {
        status = wDate ? 'Struck Off' : 'Active';
      }

      records.push({
        admissionNo: admNo,
        admissionDate: admDate,
        studentName: studentName,
        fatherName: getVal('fatherName'),
        caste: getVal('caste'),
        occupation: getVal('occupation'),
        residence: getVal('residence'),
        dob: dob,
        dobWords: getVal('dobWords'),
        prevSchool: getVal('prevSchool'),
        classAdmitted: getVal('classAdmitted'),
        withdrawalDate: wDate,
        classWithdrawn: getVal('classWithdrawn'),
        withdrawalReason: getVal('withdrawalReason'),
        slcNo: getVal('slcNo'),
        conduct: getVal('conduct') || 'Good',
        status: status,
        remarks: getVal('remarks')
      });
    }

    return records;
  },

  // Print Official Register Dakhla Kharij (Middle or High) in Landscape
  printAdmWithdrawalRegister(type = 'middle') {
    const isHigh = type === 'high';
    const filterGrade = document.getElementById(isHigh ? 'awh-filter-grade' : 'awm-filter-grade')?.value || '';
    const filterStatus = document.getElementById(isHigh ? 'awh-filter-status' : 'awm-filter-status')?.value || '';
    const searchQuery = document.getElementById(isHigh ? 'awh-search' : 'awm-search')?.value || '';
    const records = SchoolDB.getAdmWithdrawals(type, searchQuery, filterGrade, filterStatus);
    const settings = SchoolDB.data.settings;

    let activeCount = 0;
    let struckCount = 0;
    records.forEach(r => {
      if ((r.status || '').toLowerCase() === 'active') activeCount++;
      else struckCount++;
    });

    const regTitle = isHigh
      ? `OFFICIAL REGISTER DAKHLA KHARIJ (HIGH SECTION - CLASSES 9TH & 10TH)`
      : `OFFICIAL REGISTER DAKHLA KHARIJ (MIDDLE SECTION - CLASSES 6TH, 7TH & 8TH)`;
    const regUrdu = isHigh
      ? `(رجسٹر داخلہ خارج - ہائی سیکشن، جماعت نہم و دہم - میٹرک)`
      : `(رجسٹر داخلہ خارج - مڈل سیکشن، جماعت ششم تا ہشتم)`;

    const rowsHTML = records.map((item, idx) => {
      const isStruck = (item.status || '').toLowerCase().includes('struck');
      const statusBadge = isStruck
        ? `<span style="background:#fef3c7; color:#b45309; padding:2px 6px; border-radius:4px; font-weight:700; font-size:9.5px; border:1px solid #fde68a;">Struck Off / خارج</span>`
        : `<span style="background:#dcfce7; color:#15803d; padding:2px 6px; border-radius:4px; font-weight:700; font-size:9.5px; border:1px solid #bbf7d0;">On Roll / حاضر</span>`;

      return `
        <tr>
          <td style="text-align: center; font-weight: 600; padding: 4px 2px;">${idx + 1}</td>
          <td style="text-align: center; font-weight: 800; color: ${isHigh ? '#1d4ed8' : '#047857'}; font-size: 10.5px; white-space: nowrap; padding: 4px 2px;">${item.admissionNo || '-'}</td>
          <td style="text-align: center; white-space: nowrap; font-size: 9px; padding: 4px 2px;">${item.admissionDate || '-'}</td>
          <td style="padding: 4px 5px;">
            <strong style="color: #0f172a; font-size: 10.5px;">${item.studentName}</strong>
          </td>
          <td style="padding: 4px 5px; font-size: 10px;">
            <strong style="color: #1e293b;">${item.fatherName || '-'}</strong>
          </td>
          <td style="padding: 4px 4px; font-size: 9.5px; color: #334155;">
            ${item.caste || '-'}
          </td>
          <td style="padding: 4px 4px; font-size: 9.5px; color: #334155;">
            ${item.occupation || '-'}
          </td>
          <td style="padding: 4px 5px; font-size: 9px; color: #475569;">
            ${item.residence || '-'}
          </td>
          <td style="padding: 4px 5px; font-size: 9px;">
            <strong>${item.dob || '-'}</strong>
            ${item.dobWords ? `<br><em style="color:#475569; font-size:8px;">${item.dobWords}</em>` : ''}
          </td>
          <td style="padding: 4px 4px; font-size: 9px; color: #334155;">${item.prevSchool || '-'}</td>
          <td style="text-align: center; font-weight: 700; color: #1e3a8a; padding: 4px 2px; font-size: 9.5px;">${item.classAdmitted || '-'}</td>
          <td style="text-align: center; padding: 4px 2px; font-size: 9px;">
            ${item.withdrawalDate ? `<strong>${item.withdrawalDate}</strong>` : '<span style="color:#94a3b8;">-</span>'}
            ${item.classWithdrawn ? `<br><small style="color:#64748b;">(${item.classWithdrawn})</small>` : ''}
          </td>
          <td style="padding: 4px 5px; font-size: 9px;">
            ${item.withdrawalReason ? `<div>${item.withdrawalReason}</div>` : ''}
            ${item.slcNo ? `<strong style="color:#b45309; font-size:8.5px;">SLC: ${item.slcNo}</strong>` : ''}
            ${!item.withdrawalReason && !item.slcNo ? '<span style="color:#94a3b8;">-</span>' : ''}
          </td>
          <td style="text-align: center; padding: 4px 2px; font-size: 9px;">${item.conduct || 'Good'}</td>
          <td style="text-align: center; padding: 4px 2px;">${statusBadge}</td>
        </tr>
      `;
    }).join('');

    const htmlContent = `
      <div style="font-family: Arial, sans-serif; color: #000; padding: 8px; width: 100%;">
        <!-- Header -->
        <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #000; padding-bottom: 8px; margin-bottom: 10px;">
          <div>
            <h1 style="font-size: 18px; margin: 0; font-weight: 900; letter-spacing: 0.5px; color: ${isHigh ? '#1d4ed8' : '#047857'};">
              ${settings.schoolName || 'GOVT: HIGH SCHOOL ZANDO DHERI, MARDAN PAKISTAN'}
            </h1>
            <div style="font-size: 11px; color: #334155; margin-top: 2px;">
              ${settings.address || 'Zando Dheri, Mardan, Khyber Pakhtunkhwa, Pakistan'} &bull; Phone: ${settings.phone || '-'} &bull; Session: ${settings.academicYear || '2025-2026'}
            </div>
          </div>
          <div style="text-align: right;">
            <div style="font-size: 13px; font-weight: 800; color: #0f172a; letter-spacing: 0.3px;">
              ${regTitle}
            </div>
            <div style="font-size: 11px; color: ${isHigh ? '#1d4ed8' : '#047857'}; font-weight: 700;">
              ${regUrdu}
            </div>
          </div>
        </div>

        <!-- Summary Metrics Strip -->
        <div style="display: flex; justify-content: space-between; background: #f8fafc; border: 1px solid #cbd5e1; border-radius: 6px; padding: 6px 14px; margin-bottom: 10px; font-size: 11px;">
          <div>Total Registered Pupils: <strong>${records.length}</strong> <span class="urdu-title">(کل مندرجات داخلہ خارج)</span></div>
          <div>Active Enrolled On Roll: <strong style="color: #15803d;">${activeCount}</strong> <span class="urdu-title">(برسرِ حاضر طلباء)</span></div>
          <div>Struck Off / SLC Issued: <strong style="color: #b45309;">${struckCount}</strong> <span class="urdu-title">(خارج شدہ طلباء)</span></div>
          <div>Register Section: <strong>${isHigh ? 'High Section (9th - 10th)' : 'Middle Section (6th - 8th)'}</strong></div>
          <div>Date Generated: <strong>${new Date().toLocaleDateString('en-GB')}</strong></div>
        </div>

        <!-- Official Register Table -->
        <table style="width: 100%; border-collapse: collapse; font-size: 9px;">
          <thead>
            <tr style="background-color: #f1f5f9;">
              <th style="padding: 5px 3px; border: 1px solid #cbd5e1; text-align: center; width: 24px;">#</th>
              <th style="padding: 5px 3px; border: 1px solid #cbd5e1; text-align: center; width: 50px;">Adm No<br><span style="font-size:8px;">داخلہ نمبر</span></th>
              <th style="padding: 5px 3px; border: 1px solid #cbd5e1; text-align: center; width: 60px;">Adm Date<br><span style="font-size:8px;">تاریخ داخلہ</span></th>
              <th style="padding: 5px 5px; border: 1px solid #cbd5e1; text-align: left; min-width: 95px;">Pupil's Full Name<br><span style="font-size:8px;">نام طالب علم</span></th>
              <th style="padding: 5px 5px; border: 1px solid #cbd5e1; text-align: left; min-width: 90px;">Father's Name<br><span style="font-size:8px;">نام والد</span></th>
              <th style="padding: 5px 4px; border: 1px solid #cbd5e1; text-align: left; width: 60px;">Caste<br><span style="font-size:8px;">قومیت</span></th>
              <th style="padding: 5px 4px; border: 1px solid #cbd5e1; text-align: left; width: 65px;">Occupation<br><span style="font-size:8px;">پیشہ والد</span></th>
              <th style="padding: 5px 5px; border: 1px solid #cbd5e1; text-align: left; min-width: 100px;">Residence / Address<br><span style="font-size:8px;">سکونت / پتہ</span></th>
              <th style="padding: 5px 5px; border: 1px solid #cbd5e1; text-align: left; width: 120px;">Date of Birth<br><span style="font-size:8px;">تاریخ پیدائش ہندسوں و الفاظ</span></th>
              <th style="padding: 5px 4px; border: 1px solid #cbd5e1; text-align: left; width: 85px;">Previous School<br><span style="font-size:8px;">سابقہ اسکول</span></th>
              <th style="padding: 5px 3px; border: 1px solid #cbd5e1; text-align: center; width: 55px;">Admitted<br><span style="font-size:8px;">کلاس داخلہ</span></th>
              <th style="padding: 5px 3px; border: 1px solid #cbd5e1; text-align: center; width: 68px;">Withdrawn<br><span style="font-size:8px;">تاریخ و جماعت اخراج</span></th>
              <th style="padding: 5px 5px; border: 1px solid #cbd5e1; text-align: left; width: 95px;">Reason &amp; SLC #<br><span style="font-size:8px;">وجہ اخراج و سرٹیفکیٹ</span></th>
              <th style="padding: 5px 3px; border: 1px solid #cbd5e1; text-align: center; width: 48px;">Conduct<br><span style="font-size:8px;">چال چلن</span></th>
              <th style="padding: 5px 3px; border: 1px solid #cbd5e1; text-align: center; width: 65px;">Status<br><span style="font-size:8px;">کیفیت</span></th>
            </tr>
          </thead>
          <tbody>
            ${rowsHTML || `<tr><td colspan="15" style="text-align:center; padding:15px;">No Admission & Withdrawal Register entries found for selected criteria.</td></tr>`}
          </tbody>
        </table>

        <!-- Signatures Strip -->
        <div style="display: flex; justify-content: space-between; margin-top: 35px; padding-top: 10px;">
          <div style="text-align: center; width: 220px;">
            <div style="border-bottom: 1px solid #000; height: 30px; margin-bottom: 5px;"></div>
            <strong style="font-size: 11px;">Incharge Dakhla Kharij <span class="urdu-title">(انچارج داخلہ خارج)</span></strong>
          </div>
          <div style="text-align: center; width: 220px;">
            <div style="border-bottom: 1px solid #000; height: 30px; margin-bottom: 5px;"></div>
            <strong style="font-size: 11px;">Verification Committee Member <span class="urdu-title">(ممبر تصدیقی کمیٹی)</span></strong>
          </div>
          <div style="text-align: center; width: 220px;">
            <div style="border-bottom: 1px solid #000; height: 30px; margin-bottom: 5px;"></div>
            <strong style="font-size: 11px;">Principal / Headmaster <span class="urdu-title">(پرنسپل / ہیڈ ماسٹر)</span></strong>
          </div>
        </div>

        <!-- Footer watermark -->
        <div style="margin-top: 15px; font-size: 9.5px; color: #64748b; display: flex; justify-content: space-between; align-items: center; border-top: 1px dotted #cbd5e1; padding-top: 4px;">
          <span>Govt: High School Zando Dheri, Mardan &bull; Official Government School Register Dakhla Kharij</span>
          <span>Designed &amp; Developed by: <strong>Shaukat Zando</strong></span>
        </div>
      </div>
    `;

    this.printLandscapeElement(htmlContent);
  },

  // Print all student profiles in one comprehensive landscape page / PDF format
  printStudentProfilesLandscape() {
    const students = SchoolDB.getStudents();
    const settings = SchoolDB.data.settings;

    if (!students.length) {
      alert('No student records found to generate landscape profile report.');
      return;
    }

    const tableRows = students.map((s, idx) => {
      let catBadge = s.specialCategory && s.specialCategory !== 'None' ? s.specialCategory : 'Normal';
      return `
        <tr>
          <td style="text-align: center; font-weight: 600;">${idx + 1}</td>
          <td style="font-weight: 700; color: #1e3a8a;">${s.id || '-'}</td>
          <td>${s.admissionDate || '-'}</td>
          <td style="font-weight: 600;">${s.name}</td>
          <td>${s.guardian || '-'}</td>
          <td>${s.dob || '-'}</td>
          <td>${s.grade || '-'}</td>
          <td style="text-align: center; font-weight: 600;">${s.section || '-'}</td>
          <td style="text-align: center;">${s.rollNo || '-'}</td>
          <td>${s.phone || '-'}</td>
          <td><span style="font-weight: 600; ${s.specialCategory && s.specialCategory !== 'None' ? 'color: #b45309;' : 'color: #334155;'}">${catBadge}</span></td>
          <td style="text-align: center;">${s.gender || 'Male'}</td>
          <td style="font-size: 11px;">${s.address || '-'}</td>
          <td style="text-align: center;"><span style="display: inline-block; padding: 2px 6px; border-radius: 4px; font-size: 10px; font-weight: 700; ${s.status === 'Active' ? 'background: #dcfce7; color: #15803d;' : 'background: #f1f5f9; color: #64748b;'}">${s.status || 'Active'}</span></td>
        </tr>
      `;
    }).join('');

    const htmlContent = `
      <div class="landscape-profiles-document">
        <div class="landscape-header" style="display: flex; align-items: center; justify-content: space-between; border-bottom: 2px solid #1e3a8a; padding-bottom: 12px; margin-bottom: 14px;">
          <div style="display: flex; align-items: center; gap: 14px;">
            <img src="images/monogram school.jpg" alt="School Monogram" style="width: 65px; height: 65px; object-fit: contain; border-radius: 50%; border: 1.5px solid #1e3a8a;">
            <div>
              <h1 style="font-size: 20px; font-weight: 800; color: #1e3a8a; margin: 0; text-transform: uppercase;">${settings.schoolName}</h1>
              <p style="font-size: 12px; color: #475569; margin: 2px 0 0 0;">${settings.tagline} &bull; ${settings.address}</p>
              <div style="font-size: 11px; color: #64748b; margin-top: 2px;">Phone: ${settings.phone} &bull; Academic Session: <strong>${settings.academicYear}</strong></div>
            </div>
          </div>
          <div style="text-align: right;">
            <div style="background: #1e3a8a; color: #ffffff; padding: 6px 14px; border-radius: 6px; font-weight: 700; font-size: 13px; letter-spacing: 0.5px;">
              MASTER STUDENT DIRECTORY &amp; PROFILES
            </div>
            <div style="font-size: 11px; color: #475569; margin-top: 5px;">
              Date Generated: <strong>${new Date().toLocaleDateString('en-GB')}</strong> &bull; Total Enrolled: <strong>${students.length}</strong>
            </div>
          </div>
        </div>

        <table style="width: 100%; border-collapse: collapse; font-size: 11px; font-family: inherit;">
          <thead>
            <tr style="background-color: #f1f5f9; border-top: 1.5px solid #0f172a; border-bottom: 1.5px solid #0f172a;">
              <th style="padding: 7px 5px; border: 1px solid #cbd5e1; text-align: center;">#</th>
              <th style="padding: 7px 5px; border: 1px solid #cbd5e1;">Admission No</th>
              <th style="padding: 7px 5px; border: 1px solid #cbd5e1;">Admission Date</th>
              <th style="padding: 7px 5px; border: 1px solid #cbd5e1;">Full Name</th>
              <th style="padding: 7px 5px; border: 1px solid #cbd5e1;">Father Name</th>
              <th style="padding: 7px 5px; border: 1px solid #cbd5e1;">D.O.B</th>
              <th style="padding: 7px 5px; border: 1px solid #cbd5e1;">Grade</th>
              <th style="padding: 7px 5px; border: 1px solid #cbd5e1; text-align: center;">Section</th>
              <th style="padding: 7px 5px; border: 1px solid #cbd5e1; text-align: center;">Roll No</th>
              <th style="padding: 7px 5px; border: 1px solid #cbd5e1;">Emergency No</th>
              <th style="padding: 7px 5px; border: 1px solid #cbd5e1;">Orphan / Disable</th>
              <th style="padding: 7px 5px; border: 1px solid #cbd5e1; text-align: center;">Gender</th>
              <th style="padding: 7px 5px; border: 1px solid #cbd5e1;">Address</th>
              <th style="padding: 7px 5px; border: 1px solid #cbd5e1; text-align: center;">Status</th>
            </tr>
          </thead>
          <tbody>
            ${tableRows}
          </tbody>
        </table>

        <div style="margin-top: 24px; display: flex; justify-content: space-between; align-items: flex-end; font-size: 12px; padding-top: 14px; border-top: 1.5px solid #cbd5e1;">
          <div style="text-align: center; width: 220px;">
            <div style="border-bottom: 1px solid #000; height: 35px; margin-bottom: 6px;"></div>
            <span>Prepared By / Clerk</span>
          </div>
          <div style="text-align: center; width: 220px;">
            <div style="border-bottom: 1px solid #000; height: 35px; margin-bottom: 6px;"></div>
            <span>Checked By / Incharge Admission</span>
          </div>
          <div style="text-align: center; width: 220px;">
            <div style="border-bottom: 1px solid #000; height: 35px; margin-bottom: 6px;"></div>
            <strong style="font-size: 13px;">Principal / Headmaster</strong>
          </div>
        </div>

        <div style="margin-top: 14px; font-size: 10px; color: #64748b; display: flex; justify-content: space-between; align-items: center; border-top: 1px dotted #cbd5e1; padding-top: 6px;">
          <span>Govt: High School Zando Dheri, Mardan &bull; Official Computer-Generated Document</span>
          <span>Designed &amp; Developed by: <strong>Shaukat Zando</strong></span>
        </div>
      </div>
    `;

    this.printLandscapeElement(htmlContent);
  },

  // Print Official One-Page Landscape Class Gazette & Tabulation Register
  printClassGazetteLandscape(classId, term) {
    if (!classId) {
      classId = document.getElementById('exams-filter-class')?.value;
    }
    const classes = SchoolDB.getClasses();
    const allStudents = SchoolDB.getStudents();

    let currentClass = null;
    if (classId) {
      currentClass = classes.find(c => c.id === classId || c.name === classId || `${c.name} (${c.section})` === classId);
    }

    // If no specific class filter is selected ("All Classes"), pick the first class that actually has enrolled students or exam marks
    if (!currentClass) {
      // First look for classes with students
      currentClass = classes.find(c => allStudents.some(s => s.grade === c.name && s.section === c.section));
      if (!currentClass) {
        currentClass = classes[0];
      }
      if (!currentClass) {
        alert('No classes found in database.');
        return;
      }
    }

    if (!term) {
      term = document.getElementById('exams-filter-term')?.value || 'Combined (1st & 2nd Semester)';
    }

    const settings = SchoolDB.data.settings;
    const students = allStudents.filter(s => s.grade === currentClass.name && s.section === currentClass.section);

    if (!students.length) {
      alert(`No student records found enrolled in ${currentClass.name} - Section ${currentClass.section}.\n\nPlease select a class from the dropdown filter (e.g. Grade 10) that has enrolled students, or enroll students in ${currentClass.name} first.`);
      return;
    }

    // Sort students by Roll Number
    students.sort((a, b) => (parseInt(a.rollNo) || 0) - (parseInt(b.rollNo) || 0));

    // Calculate marks and positions for each student
    const classResults = students.map((s) => {
      const sem1 = SchoolDB.getStudentMarkByTerm(s.id, '1st Semester');
      const sem2 = SchoolDB.getStudentMarkByTerm(s.id, '2nd Semester');
      const comb = SchoolDB.computeCombinedMarkRecord(s, sem1, sem2);

      let targetRecord;
      if (term === '1st Semester') targetRecord = sem1;
      else if (term === '2nd Semester') targetRecord = sem2;
      else targetRecord = comb;

      return {
        student: s,
        sem1,
        sem2,
        comb,
        targetRecord,
        obtained: targetRecord ? targetRecord.totalObtained : 0,
        maxMarks: targetRecord ? targetRecord.maxMarks : 0,
        percentage: targetRecord ? targetRecord.percentage : 0,
        grade: targetRecord ? targetRecord.grade : '-',
        gpa: targetRecord ? targetRecord.gpa : 0
      };
    });

    // Positions ranking among students with non-zero marks
    const scoredStudents = [...classResults].filter(r => r.obtained > 0).sort((a, b) => b.obtained - a.obtained);
    const positionMap = {};
    scoredStudents.forEach((st, idx) => {
      let pBadge = `${idx + 1}th`;
      if (idx === 0) pBadge = '🥇 1st (اول)';
      else if (idx === 1) pBadge = '🥈 2nd (دوم)';
      else if (idx === 2) pBadge = '🥉 3rd (سوم)';
      positionMap[st.student.id] = pBadge;
    });

    const isCombined = term === 'Combined (1st & 2nd Semester)';

    // Determine Curriculum Subjects for this class/section
    const gradeName = (currentClass.name || '').toLowerCase();
    const sectionName = (currentClass.section || '').toUpperCase().trim();
    let classCurriculumGroup = 'all';
    if (gradeName.includes('6') || gradeName.includes('7') || gradeName.includes('8')) {
      classCurriculumGroup = 'middle';
    } else if (gradeName.includes('9') || gradeName.includes('10')) {
      if (sectionName === 'A') classCurriculumGroup = 'science';
      else if (sectionName === 'B' || sectionName === 'C') classCurriculumGroup = 'arts';
    }

    let allSubjects = SchoolDB.getSubjects();
    let classSubjects = [];
    if (classCurriculumGroup === 'middle') {
      classSubjects = allSubjects.filter(s => s.code.startsWith('MID-'));
    } else if (classCurriculumGroup === 'science') {
      classSubjects = allSubjects.filter(s => s.code.startsWith('SCI-'));
    } else if (classCurriculumGroup === 'arts') {
      classSubjects = allSubjects.filter(s => s.code.startsWith('ART-'));
    }

    // Fallback: If no curriculum prefix matched, collect distinct subjects from student marks or all subjects
    if (!classSubjects.length) {
      const subjectCodeSet = new Set();
      classResults.forEach(r => {
        if (r.targetRecord && r.targetRecord.scores) {
          Object.keys(r.targetRecord.scores).forEach(code => subjectCodeSet.add(code));
        }
      });
      if (subjectCodeSet.size > 0) {
        classSubjects = allSubjects.filter(s => subjectCodeSet.has(s.code));
      } else {
        classSubjects = allSubjects.slice(0, 9);
      }
    }

    let passedCount = 0;
    let failedCount = 0;
    let totalObtSum = 0;
    let validStudentCount = 0;
    let totalClassObtainedSum = 0;

    const classTotalMarks = classSubjects.reduce((acc, sub) => acc + (Number(sub.totalMarks) || 100), 0);

    const tableRows = classResults.map((res, idx) => {
      const s = res.student;
      const t = res.targetRecord;
      const pos = positionMap[s.id] || '-';
      const isPass = res.percentage >= 50;
      if (t && res.obtained > 0) {
        validStudentCount++;
        totalObtSum += res.percentage;
        totalClassObtainedSum += res.obtained;
        if (isPass) passedCount++;
        else failedCount++;
      }

      let dataColumns = '';
      if (isCombined) {
        dataColumns = `
          <td style="text-align: center; font-weight: 600; color: #166534; background: #f0fdf4;">${res.sem1 ? res.sem1.maxMarks : (classTotalMarks || '-')}</td>
          <td style="text-align: center; font-weight: 600; color: #1e3a8a; background: #eff6ff;">${res.sem1 ? res.sem1.totalObtained : '-'}</td>
          <td style="text-align: center;">${res.sem1 ? res.sem1.percentage + '%' : '-'}</td>
          <td style="text-align: center; font-weight: 600; color: #166534; background: #f0fdf4;">${res.sem2 ? res.sem2.maxMarks : (classTotalMarks || '-')}</td>
          <td style="text-align: center; font-weight: 600; color: #1e3a8a; background: #eff6ff;">${res.sem2 ? res.sem2.totalObtained : '-'}</td>
          <td style="text-align: center;">${res.sem2 ? res.sem2.percentage + '%' : '-'}</td>
          <td style="text-align: center; font-weight: 800; color: #14532d; background: #dcfce7;">${res.maxMarks || (classTotalMarks * 2)}</td>
          <td style="text-align: center; font-weight: 800; color: #1e3a8a; background: #eff6ff;">${res.obtained}</td>
          <td style="text-align: center; font-weight: 700;">${res.percentage}%</td>
          <td style="text-align: center;"><span class="grade-pill grade-${(res.grade || 'F').replace('+', 'plus')}">${res.grade}</span></td>
          <td style="text-align: center; font-weight: 600;">${Number(res.gpa).toFixed(1)}</td>
          <td style="text-align: center; font-weight: 700; color: #047857;">${pos}</td>
          <td style="text-align: center;">
            <span style="font-weight: 700; font-size: 10px; padding: 2px 6px; border-radius: 4px; ${isPass ? 'background: #dcfce7; color: #15803d;' : 'background: #fee2e2; color: #b91c1c;'}">
              ${isPass ? 'PROMOTED (ترقی)' : 'FAILED (ناکام)'}
            </span>
          </td>
        `;
      } else {
        // Individual subject scores
        const subjectCells = classSubjects.map(subj => {
          const val = t && t.scores ? t.scores[subj.code] : undefined;
          const scoreDisplay = (val !== undefined && val !== null && val !== '') ? val : '-';
          const maxMarksForSub = Number(subj.totalMarks) || 100;
          const isSubFail = (val !== undefined && val !== null && val !== '') && Number(val) < (maxMarksForSub >= 50 ? (maxMarksForSub * 0.4) : 20);
          return `<td style="text-align: center; font-weight: 600; padding: 4px 3px; font-size: 10px; ${isSubFail ? 'color: #b91c1c; background: #fff1f2;' : ''}">${scoreDisplay}</td>`;
        }).join('');

        dataColumns = `
          ${subjectCells}
          <td style="text-align: center; font-weight: 800; color: #166534; background: #f0fdf4; font-size: 10.5px;">${res.maxMarks || classTotalMarks}</td>
          <td style="text-align: center; font-weight: 800; color: #1e3a8a; background: #eff6ff; font-size: 10.5px;">${res.obtained}</td>
          <td style="text-align: center; font-weight: 700;">${res.percentage}%</td>
          <td style="text-align: center;"><span class="grade-pill grade-${(res.grade || 'F').replace('+', 'plus')}">${res.grade}</span></td>
          <td style="text-align: center; font-weight: 600;">${Number(res.gpa).toFixed(1)}</td>
          <td style="text-align: center; font-weight: 700; color: #047857;">${pos}</td>
          <td style="text-align: center;">
            <span style="font-weight: 700; font-size: 10px; padding: 2px 6px; border-radius: 4px; ${isPass ? 'background: #dcfce7; color: #15803d;' : 'background: #fee2e2; color: #b91c1c;'}">
              ${isPass ? 'PASSED (کامیاب)' : 'FAILED (ناکام)'}
            </span>
          </td>
        `;
      }

      return `
        <tr>
          <td style="text-align: center; font-weight: 600;">${idx + 1}</td>
          <td style="text-align: center; font-weight: 700;">${s.rollNo || '-'}</td>
          <td style="font-weight: 700; color: #1e3a8a;">${s.id || '-'}</td>
          <td style="font-weight: 700; white-space: nowrap;">${s.name}</td>
          <td style="white-space: nowrap;">${s.guardian || '-'}</td>
          ${dataColumns}
        </tr>
      `;
    }).join('');

    const classAveragePct = validStudentCount > 0 ? Math.round(totalObtSum / validStudentCount) : 0;
    const passPercentage = validStudentCount > 0 ? Math.round((passedCount / validStudentCount) * 100) : 0;

    const top1 = scoredStudents[0];
    const top2 = scoredStudents[1];
    const top3 = scoredStudents[2];

    const htmlContent = `
      <div class="landscape-gazette-document">
        <div class="landscape-header" style="display: flex; align-items: center; justify-content: space-between; border-bottom: 2.5px solid #1e3a8a; padding-bottom: 10px; margin-bottom: 12px;">
          <div style="display: flex; align-items: center; gap: 14px;">
            <img src="images/monogram school.jpg" alt="School Monogram" style="width: 65px; height: 65px; object-fit: contain; border-radius: 50%; border: 1.5px solid #1e3a8a;">
            <div>
              <h1 style="font-size: 19px; font-weight: 800; color: #1e3a8a; margin: 0; text-transform: uppercase;">${settings.schoolName}</h1>
              <p style="font-size: 11.5px; color: #475569; margin: 2px 0 0 0;">${settings.tagline} &bull; ${settings.address}</p>
              <div style="font-size: 11px; color: #64748b; margin-top: 2px;">Phone: ${settings.phone} &bull; Academic Session: <strong>${settings.academicYear}</strong></div>
            </div>
          </div>
          <div style="text-align: right;">
            <div style="background: #1e3a8a; color: #ffffff; padding: 6px 14px; border-radius: 6px; font-weight: 800; font-size: 13px; letter-spacing: 0.5px;">
              CLASS TABULATION REGISTER &amp; RESULT GAZETTE
            </div>
            <div style="font-size: 11.5px; color: #0f172a; margin-top: 5px; font-weight: 700;">
              Class: <span style="color: #1e3a8a;">${currentClass.name} - Section ${currentClass.section}</span> &bull; Term: <span style="color: #b45309;">${term}</span>
            </div>
            <div style="font-size: 10.5px; color: #64748b; margin-top: 2px;">
              Date Generated: <strong>${new Date().toLocaleDateString('en-GB')}</strong> &bull; Total Enrolled: <strong>${students.length}</strong>
            </div>
          </div>
        </div>

        <!-- Performance KPI Bar -->
        <div style="background: #f8fafc; border: 1px solid #cbd5e1; border-radius: 6px; padding: 8px 14px; margin-bottom: 12px; display: flex; justify-content: space-between; align-items: center; font-size: 11px;">
          <div>Subjects: <strong>${classSubjects.length}</strong></div>
          <div>Total Marks of All Subjects: <strong style="color: #166534; font-size: 12.5px; background: #dcfce7; padding: 2px 8px; border-radius: 4px; border: 1px solid #bbf7d0;">${isCombined ? (classTotalMarks * 2) : classTotalMarks}</strong> <span class="urdu-title">(کل نمبر تمام مضامین)</span></div>
          <div>Appeared: <strong>${validStudentCount}</strong> / ${students.length}</div>
          <div>Passed: <strong style="color: #15803d;">${passedCount}</strong></div>
          <div>Failed: <strong style="color: #b91c1c;">${failedCount}</strong></div>
          <div>Pass Rate: <strong style="color: #1e3a8a; font-size: 12px;">${passPercentage}%</strong></div>
          <div>Class Average: <strong>${classAveragePct}%</strong></div>
        </div>

        <table style="width: 100%; border-collapse: collapse; font-size: 10px; font-family: inherit;">
          <thead>
            <tr style="background-color: #f1f5f9; border-top: 1.5px solid #0f172a; border-bottom: 1.5px solid #0f172a;">
              <th style="padding: 5px 3px; border: 1px solid #cbd5e1; text-align: center; width: 28px;">#</th>
              <th style="padding: 5px 3px; border: 1px solid #cbd5e1; text-align: center; width: 50px;">Roll No</th>
              <th style="padding: 5px 3px; border: 1px solid #cbd5e1; width: 75px;">Adm No</th>
              <th style="padding: 5px 4px; border: 1px solid #cbd5e1;">Student Name</th>
              <th style="padding: 5px 4px; border: 1px solid #cbd5e1;">Father Name</th>
              ${isCombined ? `
                <th style="padding: 5px 3px; border: 1px solid #cbd5e1; text-align: center; background: #f0fdf4; color: #166534;">1st Sem<br>Total Marks</th>
                <th style="padding: 5px 3px; border: 1px solid #cbd5e1; text-align: center; background: #eff6ff; color: #1e40af;">1st Sem<br>Obtained</th>
                <th style="padding: 5px 3px; border: 1px solid #cbd5e1; text-align: center;">1st %</th>
                <th style="padding: 5px 3px; border: 1px solid #cbd5e1; text-align: center; background: #f0fdf4; color: #166534;">2nd Sem<br>Total Marks</th>
                <th style="padding: 5px 3px; border: 1px solid #cbd5e1; text-align: center; background: #eff6ff; color: #1e40af;">2nd Sem<br>Obtained</th>
                <th style="padding: 5px 3px; border: 1px solid #cbd5e1; text-align: center;">2nd %</th>
                <th style="padding: 5px 3px; border: 1px solid #cbd5e1; text-align: center; background: #dcfce7; color: #14532d; font-weight: 800;">Grand Total<br>Marks (کل نمبر)</th>
                <th style="padding: 5px 3px; border: 1px solid #cbd5e1; text-align: center; background: #e0e7ff; color: #3730a3; font-weight: 800;">Combined<br>Obtained</th>
                <th style="padding: 5px 3px; border: 1px solid #cbd5e1; text-align: center;">Agg %</th>
                <th style="padding: 5px 3px; border: 1px solid #cbd5e1; text-align: center;">Grade</th>
                <th style="padding: 5px 3px; border: 1px solid #cbd5e1; text-align: center;">GPA</th>
                <th style="padding: 5px 3px; border: 1px solid #cbd5e1; text-align: center;">Position</th>
                <th style="padding: 5px 3px; border: 1px solid #cbd5e1; text-align: center;">Annual Result</th>
              ` : `
                ${classSubjects.map(sub => `
                  <th style="padding: 4px 2px; border: 1px solid #cbd5e1; text-align: center; font-size: 9.5px; line-height: 1.2;">
                    ${sub.name.split(' ')[0]}<br>
                    <span style="font-size: 8.5px; color: #1e3a8a; font-weight: 700;">(${sub.totalMarks || 100})</span>
                  </th>
                `).join('')}
                <th style="padding: 5px 3px; border: 1px solid #cbd5e1; text-align: center; background: #f0fdf4; color: #166534; font-weight: 800; min-width: 65px;">Total Marks<br><span style="font-size:8px;">(کل نمبر)</span></th>
                <th style="padding: 5px 3px; border: 1px solid #cbd5e1; text-align: center; background: #eff6ff; color: #1e40af; font-weight: 800; min-width: 65px;">Marks Obtained<br><span style="font-size:8px;">(حاصل کردہ)</span></th>
                <th style="padding: 5px 3px; border: 1px solid #cbd5e1; text-align: center;">%</th>
                <th style="padding: 5px 3px; border: 1px solid #cbd5e1; text-align: center;">Grade</th>
                <th style="padding: 5px 3px; border: 1px solid #cbd5e1; text-align: center;">GPA</th>
                <th style="padding: 5px 3px; border: 1px solid #cbd5e1; text-align: center;">Position</th>
                <th style="padding: 5px 3px; border: 1px solid #cbd5e1; text-align: center;">Result</th>
              `}
            </tr>
          </thead>
          <tbody>
            ${tableRows}
          </tbody>
          <tfoot>
            <tr style="background: #f8fafc; font-weight: 700; border-top: 2.5px solid #0f172a;">
              <td colspan="5" style="text-align: right; padding: 6px 8px; font-weight: 800; font-size: 10.5px;">
                Total Marks of All Subjects (تمام مضامین کے کل نمبر):
              </td>
              ${isCombined ? `
                <td style="text-align: center; font-weight: 800; color: #166534; background: #f0fdf4; padding: 6px 3px;">${classTotalMarks}</td>
                <td style="text-align: center; font-weight: 700; color: #1e3a8a; background: #eff6ff;">-</td>
                <td style="text-align: center; font-weight: 700;">-</td>
                <td style="text-align: center; font-weight: 800; color: #166534; background: #f0fdf4; padding: 6px 3px;">${classTotalMarks}</td>
                <td style="text-align: center; font-weight: 700; color: #1e3a8a; background: #eff6ff;">-</td>
                <td style="text-align: center; font-weight: 700;">-</td>
                <td style="text-align: center; font-weight: 900; color: #14532d; background: #dcfce7; font-size: 11px; padding: 6px 3px;">${classTotalMarks * 2}</td>
                <td style="text-align: center; font-weight: 800; color: #1e3a8a; background: #eff6ff; padding: 6px 3px;">${validStudentCount > 0 ? Math.round(totalClassObtainedSum / validStudentCount) : 0} (Avg)</td>
                <td style="text-align: center; font-weight: 800; padding: 6px 3px;">${classAveragePct}%</td>
                <td colspan="4" style="text-align: center; color: #334155; font-size: 10px; padding: 6px 3px;">
                  Annual Promotion Rate: <strong style="color: #15803d;">${passPercentage}%</strong> (${passedCount} Promoted)
                </td>
              ` : `
                ${classSubjects.map(sub => `
                  <td style="text-align: center; font-weight: 800; color: #1e3a8a; background: #eff6ff; padding: 6px 2px; font-size: 10px;">
                    ${sub.totalMarks || 100}
                  </td>
                `).join('')}
                <td style="text-align: center; font-weight: 900; color: #166534; background: #dcfce7; font-size: 11px; padding: 6px 3px;">
                  ${classTotalMarks}
                </td>
                <td style="text-align: center; font-weight: 800; color: #1e3a8a; background: #eff6ff; padding: 6px 3px;">
                  ${validStudentCount > 0 ? Math.round(totalClassObtainedSum / validStudentCount) : 0} (Avg)
                </td>
                <td style="text-align: center; font-weight: 800; padding: 6px 3px;">
                  ${classAveragePct}%
                </td>
                <td colspan="4" style="text-align: center; color: #334155; font-size: 10px; padding: 6px 3px;">
                  Class Pass Rate: <strong style="color: #15803d;">${passPercentage}%</strong> (${passedCount} Passed, ${failedCount} Failed)
                </td>
              `}
            </tr>
          </tfoot>
        </table>

        <!-- Position Holders Highlight Strip -->
        <div style="margin-top: 10px; background: #fefce8; border: 1px solid #fde047; border-radius: 6px; padding: 8px 12px; display: flex; justify-content: space-around; align-items: center; font-size: 11px;">
          <div>🥇 <strong>1st Position:</strong> ${top1 ? `${top1.student.name} (Roll: ${top1.student.rollNo}, ${top1.obtained} Marks, ${top1.percentage}%)` : 'N/A'}</div>
          <div>🥈 <strong>2nd Position:</strong> ${top2 ? `${top2.student.name} (Roll: ${top2.student.rollNo}, ${top2.obtained} Marks, ${top2.percentage}%)` : 'N/A'}</div>
          <div>🥉 <strong>3rd Position:</strong> ${top3 ? `${top3.student.name} (Roll: ${top3.student.rollNo}, ${top3.obtained} Marks, ${top3.percentage}%)` : 'N/A'}</div>
        </div>

        <!-- Official Signatures -->
        <div style="margin-top: 18px; display: flex; justify-content: space-between; align-items: flex-end; font-size: 11.5px; padding-top: 12px; border-top: 1.5px solid #cbd5e1;">
          <div style="text-align: center; width: 220px;">
            <div style="border-bottom: 1px solid #000; height: 30px; margin-bottom: 5px;"></div>
            <span>Class Teacher / Incharge <span class="urdu-title">(کلاس انچارج)</span></span>
          </div>
          <div style="text-align: center; width: 220px;">
            <div style="border-bottom: 1px solid #000; height: 30px; margin-bottom: 5px;"></div>
            <span>Tabulator / Controller of Exams <span class="urdu-title">(کنٹرولر امتحانات)</span></span>
          </div>
          <div style="text-align: center; width: 220px;">
            <div style="border-bottom: 1px solid #000; height: 30px; margin-bottom: 5px;"></div>
            <strong style="font-size: 12px;">Principal / Headmaster <span class="urdu-title">(پرنسپل / ہیڈ ماسٹر)</span></strong>
          </div>
        </div>

        <div style="margin-top: 10px; font-size: 9.5px; color: #64748b; display: flex; justify-content: space-between; align-items: center; border-top: 1px dotted #cbd5e1; padding-top: 4px;">
          <span>Govt: High School Zando Dheri, Mardan &bull; Official Computer-Generated Tabulation Gazette</span>
          <span>Designed &amp; Developed by: <strong>Shaukat Zando</strong></span>
        </div>
      </div>
    `;

    this.printLandscapeElement(htmlContent);
  },

  // ==================== TEACHING & NON-TEACHING STAFF REPORTS ====================

  // 1. Print Landscape PDF Roster of all Teaching & Non-teaching Staff
  printStaffRosterLandscape() {
    const teachers = SchoolDB.getTeachers();
    const settings = SchoolDB.data.settings;

    if (!teachers.length) {
      alert('No staff members registered in the database.');
      return;
    }

    const rowsHtml = teachers.map((t, idx) => {
      const photoHtml = t.photo
        ? `<img src="${t.photo}" alt="${t.name}" style="width: 28px; height: 32px; object-fit: cover; border-radius: 3px; border: 1px solid #cbd5e1; display: block; margin: 0 auto;">`
        : `<div style="width: 28px; height: 32px; background: #f1f5f9; border-radius: 3px; display: flex; align-items: center; justify-content: center; font-size: 13px; color: #94a3b8; margin: 0 auto; border: 1px dashed #cbd5e1;">&#128100;</div>`;

      return `
        <tr style="height: 38px;">
          <td style="text-align: center; font-weight: 600; font-size: 10px;">${idx + 1}</td>
          <td style="text-align: center; padding: 2px;">${photoHtml}</td>
          <td style="text-align: center; font-weight: 700; font-family: monospace; font-size: 10px; color: #1e3a8a;">${t.id}</td>
          <td style="font-weight: 700; font-size: 11px; color: #0f172a; white-space: nowrap;">${t.name}</td>
          <td style="font-size: 10.5px; color: #334155; white-space: nowrap;">${t.fatherName || '-'}</td>
          <td style="font-weight: 600; font-size: 10px; color: #0f172a; white-space: nowrap;">${t.designation || 'Staff'}</td>
          <td style="text-align: center; font-weight: 700; font-size: 10px;">${t.bps || 'BPS-16'}</td>
          <td style="font-size: 10px; color: #0369a1; font-weight: 600;">${t.qualification || '-'}</td>
          <td style="font-size: 10px; color: #92400e; font-weight: 600;">${t.profQualification || t.professionalQualification || '-'}</td>
          <td style="text-align: center; font-family: monospace; font-size: 10px; font-weight: 700; color: #1e40af;">${t.personalNo || '-'}</td>
          <td style="text-align: center; font-family: monospace; font-size: 9.5px; white-space: nowrap;">${t.cnic || '-'}</td>
          <td style="text-align: center; font-family: monospace; font-size: 9.5px; color: #065f46; font-weight: 600; white-space: nowrap;">${t.salaryAccount || '-'}</td>
          <td style="text-align: center; font-size: 9.5px; font-weight: 700;">${t.bankCode || '-'}</td>
          <td style="font-size: 9.5px; white-space: nowrap;">${t.bankName || '-'}</td>
          <td style="text-align: center; font-size: 9.5px; white-space: nowrap;">${t.phone || '-'}</td>
          <td style="text-align: center; font-size: 9px; font-weight: 700; color: ${t.status === 'Active' ? '#15803d' : '#b91c1c'};">${t.status || 'Active'}</td>
        </tr>
      `;
    }).join('');

    const htmlContent = `
      <div class="printable-target" style="padding: 6px 10px; font-size: 10px; font-family: Arial, sans-serif; background: #fff; width: 100%; max-width: 100%;">
        <!-- Header -->
        <div style="display: flex; align-items: center; justify-content: space-between; border-bottom: 2px solid #1e3a8a; padding-bottom: 6px; margin-bottom: 8px;">
          <div style="width: 65px; text-align: center;">
            <img src="${settings.logoUrl || 'assets/logo.png'}" onerror="this.style.display='none'" style="max-height: 55px; max-width: 55px; object-fit: contain;">
          </div>
          <div style="flex: 1; text-align: center; line-height: 1.25;">
            <div style="font-size: 11px; font-weight: 600; letter-spacing: 1px; color: #475569; text-transform: uppercase;">GOVERNMENT OF KHYBER PAKHTUNKHWA &bull; ELEMENTARY &amp; SECONDARY EDUCATION DEPARTMENT</div>
            <h1 style="margin: 2px 0; font-size: 17px; font-weight: 900; color: #1e3a8a; text-transform: uppercase; letter-spacing: 0.5px;">${settings.schoolName || 'GOVT: HIGH SCHOOL ZANDO DHERI, MARDAN'}</h1>
            <div style="font-size: 13px; font-weight: 800; color: #0f172a; margin-top: 2px; text-decoration: underline;">
              TEACHING &amp; NON-TEACHING STAFF REGISTER (ملازمین حاضری و سروس رجسٹر)
            </div>
          </div>
          <div style="width: 80px; text-align: right; font-size: 9px; color: #475569; line-height: 1.3;">
            <div><strong>Date:</strong> ${new Date().toLocaleDateString('en-GB')}</div>
            <div><strong>Total Staff:</strong> ${teachers.length}</div>
            <div><strong>EMIS Code:</strong> ${settings.emisCode || '18456'}</div>
          </div>
        </div>

        <!-- Staff Table -->
        <table style="width: 100%; border-collapse: collapse; font-size: 9.5px; border: 1.5px solid #0f172a;">
          <thead>
            <tr style="background: #0f172a; color: #ffffff; text-align: center; font-size: 9px;">
              <th style="border: 1px solid #334155; padding: 4px 2px; width: 24px;">S.#</th>
              <th style="border: 1px solid #334155; padding: 4px 2px; width: 34px;">Photo</th>
              <th style="border: 1px solid #334155; padding: 4px 2px; width: 55px;">Emp ID</th>
              <th style="border: 1px solid #334155; padding: 4px 4px; text-align: left;">Employee Name (نام)</th>
              <th style="border: 1px solid #334155; padding: 4px 4px; text-align: left;">Father Name (والد کا نام)</th>
              <th style="border: 1px solid #334155; padding: 4px 3px; text-align: left;">Designation (عہدہ)</th>
              <th style="border: 1px solid #334155; padding: 4px 2px; width: 45px;">BPS</th>
              <th style="border: 1px solid #334155; padding: 4px 3px;">Academic Qual.</th>
              <th style="border: 1px solid #334155; padding: 4px 3px;">Prof. Qual.</th>
              <th style="border: 1px solid #334155; padding: 4px 2px; width: 62px;">Personal #</th>
              <th style="border: 1px solid #334155; padding: 4px 3px; width: 85px;">CNIC No</th>
              <th style="border: 1px solid #334155; padding: 4px 3px; width: 105px;">Salary Account No</th>
              <th style="border: 1px solid #334155; padding: 4px 2px; width: 40px;">Bank Code</th>
              <th style="border: 1px solid #334155; padding: 4px 3px;">Bank Name</th>
              <th style="border: 1px solid #334155; padding: 4px 2px; width: 75px;">Phone</th>
              <th style="border: 1px solid #334155; padding: 4px 2px; width: 38px;">Status</th>
            </tr>
          </thead>
          <tbody>
            ${rowsHtml}
          </tbody>
        </table>

        <!-- Signatures & Authority Section -->
        <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-top: 24px; padding: 0 15px; font-size: 11px;">
          <div style="text-align: center; width: 220px;">
            <div style="border-bottom: 1px solid #000; height: 35px; margin-bottom: 4px;"></div>
            <span>Establishment Clerk / Incharge <span class="urdu-title">(کلرک / انچارج ملازمین)</span></span>
          </div>
          <div style="text-align: center; width: 220px;">
            <div style="border-bottom: 1px solid #000; height: 35px; margin-bottom: 4px;"></div>
            <span>Accountant / DDO Assistant <span class="urdu-title">(اکاؤنٹنٹ / ڈی ڈی او)</span></span>
          </div>
          <div style="text-align: center; width: 220px;">
            <div style="border-bottom: 1px solid #000; height: 35px; margin-bottom: 4px;"></div>
            <strong style="font-size: 12px;">Principal / Headmaster <span class="urdu-title">(پرنسپل / ہیڈ ماسٹر)</span></strong>
            <div style="font-size: 9.5px; color: #475569;">Official Seal &amp; Signature</div>
          </div>
        </div>

        <!-- Footer watermark -->
        <div style="margin-top: 14px; font-size: 9.5px; color: #64748b; display: flex; justify-content: space-between; align-items: center; border-top: 1px dotted #cbd5e1; padding-top: 4px;">
          <span>Govt: High School Zando Dheri, Mardan &bull; Official Staff Directory Sheet</span>
          <span>Designed &amp; Developed by: <strong>Shaukat Zando</strong></span>
        </div>
      </div>
    `;

    this.printLandscapeElement(htmlContent);
  },

  // 2. Print Single-Page Authentic Employee Bio-Data Report (بائیو ڈیٹا)
  printStaffBioData(teacherId) {
    const teacher = SchoolDB.getTeacherById(teacherId);
    const settings = SchoolDB.data.settings;

    if (!teacher) {
      alert('Selected staff member record not found.');
      return;
    }

    const photoHtml = teacher.photo
      ? `<img src="${teacher.photo}" alt="${teacher.name}" style="width: 125px; height: 150px; object-fit: cover; border-radius: 4px; border: 1.5px solid #1e3a8a; box-shadow: 0 2px 4px rgba(0,0,0,0.12);">`
      : `<div style="width: 125px; height: 150px; border: 2px dashed #94a3b8; border-radius: 4px; display: flex; flex-direction: column; align-items: center; justify-content: center; background: #f8fafc; color: #64748b;">
           <span style="font-size: 32px;">&#128100;</span>
           <span style="font-size: 10px; font-weight: 600; margin-top: 4px;">Passport Photo</span>
           <span style="font-size: 9px; color: #94a3b8;">(تصویر برائے بائیو ڈیٹا)</span>
         </div>`;

    const htmlContent = `
      <div class="printable-target" style="padding: 10px 18px; font-family: Arial, sans-serif; background: #fff; width: 100%; max-width: 780px; margin: 0 auto; color: #0f172a; line-height: 1.35;">
        
        <!-- Document Border Frame -->
        <div style="border: 2px solid #1e3a8a; padding: 14px 16px; border-radius: 4px; position: relative;">
          
          <!-- Outer Header -->
          <div style="display: flex; align-items: center; justify-content: space-between; border-bottom: 2px solid #1e3a8a; padding-bottom: 8px; margin-bottom: 12px;">
            <div style="width: 75px; text-align: center;">
              <img src="${settings.logoUrl || 'assets/logo.png'}" onerror="this.style.display='none'" style="max-height: 70px; max-width: 70px; object-fit: contain;">
            </div>
            <div style="flex: 1; text-align: center; line-height: 1.25;">
              <div style="font-size: 11px; font-weight: 700; letter-spacing: 1.5px; color: #475569; text-transform: uppercase;">GOVERNMENT OF KHYBER PAKHTUNKHWA</div>
              <div style="font-size: 11.5px; font-weight: 600; color: #059669; text-transform: uppercase;">ELEMENTARY &amp; SECONDARY EDUCATION DEPARTMENT</div>
              <h1 style="margin: 3px 0; font-size: 18px; font-weight: 900; color: #1e3a8a; text-transform: uppercase; letter-spacing: 0.5px;">${settings.schoolName || 'GOVT: HIGH SCHOOL ZANDO DHERI, MARDAN'}</h1>
              <div style="display: inline-block; background: #1e3a8a; color: #ffffff; padding: 3px 18px; border-radius: 3px; font-size: 13px; font-weight: 800; letter-spacing: 1px; margin-top: 4px;">
                STAFF BIO-DATA / ملازم سروس بائیو ڈیٹا
              </div>
            </div>
            <div style="width: 75px; text-align: right; font-size: 9.5px; color: #475569;">
              <div><strong>EMIS:</strong> ${settings.emisCode || '18456'}</div>
              <div><strong>District:</strong> Mardan</div>
              <div><strong>Status:</strong> <span style="font-weight: 700; color: ${teacher.status === 'Active' ? '#15803d' : '#b91c1c'};">${teacher.status || 'Active'}</span></div>
            </div>
          </div>

          <!-- Top Identification Card Row with Photo -->
          <div style="display: flex; gap: 14px; margin-bottom: 12px; align-items: flex-start;">
            <div style="flex: 1;">
              <table style="width: 100%; border-collapse: collapse; font-size: 11px; border: 1px solid #cbd5e1;">
                <tbody>
                  <tr style="background: #f8fafc;">
                    <td style="padding: 6px 8px; font-weight: 700; color: #475569; width: 140px; border-bottom: 1px solid #e2e8f0;">Full Name (مکمل نام):</td>
                    <td style="padding: 6px 8px; font-weight: 800; font-size: 13px; color: #1e3a8a; border-bottom: 1px solid #e2e8f0;">${teacher.name}</td>
                  </tr>
                  <tr>
                    <td style="padding: 6px 8px; font-weight: 700; color: #475569; border-bottom: 1px solid #e2e8f0;">Father Name (والد کا نام):</td>
                    <td style="padding: 6px 8px; font-size: 12px; font-weight: 700; border-bottom: 1px solid #e2e8f0;">${teacher.fatherName || 'N/A'}</td>
                  </tr>
                  <tr style="background: #f8fafc;">
                    <td style="padding: 6px 8px; font-weight: 700; color: #475569; border-bottom: 1px solid #e2e8f0;">Employee ID / ریفرنس:</td>
                    <td style="padding: 6px 8px; font-family: monospace; font-size: 12px; font-weight: 800; color: #0284c7; border-bottom: 1px solid #e2e8f0;">${teacher.id}</td>
                  </tr>
                  <tr>
                    <td style="padding: 6px 8px; font-weight: 700; color: #475569; border-bottom: 1px solid #e2e8f0;">Current Designation (عہدہ):</td>
                    <td style="padding: 6px 8px; font-size: 12px; font-weight: 800; color: #0f172a; border-bottom: 1px solid #e2e8f0;">${teacher.designation || 'Staff'}</td>
                  </tr>
                  <tr style="background: #f8fafc;">
                    <td style="padding: 6px 8px; font-weight: 700; color: #475569; border-bottom: 1px solid #e2e8f0;">Basic Pay Scale (BPS / اسکیل):</td>
                    <td style="padding: 6px 8px; font-weight: 800; font-size: 12px; color: #b45309; border-bottom: 1px solid #e2e8f0;">${teacher.bps || 'BPS-16'}</td>
                  </tr>
                  <tr>
                    <td style="padding: 6px 8px; font-weight: 700; color: #475569;">Gender / جنس:</td>
                    <td style="padding: 6px 8px; font-size: 11.5px; font-weight: 600;">${teacher.gender || 'Male'}</td>
                  </tr>
                </tbody>
              </table>
            </div>

            <!-- Photo Frame on Top-Right -->
            <div style="width: 130px; text-align: center; flex-shrink: 0;">
              ${photoHtml}
              <div style="font-size: 9.5px; color: #64748b; margin-top: 4px; font-weight: 600;">Verified Photograph</div>
            </div>
          </div>

          <!-- Section 1: Qualifications & Educational Attainment -->
          <div style="background: #1e3a8a; color: #fff; padding: 4px 8px; font-size: 11px; font-weight: 700; letter-spacing: 0.5px; margin-bottom: 6px; border-radius: 2px;">
            1. EDUCATIONAL &amp; PROFESSIONAL QUALIFICATIONS (تعلیمی و پیشہ ورانہ اسناد)
          </div>
          <table style="width: 100%; border-collapse: collapse; font-size: 11px; border: 1px solid #cbd5e1; margin-bottom: 12px;">
            <tbody>
              <tr style="background: #f8fafc;">
                <td style="padding: 7px 10px; font-weight: 700; color: #475569; width: 190px; border-bottom: 1px solid #e2e8f0; border-right: 1px solid #e2e8f0;">
                  Academic Qualification <br><small class="text-muted" style="font-weight: normal;">(تعلیمی قابلیت - ڈگری/سند)</small>
                </td>
                <td style="padding: 7px 10px; font-weight: 700; font-size: 12px; color: #0369a1; border-bottom: 1px solid #e2e8f0;">
                  ${teacher.qualification || 'Not Specified'}
                </td>
              </tr>
              <tr>
                <td style="padding: 7px 10px; font-weight: 700; color: #475569; border-right: 1px solid #e2e8f0;">
                  Professional Qualification <br><small class="text-muted" style="font-weight: normal;">(پیشہ ورانہ تربیت و تدریسی اسناد)</small>
                </td>
                <td style="padding: 7px 10px; font-weight: 700; font-size: 12px; color: #92400e;">
                  ${teacher.profQualification || teacher.professionalQualification || 'N/A (e.g. B.Ed, M.Ed, PTC)'}
                </td>
              </tr>
            </tbody>
          </table>

          <!-- Section 2: Official Service & Identification Particulars -->
          <div style="background: #1e3a8a; color: #fff; padding: 4px 8px; font-size: 11px; font-weight: 700; letter-spacing: 0.5px; margin-bottom: 6px; border-radius: 2px;">
            2. SERVICE &amp; CIVIL IDENTIFICATION (سروس کوائف و شناختی تفصیلات)
          </div>
          <table style="width: 100%; border-collapse: collapse; font-size: 11px; border: 1px solid #cbd5e1; margin-bottom: 12px;">
            <tbody>
              <tr>
                <td style="padding: 6px 8px; font-weight: 700; color: #475569; width: 22%; border: 1px solid #e2e8f0; background: #f8fafc;">Personal No (SAP ID):</td>
                <td style="padding: 6px 8px; font-weight: 800; font-family: monospace; font-size: 12px; color: #1e40af; border: 1px solid #e2e8f0; width: 28%;">${teacher.personalNo || 'N/A'}</td>
                <td style="padding: 6px 8px; font-weight: 700; color: #475569; width: 22%; border: 1px solid #e2e8f0; background: #f8fafc;">CNIC No (شناختی کارڈ):</td>
                <td style="padding: 6px 8px; font-weight: 700; font-family: monospace; font-size: 11.5px; border: 1px solid #e2e8f0; width: 28%;">${teacher.cnic || 'N/A'}</td>
              </tr>
              <tr>
                <td style="padding: 6px 8px; font-weight: 700; color: #475569; border: 1px solid #e2e8f0; background: #f8fafc;">Date of Joining (تاریخ تقرری):</td>
                <td style="padding: 6px 8px; font-size: 11px; border: 1px solid #e2e8f0;">${teacher.joinDate || 'N/A'}</td>
                <td style="padding: 6px 8px; font-weight: 700; color: #475569; border: 1px solid #e2e8f0; background: #f8fafc;">Phone / Mobile:</td>
                <td style="padding: 6px 8px; font-weight: 700; font-size: 11px; border: 1px solid #e2e8f0;">${teacher.phone || 'N/A'}</td>
              </tr>
              <tr>
                <td style="padding: 6px 8px; font-weight: 700; color: #475569; border: 1px solid #e2e8f0; background: #f8fafc;">Email Address:</td>
                <td style="padding: 6px 8px; font-size: 11px; border: 1px solid #e2e8f0;" colspan="3">${teacher.email || 'N/A'}</td>
              </tr>
            </tbody>
          </table>

          <!-- Section 3: Salary & Bank Disbursal Account Details -->
          <div style="background: #1e3a8a; color: #fff; padding: 4px 8px; font-size: 11px; font-weight: 700; letter-spacing: 0.5px; margin-bottom: 6px; border-radius: 2px;">
            3. SALARY &amp; BANK DISBURSAL PARTICULARS (بینک اکاؤنٹ و تنخواہ تفصیلات)
          </div>
          <table style="width: 100%; border-collapse: collapse; font-size: 11px; border: 1px solid #cbd5e1; margin-bottom: 12px;">
            <tbody>
              <tr>
                <td style="padding: 6px 8px; font-weight: 700; color: #475569; width: 22%; border: 1px solid #e2e8f0; background: #f8fafc;">Salary Account No:</td>
                <td style="padding: 6px 8px; font-weight: 800; font-family: monospace; font-size: 12px; color: #065f46; border: 1px solid #e2e8f0; width: 38%;">${teacher.salaryAccount || 'N/A'}</td>
                <td style="padding: 6px 8px; font-weight: 700; color: #475569; width: 18%; border: 1px solid #e2e8f0; background: #f8fafc;">Branch / Bank Code:</td>
                <td style="padding: 6px 8px; font-weight: 800; font-family: monospace; font-size: 11.5px; border: 1px solid #e2e8f0; width: 22%;">${teacher.bankCode || 'N/A'}</td>
              </tr>
              <tr>
                <td style="padding: 6px 8px; font-weight: 700; color: #475569; border: 1px solid #e2e8f0; background: #f8fafc;">Disbursing Bank Name:</td>
                <td style="padding: 6px 8px; font-weight: 700; font-size: 11.5px; border: 1px solid #e2e8f0;" colspan="3">${teacher.bankName || 'N/A'}</td>
              </tr>
            </tbody>
          </table>

          <!-- Section 4: Employee Undertaking & Administrative Authentication -->
          <div style="margin-top: 14px; padding: 6px 10px; background: #f8fafc; border: 1px dashed #cbd5e1; border-radius: 4px; font-size: 10px; line-height: 1.4; color: #334155;">
            <strong>Employee Declaration / اقرار نامہ:</strong> I hereby declare that the personal, educational, professional, and bank particulars stated above are true and accurate to the best of my knowledge and record.
          </div>

          <!-- Official Signatures Block -->
          <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-top: 36px; padding: 0 10px; font-size: 11px;">
            <div style="text-align: center; width: 200px;">
              <div style="border-bottom: 1px solid #000; height: 35px; margin-bottom: 4px;"></div>
              <strong>Signature of Employee</strong>
              <div style="font-size: 9.5px; color: #475569;">دستخط ملازم</div>
            </div>
            <div style="text-align: center; width: 200px;">
              <div style="border-bottom: 1px solid #000; height: 35px; margin-bottom: 4px;"></div>
              <strong>Establishment / Clerk Incharge</strong>
              <div style="font-size: 9.5px; color: #475569;">دستخط کلرک / انچارج</div>
            </div>
            <div style="text-align: center; width: 200px;">
              <div style="border-bottom: 1px solid #000; height: 35px; margin-bottom: 4px;"></div>
              <strong style="font-size: 12px; color: #1e3a8a;">Principal / Headmaster</strong>
              <div style="font-size: 9.5px; color: #475569;">Official Seal &amp; Signature (پرنسپل مہر و دستخط)</div>
            </div>
          </div>

          <!-- Bottom Footer Reference -->
          <div style="margin-top: 18px; font-size: 9px; color: #64748b; display: flex; justify-content: space-between; align-items: center; border-top: 1px dotted #cbd5e1; padding-top: 4px;">
            <span>GHS Zando Dheri Official EMIS Record &bull; Generated: ${new Date().toLocaleDateString('en-GB')}</span>
            <span>Designed &amp; Developed by: <strong>Shaukat Zando</strong></span>
          </div>

        </div>
      </div>
    `;

    this.printElement(htmlContent);
  },

  // Print isolated landscape document / PDF
  printLandscapeElement(htmlContent) {
    const printWindow = window.open('', '_blank', 'width=1150,height=800');
    if (!printWindow) {
      alert('Pop-up blocked. Please allow popups to print/download documents as PDF.');
      return;
    }

    printWindow.document.open();
    printWindow.document.write(`
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <title>Student Master Profiles Roster - Landscape</title>
        <style>
          @page {
            size: A4 landscape;
            margin: 10mm 12mm 10mm 12mm;
          }
          * { box-sizing: border-box; }
          body {
            background: #ffffff !important;
            margin: 0;
            padding: 12px;
            color: #0f172a;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }
          table { border-collapse: collapse; width: 100%; }
          th, td { border: 1px solid #cbd5e1; padding: 5px 6px; }
          thead th { background-color: #f1f5f9 !important; font-weight: 700; color: #0f172a; }
          tbody tr:nth-child(even) { background-color: #f8fafc; }
          @media print {
            body { padding: 0 !important; }
            .no-print { display: none !important; }
          }
        </style>
      </head>
      <body>
        <div class="no-print" style="background: #eff6ff; border: 1px solid #93c5fd; padding: 10px 16px; border-radius: 6px; margin-bottom: 12px; display: flex; justify-content: space-between; align-items: center;">
          <div style="font-size: 13px; color: #1e3a8a;">
            &#128424; <strong>Landscape Print &amp; PDF View:</strong> Use your browser's Print dialog to save as <strong>PDF (Landscape)</strong> or send to printer.
          </div>
          <div>
            <button onclick="window.print()" style="background: #1e3a8a; color: #fff; border: none; padding: 7px 18px; border-radius: 5px; font-weight: 700; cursor: pointer;">
              &#128424; Print / Save PDF
            </button>
            <button onclick="window.close()" style="background: #e2e8f0; color: #334155; border: none; padding: 7px 14px; border-radius: 5px; margin-left: 6px; cursor: pointer;">
              Close
            </button>
          </div>
        </div>
        ${htmlContent}
        <` + `script>
          window.onload = function() {
            setTimeout(function() {
              window.print();
            }, 350);
          };
        <` + `/script>
      </body>
      </html>
    `);
    printWindow.document.close();
  },

  // Generate HTML for Student Profile & ID Card
  generateStudentIdCardHTML(student) {
    const settings = SchoolDB.data.settings;
    return `
      <div class="id-card-wrapper printable-target">
        <div class="school-id-card">
          <div class="id-header">
            <div class="id-header-top">
              <img src="images/monogram school.jpg" alt="School Monogram" class="id-monogram-img">
              <div>
                <h4>${settings.schoolName}</h4>
                <p>${settings.tagline}</p>
              </div>
            </div>
          </div>
          <div class="id-body">
            <div class="id-avatar-box">
              <div class="id-avatar-icon">
                ${student.photo ? `<img src="${student.photo}" alt="${student.name}" class="id-photo-img">` : `<span>${student.name.charAt(0)}</span>`}
              </div>
              <span class="id-badge-status ${student.status.toLowerCase()}">${student.status}</span>
            </div>
            <div class="id-details">
              <h3>${student.name}</h3>
              <p class="id-role">Student &bull; ${student.grade} - Sec ${student.section}</p>
              <div class="id-meta-grid">
                <div><strong>Admission No:</strong> ${student.id} <span class="urdu-title" style="font-size:10px;">(داخلہ نمبر)</span></div>
                <div><strong>Roll No:</strong> ${student.rollNo} <span class="urdu-title" style="font-size:10px;">(رول نمبر)</span></div>
                <div><strong>Category:</strong> ${student.specialCategory || 'Normal'} <span class="urdu-title" style="font-size:10px;">(کیٹیگری)</span></div>
                <div><strong>DOB:</strong> ${student.dob || 'N/A'} <span class="urdu-title" style="font-size:10px;">(تاریخ پیدائش)</span></div>
                <div><strong>Gender:</strong> ${student.gender} <span class="urdu-title" style="font-size:10px;">(جنس)</span></div>
                <div><strong>Father Name:</strong> ${student.guardian} <span class="urdu-title" style="font-size:10px;">(والد کا نام)</span></div>
                <div><strong>Emergency:</strong> ${student.phone} <span class="urdu-title" style="font-size:10px;">(رابطہ فون)</span></div>
              </div>
            </div>
          </div>
          <div class="id-footer">
            <div class="barcode-fake">||| | |||| | ||| |||| | ||| | |||</div>
            <p>Authorized Academic Credential &bull; Valid for ${settings.academicYear} <span class="urdu-title" style="font-size:9px;">(تصدیق شدہ طالب علم کارڈ)</span></p>
          </div>
        </div>
      </div>
    `;
  },

  // Generate Base64 Data URL for QR Code using qrcode.min.js
  generateQRCodeDataURL(text, width = 192, height = 192) {
    try {
      if (typeof QRCode === 'undefined') {
        console.warn('QRCode library is not loaded');
        return '';
      }
      const tempDiv = document.createElement('div');
      tempDiv.style.position = 'absolute';
      tempDiv.style.left = '-9999px';
      tempDiv.style.top = '-9999px';
      tempDiv.style.width = width + 'px';
      tempDiv.style.height = height + 'px';
      tempDiv.style.visibility = 'hidden';
      const root = document.body || document.documentElement;
      if (root) root.appendChild(tempDiv);

      new QRCode(tempDiv, {
        text: text,
        width: width,
        height: height,
        colorDark: '#000000',
        colorLight: '#ffffff',
        correctLevel: QRCode.CorrectLevel.M
      });

      let dataUrl = '';
      const canvas = tempDiv.querySelector('canvas');
      if (canvas && typeof canvas.toDataURL === 'function') {
        dataUrl = canvas.toDataURL('image/png');
      } else {
        const img = tempDiv.querySelector('img');
        if (img && img.src && img.src.startsWith('data:')) {
          dataUrl = img.src;
        }
      }

      if (root && tempDiv.parentNode === root) {
        root.removeChild(tempDiv);
      }
      return dataUrl;
    } catch (err) {
      console.error('Error generating QR code data URL:', err);
      return '';
    }
  },

  // Build plain text payload covering all exam results for the student
  buildStudentVerificationText(student, markRecord, settings) {
    const schoolName = settings?.schoolName || 'Govt High School';
    const emis = settings?.emisCode ? `EMIS: ${settings.emisCode}` : '';
    const acadYear = settings?.academicYear || '2024 - 2025';
    
    const studentName = student?.name || 'Student';
    const fatherName = student?.guardian || '-';
    const rollNo = student?.rollNo || '-';
    const admNo = student?.id || markRecord?.studentId || '-';
    const cls = `${student?.grade || ''} ${student?.section ? '(' + student.section + ')' : ''}`.trim() || '-';
    
    const sem1 = markRecord?.sem1 || SchoolDB.getStudentMarkByTerm(admNo, '1st Semester');
    const sem2 = markRecord?.sem2 || SchoolDB.getStudentMarkByTerm(admNo, '2nd Semester');
    
    let sem1Line = '1st Sem: Not Conducted / Awaiting';
    if (sem1) {
      sem1Line = `1st Sem: ${sem1.totalObtained}/${sem1.maxMarks} (${sem1.percentage}%) Grade:${sem1.grade || '-'}`;
    } else if (markRecord?.sem1Obtained !== undefined && markRecord?.sem1Max) {
      const p1 = Math.round((markRecord.sem1Obtained / markRecord.sem1Max) * 100);
      sem1Line = `1st Sem: ${markRecord.sem1Obtained}/${markRecord.sem1Max} (${p1}%)`;
    }
    
    let sem2Line = '2nd Sem: Not Conducted / Awaiting';
    if (sem2) {
      sem2Line = `2nd Sem: ${sem2.totalObtained}/${sem2.maxMarks} (${sem2.percentage}%) Grade:${sem2.grade || '-'}`;
    } else if (markRecord?.sem2Obtained !== undefined && markRecord?.sem2Max) {
      const p2 = Math.round((markRecord.sem2Obtained / markRecord.sem2Max) * 100);
      sem2Line = `2nd Sem: ${markRecord.sem2Obtained}/${markRecord.sem2Max} (${p2}%)`;
    }
    
    let grandTot = '-';
    let grandPct = '-';
    let grandGrade = '-';
    let grandGpa = '-';
    let standing = 'Session In Progress';
    
    if (markRecord?.isCombined || markRecord?.examTerm === 'Combined (1st & 2nd Semester)') {
      grandTot = `${markRecord.totalObtained}/${markRecord.maxMarks}`;
      grandPct = `${markRecord.percentage}%`;
      grandGrade = markRecord.grade || '-';
      grandGpa = Number(markRecord.gpa || 0).toFixed(1);
      standing = markRecord.percentage >= 50 ? 'PROMOTED TO NEXT CLASS (PASSED)' : 'NEEDS IMPROVEMENT';
    } else if (sem1 && sem2) {
      const totObt = (Number(sem1.totalObtained) || 0) + (Number(sem2.totalObtained) || 0);
      const totMax = (Number(sem1.maxMarks) || 0) + (Number(sem2.maxMarks) || 0);
      const pct = totMax > 0 ? Math.round((totObt / totMax) * 100) : 0;
      let gr = 'F', gp = 0.0;
      if (pct >= 90) { gr = 'A+'; gp = 4.0; }
      else if (pct >= 80) { gr = 'A'; gp = 3.7; }
      else if (pct >= 70) { gr = 'B'; gp = 3.0; }
      else if (pct >= 60) { gr = 'C'; gp = 2.0; }
      else if (pct >= 50) { gr = 'D'; gp = 1.0; }
      grandTot = `${totObt}/${totMax}`;
      grandPct = `${pct}%`;
      grandGrade = gr;
      grandGpa = gp.toFixed(1);
      standing = pct >= 50 ? 'PROMOTED TO NEXT CLASS (PASSED)' : 'NEEDS IMPROVEMENT';
    } else if (sem1 && !sem2) {
      grandTot = `${sem1.totalObtained}/${sem1.maxMarks}`;
      grandPct = `${sem1.percentage}%`;
      grandGrade = sem1.grade || '-';
      grandGpa = Number(sem1.gpa || 0).toFixed(1);
      standing = sem1.percentage >= 50 ? '1st Sem Passed (In Progress)' : '1st Sem Needs Improvement';
    } else if (sem2 && !sem1) {
      grandTot = `${sem2.totalObtained}/${sem2.maxMarks}`;
      grandPct = `${sem2.percentage}%`;
      grandGrade = sem2.grade || '-';
      grandGpa = Number(sem2.gpa || 0).toFixed(1);
      standing = sem2.percentage >= 50 ? '2nd Sem Passed' : 'Needs Improvement';
    }

    return [
      `OFFICIAL ACADEMIC VERIFICATION`,
      `${schoolName}`,
      emis ? `${emis} | Session: ${acadYear}` : `Session: ${acadYear}`,
      `--------------------------------`,
      `Student: ${studentName}`,
      `Father: ${fatherName}`,
      `Roll No: ${rollNo} | Adm No: ${admNo}`,
      `Class: ${cls}`,
      `--------------------------------`,
      `ACADEMIC RESULTS:`,
      `${sem1Line}`,
      `${sem2Line}`,
      `Combined: ${grandTot} (${grandPct})`,
      `Final Grade: ${grandGrade} | GPA: ${grandGpa}`,
      `Standing: ${standing}`,
      `Verified Official Record`
    ].join('\n');
  },

  // Generate Official Student Report Card (Semester 1st, 2nd & Combined)
  generateReportCardHTML(markRecord) {
    const student = SchoolDB.getStudentById(markRecord.studentId);
    const settings = SchoolDB.data.settings;
    const subjects = SchoolDB.getSubjects();
    const subjectMap = {};
    const subjectMaxMap = {};
    subjects.forEach(s => {
      subjectMap[s.code] = s.name;
      subjectMaxMap[s.code] = Number(s.totalMarks) || 100;
    });

    const attStats = SchoolDB.getAttendanceStatsForStudent(markRecord.studentId);

    const isCombined = markRecord.isCombined || markRecord.examTerm === 'Combined (1st & 2nd Semester)';
    const isSem2 = !isCombined && (markRecord.examTerm === '2nd Semester');
    const isSem1 = !isCombined && (markRecord.examTerm === '1st Semester');

    // Fetch related semester records
    let sem1 = markRecord.sem1;
    if (!sem1 && isSem2) {
      sem1 = SchoolDB.getStudentMarkByTerm(markRecord.studentId, '1st Semester');
    }
    let sem2 = markRecord.sem2;
    if (!sem2 && isSem1) {
      sem2 = SchoolDB.getStudentMarkByTerm(markRecord.studentId, '2nd Semester');
    }

    // Cumulative calculations for 2nd Semester
    const sem1Obt = sem1 ? (Number(sem1.totalObtained) || 0) : 0;
    const sem1Max = sem1 ? (Number(sem1.maxMarks) || 0) : 0;
    const sem1Pct = sem1 ? (Number(sem1.percentage) || 0) : 0;
    const sem1Gpa = sem1 ? (Number(sem1.gpa) || 0) : 0;
    const sem1Grade = sem1 ? (sem1.grade || '-') : '-';

    const sem2Obt = markRecord.totalObtained || 0;
    const sem2Max = markRecord.maxMarks || 0;
    const combinedObt = sem1Obt + sem2Obt;
    const combinedMax = sem1Max + sem2Max;
    const combinedPct = combinedMax > 0 ? Math.round((combinedObt / combinedMax) * 100) : 0;

    let combinedGrade = 'F';
    let combinedGpa = 0.0;
    if (combinedPct >= 90) { combinedGrade = 'A+'; combinedGpa = 4.0; }
    else if (combinedPct >= 80) { combinedGrade = 'A'; combinedGpa = 3.7; }
    else if (combinedPct >= 70) { combinedGrade = 'B'; combinedGpa = 3.0; }
    else if (combinedPct >= 60) { combinedGrade = 'C'; combinedGpa = 2.0; }
    else if (combinedPct >= 50) { combinedGrade = 'D'; combinedGpa = 1.0; }

    let tableHTML = '';
    if (isCombined) {
      // Annual Consolidated Table (Side-by-side subjects)
      let count = 1;
      let rowsHTML = '';
      for (const [code, val] of Object.entries(markRecord.scores || {})) {
        const subName = subjectMap[code] || code;
        const s1 = (typeof val === 'object' && val !== null) ? val.sem1 : null;
        const s2 = (typeof val === 'object' && val !== null) ? val.sem2 : null;
        const tot = (typeof val === 'object' && val !== null) ? val.total : (Number(val) || 0);
        const max = (typeof val === 'object' && val !== null) ? val.max : 200;
        const pct = max > 0 ? Math.round((tot / max) * 100) : 0;

        let subGrade = 'F';
        if (pct >= 90) subGrade = 'A+';
        else if (pct >= 80) subGrade = 'A';
        else if (pct >= 70) subGrade = 'B';
        else if (pct >= 60) subGrade = 'C';
        else if (pct >= 50) subGrade = 'D';

        rowsHTML += `
          <tr>
            <td style="text-align: center;">${count++}</td>
            <td><strong>${subName}</strong> <small class="text-muted">(${code})</small></td>
            <td class="text-center font-bold">${s1 !== null ? s1 : '-'}</td>
            <td class="text-center font-bold">${s2 !== null ? s2 : '-'}</td>
            <td class="text-center font-bold highlight-score">${tot} / ${max}</td>
            <td class="text-center">${pct}%</td>
            <td class="text-center"><span class="grade-pill grade-${subGrade.replace('+', 'plus')}">${subGrade}</span></td>
          </tr>
        `;
      }

      tableHTML = `
        <table class="report-table">
          <thead>
            <tr>
              <th style="width: 45px;">#</th>
              <th>Subject Title <span class="urdu-title">(مضمون)</span></th>
              <th class="text-center">1st Sem (100) <span class="urdu-title">(سمسٹر اول)</span></th>
              <th class="text-center">2nd Sem (100) <span class="urdu-title">(سمسٹر دوم)</span></th>
              <th class="text-center">Combined Marks <span class="urdu-title">(مجموعی نمبر)</span></th>
              <th class="text-center">Percentage <span class="urdu-title">(فیصد)</span></th>
              <th class="text-center">Grade <span class="urdu-title">(گریڈ)</span></th>
            </tr>
          </thead>
          <tbody>
            ${rowsHTML}
          </tbody>
          <tfoot>
            <tr class="summary-row">
              <td colspan="2" class="text-right font-bold">Annual Cumulative Total <span class="urdu-title">(سالانہ مجموعی کارکردگی)</span></td>
              <td class="text-center font-bold">${markRecord.sem1Obtained} / ${markRecord.sem1Max}</td>
              <td class="text-center font-bold">${markRecord.sem2Obtained} / ${markRecord.sem2Max}</td>
              <td class="text-center font-bold highlight-score">${markRecord.totalObtained} / ${markRecord.maxMarks}</td>
              <td class="text-center font-bold">${markRecord.percentage}%</td>
              <td class="text-center font-bold"><span class="grade-pill grade-${(markRecord.grade || 'F').replace('+', 'plus')}">${markRecord.grade}</span></td>
            </tr>
          </tfoot>
        </table>
      `;
    } else {
      let count = 1;
      let rowsHTML = '';
      for (const [code, score] of Object.entries(markRecord.scores || {})) {
        const subName = subjectMap[code] || code;
        const numScore = Number(score) || 0;
        const maxScore = subjectMaxMap[code] || 100;
        const passScore = Math.ceil(maxScore * 0.4);
        const subPct = maxScore > 0 ? Math.round((numScore / maxScore) * 100) : 0;

        let subGrade = 'F';
        if (subPct >= 90) subGrade = 'A+';
        else if (subPct >= 80) subGrade = 'A';
        else if (subPct >= 70) subGrade = 'B';
        else if (subPct >= 60) subGrade = 'C';
        else if (subPct >= 50) subGrade = 'D';

        rowsHTML += `
          <tr>
            <td>${count++}</td>
            <td><strong>${subName}</strong> <small class="text-muted">(${code})</small></td>
            <td class="text-center font-bold">${maxScore}</td>
            <td class="text-center">${passScore}</td>
            <td class="text-center font-bold ${numScore < passScore ? 'text-danger' : ''}">${numScore}</td>
            <td class="text-center"><span class="grade-pill grade-${subGrade.replace('+', 'plus')}">${subGrade}</span></td>
          </tr>
        `;
      }

      tableHTML = `
        <table class="report-table">
          <thead>
            <tr>
              <th style="width: 50px;">#</th>
              <th>Subject Title <span class="urdu-title">(مضمون)</span></th>
              <th class="text-center">Max Marks <span class="urdu-title">(کل نمبر)</span></th>
              <th class="text-center">Pass Marks <span class="urdu-title">(پاسنگ)</span></th>
              <th class="text-center">Marks Obtained <span class="urdu-title">(حاصل کردہ)</span></th>
              <th class="text-center">Grade <span class="urdu-title">(گریڈ)</span></th>
            </tr>
          </thead>
          <tbody>
            ${rowsHTML}
          </tbody>
          <tfoot>
            <tr class="summary-row">
              <td colspan="2" class="text-right font-bold">${markRecord.examTerm} Total <span class="urdu-title">(سمسٹر کارکردگی)</span></td>
              <td class="text-center font-bold">${markRecord.maxMarks}</td>
              <td class="text-center">-</td>
              <td class="text-center font-bold highlight-score">${markRecord.totalObtained}</td>
              <td class="text-center font-bold"><span class="grade-pill grade-${(markRecord.grade || 'F').replace('+', 'plus')}">${markRecord.grade}</span></td>
            </tr>
          </tfoot>
        </table>
      `;
    }

    // Compact Cumulative blocks for 2nd Semester (Engineered specifically for single-page print fit)
    let sem2AdditionalBlocks = '';
    if (isSem2) {
      sem2AdditionalBlocks = `
        <!-- Combined & Previous Cumulative Standing Summary Panel -->
        <div style="background: linear-gradient(135deg, #f0fdf4 0%, #eff6ff 100%); border: 1.5px solid #93c5fd; border-radius: 6px; padding: 7px 10px; margin: 8px 0 10px;">
          <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #bfdbfe; padding-bottom: 4px; margin-bottom: 6px;">
            <strong style="color: #1e3a8a; font-size: 11.5px; display: flex; align-items: center; gap: 5px;">
              <span>&#127891;</span> 1ST &amp; 2ND SEMESTER COMBINED AGGREGATE STANDING (سالانہ مجموعی کارکردگی)
            </strong>
            <span style="font-size: 10px; font-weight: 700; color: ${combinedPct >= 50 ? '#15803d' : '#b91c1c'}; background: ${combinedPct >= 50 ? '#dcfce7' : '#fee2e2'}; padding: 1px 8px; border-radius: 10px;">
              ${combinedPct >= 50 ? 'PROMOTED TO NEXT CLASS (کامیاب و ترقی)' : 'NEEDS IMPROVEMENT (محنت درکار)'}
            </span>
          </div>

          <div style="display: grid; grid-template-columns: repeat(5, 1fr); gap: 6px; text-align: center;">
            <div style="background: #ffffff; padding: 4px 6px; border-radius: 4px; border: 1px solid #cbd5e1;">
              <span style="font-size: 9.5px; color: #64748b; display: block;">1st Sem Result</span>
              <strong style="font-size: 11.5px; color: #166534;">${sem1 ? sem1.totalObtained : 0} / ${sem1 ? sem1.maxMarks : 0} (${sem1 ? sem1.percentage + '%' : '-'})</strong>
            </div>
            <div style="background: #ffffff; padding: 4px 6px; border-radius: 4px; border: 1px solid #cbd5e1;">
              <span style="font-size: 9.5px; color: #64748b; display: block;">2nd Sem Result</span>
              <strong style="font-size: 11.5px; color: #1e3a8a;">${markRecord.totalObtained} / ${markRecord.maxMarks} (${markRecord.percentage}%)</strong>
            </div>
            <div style="background: #ffffff; padding: 4px 6px; border-radius: 4px; border: 1px solid #bfdbfe;">
              <span style="font-size: 9.5px; color: #64748b; display: block;">Combined Total</span>
              <strong style="font-size: 12px; color: #047857;">${combinedObt} / ${combinedMax}</strong>
            </div>
            <div style="background: #ffffff; padding: 4px 6px; border-radius: 4px; border: 1px solid #bfdbfe;">
              <span style="font-size: 9.5px; color: #64748b; display: block;">Annual %</span>
              <strong style="font-size: 12px; color: #1e3a8a;">${combinedPct}%</strong>
            </div>
            <div style="background: #ffffff; padding: 4px 6px; border-radius: 4px; border: 1px solid #bfdbfe;">
              <span style="font-size: 9.5px; color: #64748b; display: block;">Final Grade &amp; GPA</span>
              <strong style="font-size: 11.5px; color: #1e3a8a;"><span class="grade-pill grade-${(combinedGrade || 'F').replace('+', 'plus')}" style="padding: 1px 5px; font-size: 10px;">${combinedGrade}</span> (${Number(combinedGpa).toFixed(1)})</strong>
            </div>
          </div>
        </div>
      `;
    }

    let reportTitle = 'ACADEMIC PERFORMANCE REPORT CARD';
    let reportUrdu = '(تعلیمی کارکردگی رپورٹ کارڈ)';
    if (isCombined) {
      reportTitle = 'ANNUAL CONSOLIDATED ACADEMIC TRANSCRIPT';
      reportUrdu = '(سالانہ مشترکہ تعلیمی کارکردگی رپورٹ کارڈ)';
    } else if (isSem2) {
      reportTitle = '2ND SEMESTER & ANNUAL AGGREGATE REPORT CARD';
      reportUrdu = '(دوسرا سمسٹر و سالانہ مجموعی نتیجہ کارڈ)';
    } else if (isSem1) {
      reportTitle = '1ST SEMESTER ACADEMIC REPORT CARD';
      reportUrdu = '(پہلا سمسٹر تعلیمی رپورٹ کارڈ)';
    }

    // Generate QR verification code covering all exams (1 inch square)
    const qrText = this.buildStudentVerificationText(student, markRecord, settings);
    const qrDataUrl = this.generateQRCodeDataURL(qrText, 192, 192);

    return `
      <div class="official-transcript-wrapper printable-target">
        <div class="transcript-header">
          <div class="transcript-monogram-box">
            <img src="images/monogram school.jpg" alt="School Monogram" class="transcript-monogram-img">
          </div>
          <div class="school-info">
            <h2>${settings.schoolName}</h2>
            <p class="tagline">${settings.tagline}</p>
            <p class="address">${settings.address} &bull; ${settings.phone} &bull; ${settings.email}</p>
            <h3 class="transcript-title">${reportTitle} <span class="urdu-title">${reportUrdu}</span></h3>
            <span class="exam-term-badge">${markRecord.examTerm} &bull; Academic Year ${settings.academicYear}</span>
          </div>
          <div class="transcript-student-photo-box">
            ${student?.photo ? `
              <img src="${student.photo}" alt="${student?.name || 'Student Photo'}" class="transcript-student-img">
            ` : `
              <div class="transcript-student-placeholder">
                <span class="placeholder-icon">&#128100;</span>
                <span class="placeholder-label">Student Photo</span>
                <span class="urdu-title placeholder-urdu">تصویر طالب علم</span>
              </div>
            `}
          </div>
        </div>

        <div class="transcript-meta-grid">
          <div><strong>Student Name:</strong> ${student?.name || 'N/A'} <span class="urdu-title">(نام)</span></div>
          <div><strong>Admission No:</strong> ${student?.id || markRecord.studentId} <span class="urdu-title">(داخلہ نمبر)</span></div>
          <div><strong>Roll Number:</strong> ${student?.rollNo || 'N/A'} <span class="urdu-title">(رول نمبر)</span></div>
          <div><strong>Grade & Section:</strong> ${student?.grade || ''} - ${student?.section || ''} <span class="urdu-title">(جماعت)</span></div>
          <div><strong>Father Name:</strong> ${student?.guardian || 'N/A'} <span class="urdu-title">(والد کا نام)</span></div>
          <div><strong>Category:</strong> ${student?.specialCategory || 'Normal'} <span class="urdu-title">(کیٹیگری)</span></div>
          <div><strong>Attendance Rate:</strong> ${attStats.rate}% (${attStats.presentDays}/${attStats.totalDays} Days) <span class="urdu-title">(حاضری)</span></div>
        </div>

        ${tableHTML}

        ${sem2AdditionalBlocks}

        ${(isCombined || isSem2) ? '' : `
          <div class="transcript-summary-boxes">
            <div class="sum-box">
              <span class="sum-label">${markRecord.examTerm} % <span class="urdu-title">(سمسٹر فیصد)</span></span>
              <span class="sum-value">${markRecord.percentage}%</span>
            </div>
            <div class="sum-box">
              <span class="sum-label">${markRecord.examTerm} GPA <span class="urdu-title">(جی پی اے)</span></span>
              <span class="sum-value">${Number(markRecord.gpa || 0).toFixed(1)} / 4.0</span>
            </div>
            <div class="sum-box">
              <span class="sum-label">${markRecord.examTerm} Standing <span class="urdu-title">(نتیجہ)</span></span>
              <span class="sum-value result-pass">${markRecord.percentage >= 50 ? 'PASSED (کامیاب)' : 'NEEDS IMPROVEMENT (محنت درکار)'}</span>
            </div>
          </div>
        `}

        <div class="transcript-footer-section">
          <div class="transcript-remarks">
            <strong>Teacher's Evaluation &amp; Remarks <span class="urdu-title">(اساتذہ کے تاثرات و ریمارکس)</span>:</strong>
            <p>${markRecord.remarks || 'Diligent effort demonstrated across academic evaluations.'}</p>
          </div>
          <div class="transcript-qr-box">
            <div style="font-size: 8px; font-weight: 700; color: #1e3a8a; text-transform: uppercase; margin-bottom: 2px; letter-spacing: 0.3px; line-height: 1;">
              QR Verification
            </div>
            <div class="transcript-qr-frame">
              ${qrDataUrl ? `
                <img src="${qrDataUrl}" alt="Academic Verification QR" class="transcript-qr-img">
              ` : `
                <div style="font-size: 8px; color: #94a3b8; text-align: center; padding: 2px;">QR Code<br>(All Results)</div>
              `}
            </div>
            <div style="font-size: 7.5px; font-weight: 600; color: #334155; margin-top: 2px; line-height: 1;">
              All Exams Summary
            </div>
            <div class="urdu-title" style="font-size: 7px; color: #15803d; line-height: 1;">
              تصدیقی کیو آر کوڈ
            </div>
          </div>
        </div>

        <div class="transcript-signatures">
          <div class="sig-line">
            <div class="line"></div>
            <span>Class Teacher <span class="urdu-title">(کلاس ٹیچر)</span></span>
          </div>
          <div class="sig-line">
            <div class="line"></div>
            <span>Examiner / Controller <span class="urdu-title">(کنٹرولر امتحانات)</span></span>
          </div>
          <div class="sig-line">
            <div class="line"></div>
            <span>Principal's Signature <span class="urdu-title">(دستخط پرنسپل)</span></span>
          </div>
        </div>

        <div style="margin-top: 18px; padding-top: 6px; border-top: 1px dotted #cbd5e1; display: flex; justify-content: space-between; align-items: center; font-size: 10px; color: #64748b;">
          <span>Official System Document &bull; ${settings.schoolName}</span>
          <span>Designed &amp; Developed by: <strong>Shaukat Zando</strong></span>
        </div>
      </div>
    `;
  },

  // Generate Fee Payment Receipt
  generateFeeReceiptHTML(fee) {
    const student = SchoolDB.getStudentById(fee.studentId);
    const settings = SchoolDB.data.settings;
    const balance = fee.amount - fee.paidAmount;

    return `
      <div class="fee-receipt-wrapper printable-target">
        <div class="receipt-header">
          <div class="school-seal">
            <img src="images/monogram school.jpg" alt="School Monogram" class="doc-monogram-img">
          </div>
          <div>
            <h2>${settings.schoolName}</h2>
            <p>${settings.address} &bull; ${settings.phone}</p>
            <h3 class="receipt-title">OFFICIAL FEE PAYMENT RECEIPT <span class="urdu-title">(فیس ادائیگی کی رسید)</span></h3>
          </div>
        </div>

        <div class="receipt-info-strip">
          <div><strong>Receipt #:</strong> ${fee.id} <span class="urdu-title">(رسید نمبر)</span></div>
          <div><strong>Date:</strong> ${fee.paidDate || fee.createdAt || new Date().toISOString().split('T')[0]} <span class="urdu-title">(تاریخ)</span></div>
          <div><strong>Status:</strong> <span class="badge status-${fee.status.toLowerCase()}">${fee.status}</span></div>
        </div>

        <div class="receipt-student-box">
          <div><strong>Received From:</strong> ${student?.name || 'Unknown Student'} (${student?.id}) <span class="urdu-title">(طالب علم)</span></div>
          <div><strong>Class & Section:</strong> ${student?.grade || ''} - ${student?.section || ''} | Roll: ${student?.rollNo || 'N/A'} <span class="urdu-title">(جماعت و رول نمبر)</span></div>
          <div><strong>Father Name:</strong> ${student?.guardian || 'N/A'} | <strong>Contact:</strong> ${student?.phone || 'N/A'} <span class="urdu-title">(والد کا نام و فون)</span></div>
        </div>

        <table class="report-table">
          <thead>
            <tr>
              <th>Description / Particulars <span class="urdu-title">(تفصیل فیس)</span></th>
              <th>Due Date <span class="urdu-title">(آخری تاریخ)</span></th>
              <th class="text-right">Total Fee <span class="urdu-title">(کل فیس)</span></th>
              <th class="text-right">Amount Paid <span class="urdu-title">(ادا شدہ رقم)</span></th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td><strong>${fee.feeType}</strong></td>
              <td>${fee.dueDate || 'N/A'}</td>
              <td class="text-right">${settings.currency}${fee.amount.toLocaleString()}</td>
              <td class="text-right font-bold text-success">${settings.currency}${fee.paidAmount.toLocaleString()}</td>
            </tr>
          </tbody>
          <tfoot>
            <tr>
              <td colspan="3" class="text-right font-bold">Remaining Balance Due <span class="urdu-title">(بقایا رقم)</span>:</td>
              <td class="text-right font-bold ${balance > 0 ? 'text-danger' : 'text-success'}">
                ${settings.currency}${balance.toLocaleString()}
              </td>
            </tr>
          </tfoot>
        </table>

        <div class="receipt-footer-notes">
          <p><strong>Payment Mode:</strong> ${fee.method || 'Standard Checkout'} <span class="urdu-title">(طریقہ ادائیگی)</span></p>
          <p class="disclaimer">This document serves as an official proof of fee transaction generated by ${settings.schoolName}. Computer-generated voucher, signature required for verification.</p>
        </div>

        <div class="transcript-signatures">
          <div class="sig-line">
            <div class="line"></div>
            <span>Parent / Depositor <span class="urdu-title">(جمع کنندہ)</span></span>
          </div>
          <div class="sig-line">
            <div class="line"></div>
            <span>Accounts Officer <span class="urdu-title">(اکاؤنٹس آفیسر)</span></span>
          </div>
        </div>

        <div style="margin-top: 14px; padding-top: 6px; border-top: 1px dotted #cbd5e1; display: flex; justify-content: space-between; align-items: center; font-size: 10px; color: #64748b;">
          <span>Official Fee Voucher &bull; Govt: High School Zando Dheri, Mardan</span>
          <span>Designed &amp; Developed by: <strong>Shaukat Zando</strong></span>
        </div>
      </div>
    `;
  },

  printElement(htmlContent) {
    const printWindow = window.open('', '_blank', 'width=900,height=750');
    if (!printWindow) {
      alert('Pop-up blocked. Please allow popups to print documents.');
      return;
    }

    // Extract all styles currently present in the parent document (including inline and linked)
    let stylesHTML = '';
    document.querySelectorAll('style, link[rel="stylesheet"]').forEach(node => {
      stylesHTML += node.outerHTML + '\n';
    });

    printWindow.document.open();
    printWindow.document.write(`
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <title>School Document Print</title>
        ${stylesHTML}
        <style>
          @page {
            size: A4 portrait;
            margin: 8mm 10mm 8mm 10mm;
          }
          * { box-sizing: border-box; }
          body {
            background: #ffffff !important;
            margin: 0;
            padding: 0;
            color: #0f172a;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }
          .printable-target {
            box-shadow: none !important;
            border: none !important;
            padding: 0 !important;
            margin: 0 !important;
            page-break-inside: avoid !important;
            break-inside: avoid !important;
          }
          .no-print { display: none !important; }
          @media print {
            body { padding: 0 !important; margin: 0 !important; }
            .no-print { display: none !important; }
          }
        </style>
      </head>
      <body>
        <div class="no-print" style="background: #eff6ff; border: 1px solid #93c5fd; padding: 8px 14px; border-radius: 6px; margin: 10px auto; max-width: 800px; display: flex; justify-content: space-between; align-items: center;">
          <div style="font-size: 12px; color: #1e3a8a;">
            &#128424; <strong>Single-Page Print &amp; PDF View:</strong> Save as PDF or send directly to printer.
          </div>
          <div>
            <button onclick="window.print()" style="background: #1e3a8a; color: #fff; border: none; padding: 6px 16px; border-radius: 4px; font-weight: 700; cursor: pointer; font-size: 12px;">
              &#128424; Print / Save PDF
            </button>
            <button onclick="window.close()" style="background: #e2e8f0; color: #334155; border: none; padding: 6px 12px; border-radius: 4px; margin-left: 6px; cursor: pointer; font-size: 12px;">
              Close
            </button>
          </div>
        </div>
        ${htmlContent}
        <` + `script>
          window.onload = function() {
            setTimeout(function() {
              window.print();
            }, 300);
          };
        <` + `/script>
      </body>
      </html>
    `);
    printWindow.document.close();
  }
};
